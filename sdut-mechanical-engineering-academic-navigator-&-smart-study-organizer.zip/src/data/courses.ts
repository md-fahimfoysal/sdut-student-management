import { Semester } from '../types';

export const INITIAL_SEMESTERS: Semester[] = [
  {
    id: 1,
    name: "Semester 1",
    courses: [
      {
        id: "c-chinese-comp-1",
        name: "Chinese Comprehensive Course I",
        code: "SDUT-CHI101",
        completed: false,
        overview: "An introduction to foundational Chinese grammar, pronunciation patterns (pinyin), and basic conversational vocabulary specifically engineered for academic integration.",
        purpose: "To bridge language barriers for technical communication and cultural integration at SDUT.",
        learningOutcomes: [
          "Master Chinese Pinyin and four tones correctly",
          "Acquire a vocabulary of over 300 essential Chinese characters and phrases",
          "Carry out basic daily introductions, greetings, and queries"
        ],
        importance: "Critical for day-to-day survival, registration, and classroom interaction at SDUT.",
        topics: [
          {
            id: "t-chi1-t1",
            name: "Introduction to Pinyin & Phonetics",
            completed: false,
            subtopics: [
              { id: "s-chi1-t1-s1", name: "Initials and Finals", completed: false },
              { id: "s-chi1-t1-s2", name: "The Four Tones & Neutral Tone", completed: false }
            ]
          },
          {
            id: "t-chi1-t2",
            name: "Basic Social Interactions",
            completed: false,
            subtopics: [
              { id: "s-chi1-t2-s1", name: "Greetings & Small Talk", completed: false },
              { id: "s-chi1-t2-s2", name: "Asking Directions & Transport", completed: false }
            ]
          }
        ],
        engineeringPrinciples: ["Logical syntax mapping", "Phonetic articulation accuracy"],
        mathematicalFoundations: ["None"],
        laboratories: ["Phonetic Speech Lab", "Digital Pinyin Recognition practice"],
        softwareTools: ["WeChat Translate", "Pleco Dictionary App"],
        industrialApplications: ["Cross-cultural commercial communication in industrial zones"],
        researchApplications: ["Comparing foreign language teaching styles and linguistic patterns"],
        careerApplications: ["Liaison engineer for international offices", "Global logistics assistant"],
        projects: [
          { title: "Campus Tour Guide Scenario", desc: "Design a complete conversational guide for navigating Shandong University of Technology campus entirely in spoken Chinese." }
        ],
        recommendedBooks: ["New Practical Chinese Reader (Book 1) - Beijing Language University Press"],
        importantEquations: [
          { name: "Subject-Verb-Object (Basic SVO Syntax)", formula: "S + V + O", explanation: "The foundational sentence pattern for standard declarative statements in Chinese." }
        ],
        learningPath: ["Day 1-10: Pinyin drills", "Day 11-30: Character strokes and numbers", "Day 31-60: Interactive mock scenarios"]
      },
      {
        id: "c-chinese-list-1",
        name: "Chinese Listening & Speaking I",
        code: "SDUT-CHI102",
        completed: false,
        overview: "A highly interactive language program focused entirely on audio drills, comprehension practices, and active phonetic generation.",
        purpose: "Develop immediate cognitive comprehension of everyday spoken spoken patterns.",
        learningOutcomes: [
          "Differentiate fast conversational speech and tone variations",
          "Convey requests, orders, and emotional responses clearly",
          "Understand classroom commands given by native professors"
        ],
        importance: "Allows passive comprehension of spoken Chinese guidance during administrative and technical sessions.",
        topics: [
          {
            id: "t-chils1-t1",
            name: "Audio Comprehension Drill",
            completed: false,
            subtopics: [
              { id: "s-chils1-t1-s1", name: "Number systems & Prices", completed: false },
              { id: "s-chils1-t1-s2", name: "Date & Time Expressions", completed: false }
            ]
          }
        ],
        projects: [
          { title: "Marketplace Purchase Vlog", desc: "Formulate a custom vlog simulating purchasing tools or groceries at an SDUT market." }
        ]
      },
      {
        id: "c-chinese-char",
        name: "Chinese Character Course",
        code: "SDUT-CHI103",
        completed: false,
        overview: "A dedicated breakdown of Chinese character stroke order, radicals, structural composition, and reading strategies.",
        purpose: "Provide the student with the capability to recognize, decipher, and reconstruct physical text.",
        learningOutcomes: [
          "Understand the 8 fundamental stroke types",
          "Recognize 100 high-frequency radical configurations",
          "Acknowledge the visual development of traditional to simplified characters"
        ],
        importance: "Forms the base of structural character construction necessary for higher-level reading.",
        topics: [
          {
            id: "t-chichar-t1",
            name: "Foundational Stroke OrderRules",
            completed: false,
            subtopics: [
              { id: "s-chichar-t1-s1", name: "Left-to-Right & Top-to-Bottom", completed: false },
              { id: "s-chichar-t1-s2", name: "Radical Classification & Lookup", completed: false }
            ]
          }
        ],
        projects: [
          { title: "Stroke Animation Logbook", desc: "Analyze and document the precise dynamic writing paths of 50 core mechanical labels in Chinese characters." }
        ]
      }
    ]
  },
  {
    id: 2,
    name: "Semester 2",
    courses: [
      {
        id: "c-chinese-comp-2",
        name: "Chinese Comprehensive Course II",
        code: "SDUT-CHI201",
        completed: false,
        overview: "Intermediate grammar structures, particle behaviors (le, guo, zhe) and expanded compound vocabulary lists.",
        purpose: "Further develop structural speaking abilities and paragraph composition rules.",
        topics: [
          {
            id: "t-chi2-t1",
            name: "Compound Sentence Patterns",
            completed: false,
            subtopics: [
              { id: "s-chi2-t1-s1", name: "Conditionals (ruguo... dehua)", completed: false },
              { id: "s-chi2-t1-s2", name: "Aspect Particles of Action completion", completed: false }
            ]
          }
        ]
      },
      {
        id: "c-chinese-list-2",
        name: "Chinese Listening & Speaking II",
        code: "SDUT-CHI202",
        completed: false,
        topics: [
          {
            id: "t-chils2-t1",
            name: "Interactive Situational Dialogues",
            completed: false,
            subtopics: [{ id: "s-chils2-t1-s1", name: "At the Bank & Hospital", completed: false }]
          }
        ]
      },
      {
        id: "c-china-country",
        name: "China Country Profile",
        code: "SDUT-CHI203",
        completed: false,
        overview: "A comprehensive investigation of China's modern geography, economic geography, governmental sectors, historic milestones, and technological milestones.",
        purpose: "To introduce students to the societal structure and economic systems of China.",
        topics: [
          {
            id: "t-ccp-t1",
            name: "Economic Geography & Modern Zones",
            completed: false,
            subtopics: [
              { id: "s-ccp-t1-s1", name: "The Yangtze River Delta", completed: false },
              { id: "s-ccp-t1-s2", name: "High-Speed Rail Networks", completed: false }
            ]
          }
        ]
      },
      {
        id: "c-thermodynamics",
        name: "Fundamentals of Thermodynamics & Heat Transfer",
        code: "SDUT-ME201",
        completed: false,
        overview: "Deep study of energy transformation principles. Investigates the first and second laws of thermodynamics, transient and steady-state conduction, convection coefficients, and radiative exchange.",
        purpose: "Master thermodynamic modeling and engineering of industrial heat systems.",
        learningOutcomes: [
          "Analyze thermodynamic cycles including Rankine, Otto, and Diesel engines",
          "Set up differential equations for multidimensional transient heat conduction",
          "Formulate custom heat exchanger models using LMTD and NTU methods"
        ],
        importance: "The literal backbone of energy generation, engine design, turbine cooling, and electronics packaging.",
        topics: [
          {
            id: "t-therm-t1",
            name: "Laws of Thermodynamics & Real Gases",
            completed: false,
            subtopics: [
              { id: "s-therm-t1-s1", name: "First Law: Energy conservation for closed systems", completed: false },
              { id: "s-therm-t1-s2", name: "Second Law: Entropy generation & cycle efficiencies", completed: false },
              { id: "s-therm-t1-s3", name: "Equation of State for Real Gases", completed: false }
            ]
          },
          {
            id: "t-therm-t2",
            name: "Conduction, Convection & Radiation",
            completed: false,
            subtopics: [
              { id: "s-therm-t2-s1", name: "Fourier's Law & thermal resistance networks", completed: false },
              { id: "s-therm-t2-s2", name: "Boundary layer theories and Nusselt correlations", completed: false },
              { id: "s-therm-t2-s3", name: "Blackbody radiation & grey surfaces emittance", completed: false }
            ]
          }
        ],
        engineeringPrinciples: [
          "Conservation of Energy (1st Law)",
          "Entropy Maximization (2nd Law)",
          "Fourier's Rate Equation"
        ],
        mathematicalFoundations: [
          "Partial differential equations",
          "Boundary value integration",
          "Logarithmic mean functions"
        ],
        laboratories: [
          "Bomb calorimeter liquid fuel heating evaluation",
          "Concentric tube counter-flow heat exchanger performance profiling"
        ],
        softwareTools: ["MATLAB", "ANSYS Fluent (Thermal Core)", "EES (Engineering Equation Solver)"],
        industrialApplications: ["Powerplant turbine optimization", "EV battery thermal management packs"],
        researchApplications: ["Nanofluids for localized heat transfer enhancement", "Phase-change material heat sinks"],
        careerApplications: ["HVAC thermal architect", "Turbinery thermal dynamics specialist"],
        projects: [
          { title: "EV Battery Plate Thermal Sink Design", desc: "Dimension a custom liquid-cooled cold plate for an 800V EV battery module under extreme discharging conditions." }
        ],
        recommendedBooks: [
          "Introduction to Thermodynamics and Heat Transfer - Yunus A. Cengel",
          "Fundamentals of Heat and Mass Transfer - Incropera & DeWitt"
        ],
        importantEquations: [
          { name: "Ideal Gas Law", formula: "P * V = n * R * T", explanation: "Relates pressure, volume, gas constants, and temperature of primitive synthetic gases." },
          { name: "Fourier's Law of Heat Conduction", formula: "q = -k * A * (dT / dx)", explanation: "Calculates local heat transfer rate proportional to directional temperature gradient." },
          { name: "Newton's Law of Cooling", formula: "q = h * A * (Ts - T_inf)", explanation: "Defines rate of convective heat dissipation from physical boundary surfaces to fluid streams." }
        ],
        learningPath: ["Weeks 1-4: Basic properties & laws", "Weeks 5-8: Power cycles & refrigeration", "Weeks 9-12: Thermal energy conduction", "Weeks 13-16: Engineering heat exchangers"]
      },
      {
        id: "c-adv-math",
        name: "Advanced Mathematics",
        code: "SDUT-MATH201",
        completed: false,
        overview: "Calculus of several variables, multiple integrals, vector geometry, line and surface integrals, and infinite series.",
        purpose: "Build the foundational multivariable analytical calculus necessary to understand spatial mechanics.",
        topics: [
          {
            id: "t-math-t1",
            name: "Multivariable Calculus",
            completed: false,
            subtopics: [
              { id: "s-math-t1-s1", name: "Partial Derivatives & Gradients", completed: false },
              { id: "s-math-t1-s2", name: "Double and Triple Integrals in Spherical Coordinates", completed: false }
            ]
          }
        ],
        importantEquations: [
          { name: "Stokes' Theorem", formula: "∫(F • dr) = ∬(Curl F) • dS", explanation: "Equates the circulation of a vector field around a closed loop to the flux of curl through the enclosed surface." }
        ]
      },
      {
        id: "c-linear-algebra",
        name: "Linear Algebra",
        code: "SDUT-MATH202",
        completed: false,
        topics: [
          {
            id: "t-la-t1",
            name: "Matrices and Orthogonality",
            completed: false,
            subtopics: [
              { id: "s-la-t1-s1", name: "Eigenvalues & Eigenvectors", completed: false },
              { id: "s-la-t1-s2", name: "Gram-Schmidt Orthogonalization", completed: false }
            ]
          }
        ]
      },
      {
        id: "c-prob-stats",
        name: "Probability & Statistics",
        code: "SDUT-MATH203",
        completed: false,
        topics: [
          {
            id: "t-ps-t1",
            name: "Statistical Distributions",
            completed: false,
            subtopics: [{ id: "s-ps-t1-s1", name: "Gaussian & Weibull Distributions", completed: false }]
          }
        ]
      },
      {
        id: "c-machine-drawing",
        name: "Machine Drawing",
        code: "SDUT-ME202",
        completed: false,
        overview: "Drafting standards and methods. Covers orthographic projections, detailed section views, auxiliary orientations, dimensioning standards, assembly drawings, and tolerance symbols.",
        purpose: "Produce and interpret complex standardized orthographic and assembly mechanical drawings.",
        topics: [
          {
            id: "t-md-t1",
            name: "Orthographic Projections & Sectioning",
            completed: false,
            subtopics: [
              { id: "s-md-t1-s1", name: "First-angle vs Third-angle projections", completed: false },
              { id: "s-md-t1-s2", name: "Full and half section planes", completed: false }
            ]
          },
          {
            id: "t-md-t2",
            name: "Fits and Tolerances (GD&T)",
            completed: false,
            subtopics: [
              { id: "s-md-t2-s1", name: "Clearance, transition, and interference fits", completed: false },
              { id: "s-md-t2-s2", name: "Geometric Dimensioning & Tolerancing (GD&T) datums", completed: false }
            ]
          }
        ],
        softwareTools: ["AutoCAD", "SolidWorks"],
        importantEquations: [
          { name: "Max Clearance Formula", formula: "C_max = Hole_max - Shaft_min", explanation: "Establishes extreme boundaries of clearance fits to authorize free-rotation mechanical bushings." }
        ],
        projects: [
          { title: "Speed Reducer Assembly Layout", desc: "Construct a complete, multi-sheet geometric representation of a complex gear motor assembly featuring nested shafts and bearings." }
        ]
      }
    ]
  },
  {
    id: 3,
    name: "Semester 3",
    courses: [
      {
        id: "c-intermed-ch",
        name: "Intermediate Chinese",
        code: "SDUT-CHI301",
        completed: false,
        topics: [
          {
            id: "t-intchi-t1",
            name: "Academic Communication Foundations",
            completed: false,
            subtopics: [{ id: "s-intchi-t1-s1", name: "Expressing professional opinions", completed: false }]
          }
        ]
      },
      {
        id: "c-hsk4-1",
        name: "HSK Level 4 Tutoring I",
        code: "SDUT-CHI302",
        completed: false,
        overview: "Targeted preparation for passing HSK 4 globally accredited standard. Concentrates on high frequency vocabulary integration and quick structure reading.",
        purpose: "Exceed the university graduation requirement of HSK level 4.",
        topics: [
          {
            id: "t-hsk3-t1",
            name: "Reading Comprehension Strategy",
            completed: false,
            subtopics: [{ id: "s-hsk3-t1-s1", name: "Identifying sentence structure errors", completed: false }]
          }
        ]
      },
      {
        id: "c-theo-mechanics",
        name: "Theoretical Mechanics",
        code: "SDUT-ME301",
        completed: false,
        overview: "Statics, Kinematics, and Dynamics of rigid particles and linked systems. Explores force vector equilibrium, instantaneous centers of velocity, and Lagrange structural equations.",
        purpose: "Apply physical dynamics to complex articulating mechanical systems.",
        topics: [
          {
            id: "t-tm-t1",
            name: "Kinematics of Rigid Bodies",
            completed: false,
            subtopics: [
              { id: "s-tm-t1-s1", name: "Virtual work theorem for mechanics systems", completed: false },
              { id: "s-tm-t1-s2", name: "Instantaneous centers of rotational speed", completed: false }
            ]
          }
        ],
        softwareTools: ["Adams", "MATLAB Simscape"],
        importantEquations: [
          { name: "Newton's Second Law for Rigid Rotations", formula: "M = I * alpha", explanation: "Equates output rotating torque to moment of inertia scaled by angular acceleration rate." }
        ]
      },
      {
        id: "c-mat-physics",
        name: "Engineering Materials Physics",
        code: "SDUT-ME302",
        completed: false,
        topics: [
          {
            id: "t-emp-t1",
            name: "Crystal Structures & Grain Boundaries",
            completed: false,
            subtopics: [{ id: "s-emp-t1-s1", name: "BCC, FCC, and HCP crystal configurations", completed: false }]
          }
        ]
      },
      {
        id: "c-design-mechanic",
        name: "Basic Design of Mechanic",
        code: "SDUT-ME303",
        completed: false,
        topics: [
          {
            id: "t-bdm-t1",
            name: "Power Transmission Components",
            completed: false,
            subtopics: [
              { id: "s-bdm-t1-s1", name: "Spur & Helical Gear sizing algorithms", completed: false },
              { id: "s-bdm-t1-s2", name: "Belt/Chain tensioning specifications", completed: false }
            ]
          }
        ]
      },
      {
        id: "c-perception-prac",
        name: "Perception of Chinese Social Practice",
        code: "SDUT-CHI303",
        completed: false,
        topics: [
          {
            id: "t-pcsp-t1",
            name: "Zibo Local Industrial Tourism",
            completed: false,
            subtopics: [{ id: "s-pcsp-t1-s1", name: "Corporate visits to Int. Manufacturing Hubs", completed: false }]
          }
        ]
      }
    ]
  },
  {
    id: 4,
    name: "Semester 4",
    courses: [
      {
        id: "c-hsk4-2",
        name: "HSK Level 4 Tutoring II",
        code: "SDUT-CHI401",
        completed: false,
        topics: [
          {
            id: "t-hsk42-t1",
            name: "Writing Paragraph Composition",
            completed: false,
            subtopics: [{ id: "s-hsk42-t1-s1", name: "Rearranging Jumbled Sentences (HSK4 Core)", completed: false }]
          }
        ]
      },
      {
        id: "c-culture",
        name: "Chinese Culture",
        code: "SDUT-CHI402",
        completed: false,
        topics: [
          {
            id: "t-cc-t1",
            name: "Confucian Philosophy & Modern Ethics",
            completed: false,
            subtopics: [{ id: "s-cc-t1-s1", name: "Filial piety and engineering corporate styles", completed: false }]
          }
        ]
      },
      {
        id: "c-culture-exp",
        name: "Chinese Culture Experience",
        code: "SDUT-CHI403",
        completed: false,
        topics: [
          {
            id: "t-cce-t1",
            name: "Artistic Heritage Practices",
            completed: false,
            subtopics: [{ id: "s-cce-t1-s1", name: "Tea ceremony & traditional calligraphy styles", completed: false }]
          }
        ]
      },
      {
        id: "c-ind-org",
        name: "Industrial Organization",
        code: "SDUT-ME401",
        completed: false,
        topics: [
          {
            id: "t-io-t1",
            name: "Toyota Lean Production Core",
            completed: false,
            subtopics: [
              { id: "s-io-t1-s1", name: "Kaizen cycles & Just-In-Time schedules", completed: false },
              { id: "s-io-t1-s2", name: "Value Stream Mapping & Waste metrics", completed: false }
            ]
          }
        ]
      },
      {
        id: "c-tech-report",
        name: "Technical Report Writing",
        code: "SDUT-ME402",
        completed: false,
        topics: [
          {
            id: "t-trw-t1",
            name: "Abstract Engineering Structuring",
            completed: false,
            subtopics: [{ id: "s-trw-t1-s1", name: "Writing structured technical abstracts", completed: false }]
          }
        ]
      },
      {
        id: "c-fluid-mechanics",
        name: "Fluid Mechanics & Hydraulic Machines",
        code: "SDUT-ME403",
        completed: false,
        overview: "Statics and dynamics of compressible and incompressible fluids. Navier-Stokes formulations, drag/lift parameters, and operational curves of auxiliary hydraulic turbine loops.",
        purpose: "Formulate physical pipe networks, fluid transfer systems, and assess turbine dynamics.",
        topics: [
          {
            id: "t-fm-t1",
            name: "Fluid Kinematics & Bernoulli's Extension",
            completed: false,
            subtopics: [
              { id: "s-fm-t1-s1", name: "Bernoulli Equation constraints & conservation", completed: false },
              { id: "s-fm-t1-s2", name: "Viscous head loss values inside pipe circuits", completed: false }
            ]
          }
        ],
        importantEquations: [
          { name: "Bernoulli Equation", formula: "P + 0.5 * rho * V^2 + rho * g * z = Constant", explanation: "Defines static and dynamic pressure preservation in frictionless streamlines." }
        ]
      },
      {
        id: "c-mech-materials",
        name: "Mechanics of Materials",
        code: "SDUT-ME404",
        completed: false,
        overview: "Stress-strain relationships in axial, torsional, and bending mechanical loads. Shear diagrams, deformation gradients, elastic constants, and column buckling rules.",
        topics: [
          {
            id: "t-mm-t1",
            name: "Multidimensional Structural Loading",
            completed: false,
            subtopics: [
              { id: "s-mm-t1-s1", name: "Mohr's Circle of Stress transformations", completed: false },
              { id: "s-mm-t1-s2", name: "Euler-Bernoulli beam deflection integration", completed: false }
            ]
          }
        ],
        importantEquations: [
          { name: "Hooke's General Elasticity", formula: "sigma = E * epsilon", explanation: "Relates tensile stress to physical strain inside materials' normal proportional threshold boundaries." }
        ]
      },
      {
        id: "c-exchangeability",
        name: "Elementary Technology of Exchangeability Measurement",
        code: "SDUT-ME405",
        completed: false,
        topics: [
          {
            id: "t-etem-t1",
            name: "Interchangeability Engineering Rules",
            completed: false,
            subtopics: [
              { id: "s-etem-t1-s1", name: "Maximum Material Condition (MMC) constraints", completed: false },
              { id: "s-etem-t1-s2", name: "Micrometer & Coordinate Measuring Machine (CMM) calibration", completed: false }
            ]
          }
        ]
      }
    ]
  },
  {
    id: 5,
    name: "Semester 5",
    courses: [
      {
        id: "c-machining-principles",
        name: "Machining Principles & Machine Tools",
        code: "SDUT-ME501",
        completed: false,
        overview: "Chip formation physics, mechanics of orthogonal cutting tool geometries, structural components of turning/milling platforms.",
        topics: [
          {
            id: "t-mpmt-t1",
            name: "Orthogonal Metal Cutting Dynamics",
            completed: false,
            subtopics: [
              { id: "s-mpmt-t1-s1", name: "Merchant's Shear Angle Circle", completed: false },
              { id: "s-mpmt-t1-s2", name: "Taylor Tool Life calculation dynamics", completed: false }
            ]
          }
        ]
      },
      {
        id: "c-manufacturing-processes",
        name: "Introduction to Manufacturing Processes",
        code: "SDUT-ME502",
        completed: false,
        topics: [
          {
            id: "t-imp-t1",
            name: "Primary Forming Practices",
            completed: false,
            subtopics: [
              { id: "s-imp-t1-s1", name: "Metal Casting sand geometries & shrinkage", completed: false },
              { id: "s-imp-t1-s2", name: "Weld metallurgy heat affected zones (HAZ)", completed: false }
            ]
          }
        ]
      },
      {
        id: "c-electrical-sys",
        name: "Simulation Technology of Mechanical & Electrical Systems",
        code: "SDUT-ME503",
        completed: false,
        topics: [
          {
            id: "t-stmes-t1",
            name: "Multi-domain Modeling",
            completed: false,
            subtopics: [
              { id: "s-stmes-t1-s1", name: "State-space system transformation calculations", completed: false },
              { id: "s-stmes-t1-s2", name: "Simulink feedback circuit controllers", completed: false }
            ]
          }
        ]
      },
      {
        id: "c-cad-cam",
        name: "Mechanics CAD/CAM",
        code: "SDUT-ME504",
        completed: false,
        overview: "Computational geometry, NURBS, modeling kernel engines, automated G-code toolpath routing, advanced parameters of tool penetration layers.",
        topics: [
          {
            id: "t-cadcam-t1",
            name: "Computer-Aided Design Kernels",
            completed: false,
            subtopics: [
              { id: "s-cadcam-t1-s1", name: "NURBS surface modeling routines", completed: false },
              { id: "s-cadcam-t1-s2", name: "CLData G-code post-processing filters", completed: false }
            ]
          }
        ],
        softwareTools: ["SolidWorks", "UG NX", "Mastercam"]
      },
      {
        id: "c-ultra-precision",
        name: "Ultra Precision Manufacturing Technology",
        code: "SDUT-ME505",
        completed: false,
        topics: [
          {
            id: "t-upmt-t1",
            name: "Nanometer Machining Dynamics",
            completed: false,
            subtopics: [{ id: "s-upmt-t1-s1", name: "Single-point diamond cutting engines", completed: false }]
          }
        ]
      },
      {
        id: "c-pneumatic-trans",
        name: "Hydraulic & Pneumatic Transmission",
        code: "SDUT-ME506",
        completed: false,
        topics: [
          {
            id: "t-hpt-t1",
            name: "Fluid Power Circuit Layout",
            completed: false,
            subtopics: [
              { id: "s-hpt-t1-s1", name: "Directional spool control valve interfaces", completed: false },
              { id: "s-hpt-t1-s2", name: "Sizing auxiliary hydraulic pumps & reservoirs", completed: false }
            ]
          }
        ],
        importantEquations: [
          { name: "Hydraulic Cylinder Force Output", formula: "F = P * A", explanation: "Relates line operating pressure and effective piston surface area to mechanical output force." }
        ]
      }
    ]
  },
  {
    id: 6,
    name: "Semester 6",
    courses: [
      {
        id: "c-dynamics-machines",
        name: "Dynamics of Machines",
        code: "SDUT-ME601",
        completed: false,
        topics: [
          {
            id: "t-dom-t1",
            name: "Balancing of Rotors & Links",
            completed: false,
            subtopics: [
              { id: "s-dom-t1-s1", name: "Static & Dynamic rotor unbalance identification", completed: false },
              { id: "s-dom-t1-s2", name: "Critical speed evaluation of multi-bearing shafts", completed: false }
            ]
          }
        ]
      },
      {
        id: "c-nc-tech",
        name: "Numerical Control Technology",
        code: "SDUT-ME602",
        completed: false,
        overview: "Architecture of industrial CNC controller units, interpolator mechanics, modern machine feedback closed-loop scales, and ISO standard manual code blocks.",
        topics: [
          {
            id: "t-nct-t1",
            name: "Interpolation Algorithms & Toolpaths",
            completed: false,
            subtopics: [
              { id: "s-nct-t1-s1", name: "Linear & circular interpolation interpolation math", completed: false },
              { id: "s-nct-t1-s2", name: "Manual code blocks writing (G01 G02 G03)", completed: false }
            ]
          }
        ],
        softwareTools: ["UG NX", "Vericut Simulation Suite"]
      },
      {
        id: "c-quality",
        name: "Quality & Reliability Engineering",
        code: "SDUT-ME603",
        completed: false,
        topics: [
          {
            id: "t-qre-t1",
            name: "Statistical Quality Controls",
            completed: false,
            subtopics: [
              { id: "s-qre-t1-s1", name: "X-bar and R-chart control limits layout", completed: false },
              { id: "s-qre-t1-s2", name: "Weibull Failure Rate structural reliability plotting", completed: false }
            ]
          }
        ]
      },
      {
        id: "c-testing-tech",
        name: "Testing Technology for Mechanical Engineering",
        code: "SDUT-ME604",
        completed: false,
        topics: [
          {
            id: "t-ttme-t1",
            name: "Signal Acquisition Systems",
            completed: false,
            subtopics: [
              { id: "s-ttme-t1-s1", name: "Strain gauge Wheatstone bridge balance settings", completed: false },
              { id: "s-ttme-t1-s2", name: "Nyquist Sampling limit constraints in ADCs", completed: false }
            ]
          }
        ],
        importantEquations: [
          { name: "Nyquist Sampling Rate Condition", formula: "fs >= 2 * f_max", explanation: "Mandates analog sensor sampling rates must double the highest tracking frequency to resist Aliasing." }
        ]
      }
    ]
  },
  {
    id: 7,
    name: "Semester 7",
    courses: [
      {
        id: "c-advanced-mfg",
        name: "Advanced Manufacturing Technology",
        code: "SDUT-ME701",
        completed: false,
        topics: [
          {
            id: "t-amt-t1",
            name: "Additive Laser Deposition",
            completed: false,
            subtopics: [
              { id: "s-amt-t1-s1", name: "Selective Laser Sintering (SLS) boundaries", completed: false },
              { id: "s-amt-t1-s2", name: "Infill topology optimization parameters", completed: false }
            ]
          }
        ]
      },
      {
        id: "c-fea",
        name: "Finite Element Analysis",
        code: "SDUT-ME702",
        completed: false,
        overview: "Stiffness matrix algorithms and direct assembly methods. Focuses on element shape functions, linear/quadratic interpolation, stress concentration solving, and vibrational modal analysis fields.",
        purpose: "Formulate computational structural solvers of complex irregular parts.",
        topics: [
          {
            id: "t-fea-t1",
            name: "Finite Element Formulations",
            completed: false,
            subtopics: [
              { id: "s-fea-t1-s1", name: "1D Axial bar element local stiffness assembly", completed: false },
              { id: "s-fea-t1-s2", name: "Global coordinate transformation matrix mapping", completed: false },
              { id: "s-fea-t1-s3", name: "Isoparametric quadrilateral element shape integration", completed: false }
            ]
          }
        ],
        softwareTools: ["ANSYS Mechanical", "Abaqus / CAE", "HyperMesh"],
        importantEquations: [
          { name: "Global Equilibrium Equation", formula: "[K] • {u} = {F}", explanation: "Relates global stiffness matrix [K], displacements array {u}, and discrete nodal forces dynamic {F}." }
        ]
      },
      {
        id: "c-intel-mfg",
        name: "Intelligent Manufacturing Technology",
        code: "SDUT-ME703",
        completed: false,
        overview: "Industry 4.0 paradigms. Integrates cyber-physical production frameworks, IIoT networks, automated smart storage, and smart camera vision systems.",
        topics: [
          {
            id: "t-imt-t1",
            name: "Cyber-Physical System Layout",
            completed: false,
            subtopics: [
              { id: "s-imt-t1-s1", name: "Modbus / OPC UA plant telemetry routing", completed: false },
              { id: "s-imt-t1-s2", name: "Automatic Guided Vehicle (AGV) path rules", completed: false }
            ]
          }
        ],
        softwareTools: ["Siemens TIA Portal", "Node-RED", "Gemini AI Analytics / Smart Vision SDKs"]
      },
      {
        id: "c-non-trad",
        name: "Non Traditional Machining Technology",
        code: "SDUT-ME704",
        completed: false,
        topics: [
          {
            id: "t-ntmt-t1",
            name: "Electrical Discharge Orthogonal Machining",
            completed: false,
            subtopics: [
              { id: "s-ntmt-t1-s1", name: "EDM dielectric fluid breakdown thresholds", completed: false },
              { id: "s-ntmt-t1-s2", name: "Laser / Abrasive Waterjet cutting rates", completed: false }
            ]
          }
        ]
      }
    ]
  },
  {
    id: 8,
    name: "Semester 8",
    courses: [
      {
        id: "c-grad-practice",
        name: "Graduation Practice",
        code: "SDUT-ME801",
        completed: false,
        topics: [
          {
            id: "t-gp-t1",
            name: "On-site Factory Traineeship",
            completed: false,
            subtopics: [{ id: "s-gp-t1-s1", name: "Manufacturing shop-floor shifts audit", completed: false }]
          }
        ]
      },
      {
        id: "c-grad-thesis",
        name: "Graduation Thesis",
        code: "SDUT-ME802",
        completed: false,
        topics: [
          {
            id: "t-gt-t1",
            name: "Academic Thesis Formulation",
            completed: false,
            subtopics: [{ id: "s-gt-t1-s1", name: "Literature review & computational modeling validation", completed: false }]
          }
        ]
      },
      {
        id: "c-final-project",
        name: "Final Engineering Design Project",
        code: "SDUT-ME803",
        completed: false,
        overview: "Capstone industrial manufacturing synthesis design. Compiles mechanical drafting, automation loops, finite element optimization, production planning in a practical engineering challenge.",
        purpose: "Perform fully integrated mechanical solution conceptualization.",
        topics: [
          {
            id: "t-fedp-t1",
            name: "Project Prototype Construction",
            completed: false,
            subtopics: [
              { id: "s-fedp-t1-s1", name: "Complete CAD layout and functional simulation", completed: false },
              { id: "s-fedp-t1-s2", name: "Economic impact, cost estimation & safety audits", completed: false }
            ]
          }
        ],
        projects: [
          { title: "Smart Autonomous Sorting Gripper Delta Unit", desc: "Design, stress-examine, and schedule the factory commissioning of a high-speed delta manipulator integrated with camera-based part classification." }
        ]
      }
    ]
  }
];
