import React, { useState } from 'react';
import { StudentProfile, Semester } from '../types';
import { StorageService } from '../utils/storage';
import {
  FileSpreadsheet,
  Edit2,
  Check,
  User,
  Shield,
  Briefcase,
  Award,
  BookOpen,
  MapPin,
  Mail,
  Phone,
  Contact,
  FileDown,
  Download,
  Printer,
  Compass,
  Database,
  Camera,
  UploadCloud
} from 'lucide-react';

interface StudentLedgerProps {
  profile: StudentProfile;
  setProfile: (p: StudentProfile) => void;
  semesters: Semester[];
}

export default function StudentLedger({ profile, setProfile, semesters }: StudentLedgerProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<StudentProfile>({ ...profile });
  const [notif, setNotif] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const triggerNotif = (msg: string) => {
    setNotif(msg);
    setTimeout(() => setNotif(null), 3000);
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      triggerNotif('Error: Dropped file is not an image!');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      if (dataUrl) {
        setFormData(prev => ({ ...prev, profilePhoto: dataUrl }));
        if (!isEditing) {
          const updatedProfile = { ...profile, profilePhoto: dataUrl };
          setProfile(updatedProfile);
          StorageService.saveProfile(updatedProfile);
          triggerNotif('Student profile photo uploaded and saved successfully!');
        } else {
          triggerNotif('Staged new profile photo! Click Commit Changes to save.');
        }
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    setProfile(formData);
    StorageService.saveProfile(formData);
    setIsEditing(false);
    triggerNotif('Student ledger record saved securely inside local cache!');
  };

  // Modern Export JSON action
  const handleExportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(StorageService.exportAllData());
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `SDUT_Ledger_${profile.studentId || 'Backup'}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    triggerNotif('Encrypted raw academic JSON export generated successfully!');
  };

  // Custom polished PDF/Transcript printer function
  const handlePrintReport = () => {
    const totalCourses = semesters.reduce((sum, s) => sum + s.courses.length, 0);
    const completedCourses = semesters.reduce((sum, s) => sum + s.courses.filter(c => c.completed).length, 0);
    const progressPercent = Math.round((completedCourses / totalCourses) * 100);

    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Pop-up blocked! Please allow popups to generate transcripts.');
      return;
    }

    const coursesRowHtml = semesters.map(s => {
      const courseRows = s.courses.map(c => `
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="padding: 8px; font-family: monospace;">${c.code || 'N/A'}</td>
          <td style="padding: 8px;">${c.name}</td>
          <td style="padding: 8px; font-weight: bold; color: ${c.completed ? '#10b981' : '#b91c1c'};">
            ${c.completed ? 'COMPLETED (Pass)' : 'PENDING'}
          </td>
        </tr>
      `).join('');
      return `
        <tr>
          <td colspan="3" style="background-color: #f1f5f9; padding: 10px; font-weight: bold; font-size: 14px; text-transform: uppercase;">
            ${s.name}
          </td>
        </tr>
        ${courseRows}
      `;
    }).join('');

    printWindow.document.write(`
      <html>
        <head>
          <title>SDUT Mechanical Engineering - Academic Transcript Report</title>
          <style>
            body { font-family: 'Helvetica Neue', Arial, sans-serif; color: #1e293b; padding: 40px; margin: 0; line-height: 1.5; }
            .header { border-bottom: 3px solid #1d4ed8; padding-bottom: 20px; margin-bottom: 30px; display: flex; align-items: center; justify-content: space-between; }
            .university-logo { font-size: 28px; font-weight: 900; color: #1d4ed8; letter-spacing: -0.5px; }
            .subtitle { font-size: 12px; text-transform: uppercase; color: #64748b; letter-spacing: 1px; }
            .grid { display: grid; grid-template-cols: 1fr 1fr; gap: 20px; margin-bottom: 40px; }
            .card { border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; background: #f8fafc; }
            .card h3 { margin-top: 0; border-bottom: 1px solid #cbd5e1; padding-bottom: 8px; font-size: 14px; text-transform: uppercase; color: #1e293b; }
            .card p { margin: 6px 0; font-size: 12px; }
            .card p strong { color: #475569; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 12px; }
            th { text-align: left; background-color: #1e293b; color: white; padding: 10px; font-weight: 600; }
            .badge { display: inline-block; padding: 4px 12px; border-radius: 12px; font-weight: bold; font-size: 12px; background: #dbeafe; color: #1d4ed8; }
            .no-print-btn { background-color: #1d4ed8; color: white; padding: 12px 24px; border: none; border-radius: 6px; font-weight: bold; font-size: 14px; cursor: pointer; margin-bottom: 20px; }
            @media print { .no-print-btn { display: none; } }
          </style>
        </head>
        <body>
          <button class="no-print-btn" onclick="window.print()">Print Official Transcript</button>
          <div class="header">
            <div>
              <div class="university-logo">山东理工大学 (SDUT)</div>
              <div class="subtitle">Shandong University of Technology • School of Mechanical Engineering</div>
            </div>
            <div style="text-align: right;">
              <span class="badge">Academic Progress: ${progressPercent}%</span>
              <p style="font-size: 11px; color:#64748b; margin-top:5px;">Generated: ${new Date().toLocaleDateString()}</p>
            </div>
          </div>

          <h2 style="border-bottom: 2px solid #cbd5e1; padding-bottom: 6px; margin-bottom: 20px; text-transform: uppercase; font-size: 18px;">
            Student Registry & Ledger Account
          </h2>

          <div class="grid">
            <div class="card">
              <h3>Personal Registry Data</h3>
              <p><strong>Full Name:</strong> ${profile.name}</p>
              <p><strong>Passport ID:</strong> ${profile.passportNumber}</p>
              <p><strong>Contact Secondary Email:</strong> ${profile.email}</p>
              <p><strong>Phone Connection:</strong> ${profile.phone}</p>
              <p><strong>Postal Address:</strong> ${profile.address}</p>
            </div>
            <div class="card">
              <h3>University Enrollment Data</h3>
              <p><strong>Student Registry No:</strong> ${profile.studentId}</p>
              <p><strong>University ID:</strong> ${profile.universityId}</p>
              <p><strong>Admission Details:</strong> ${profile.admissionInfo}</p>
              <p><strong>Scholarship Type:</strong> ${profile.scholarshipInfo}</p>
              <p><strong>Current Registry Status:</strong> ${profile.academicStatus}</p>
            </div>
          </div>

          <h3 style="margin-top: 30px; text-transform: uppercase; border-bottom: 2px solid #cbd5e1; padding-bottom: 6px;">
            Enrolled Core Program Curriculums
          </h3>
          <table>
            <thead>
              <tr>
                <th style="width: 20%;">Course Code</th>
                <th style="width: 60%;">Curriculum Component Name</th>
                <th style="width: 20%;">Execution Status</th>
              </tr>
            </thead>
            <tbody>
              ${coursesRowHtml}
            </tbody>
          </table>

          <div style="margin-top: 50px; border-top: 1px solid #cbd5e1; padding-top: 20px; font-size: 10px; color: #94a3b8; text-align: center;">
            Official Registry Copy • Shandondong University of Technology (SDUT) Mechanical Engineering Academic Navigation System.
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="space-y-6">
      {/* Floating Notifications */}
      {notif && (
        <div className="fixed bottom-5 right-5 z-50 bg-emerald-600 text-white px-4 py-3 rounded-lg shadow-xl font-bold border border-emerald-500 animate-slide-in flex items-center space-x-2">
          <Check size={16} />
          <span className="text-xs">{notif}</span>
        </div>
      )}

      {/* Header Profile Title Card with download tools */}
      <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm">
        <div className="flex items-center space-x-4">
          <div className="p-3.5 bg-blue-500/10 text-blue-500 rounded-xl">
            <FileSpreadsheet size={32} />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-[var(--text-primary)]">Student Ledger & Registry</h1>
            <p className="text-xs text-[var(--text-secondary)]">Manage administrative university registrations, passport metadata, parent logs, and export transcripts offline.</p>
          </div>
        </div>

        {/* Action Panel */}
        <div className="flex flex-wrap gap-2">
          {isEditing ? (
            <button
              onClick={handleSave}
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-lg text-xs font-bold shadow-md cursor-pointer transition-colors flex items-center gap-1"
            >
              <Check size={14} /> Commit Changes
            </button>
          ) : (
            <button
              onClick={() => setIsEditing(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg text-xs font-bold shadow-md cursor-pointer transition-colors flex items-center gap-1"
            >
              <Edit2 size={14} /> Open Edit Workspace
            </button>
          )}

          <button
            onClick={handlePrintReport}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-[var(--border-main)] px-4 py-2.5 rounded-lg text-xs font-bold cursor-pointer transition-colors flex items-center gap-1"
            title="Sits standard browser windows print overlays"
          >
            <Printer size={14} /> PDF Report / Transcript
          </button>

          <button
            onClick={handleExportJSON}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-[var(--border-main)] px-4 py-2.5 rounded-lg text-xs font-bold cursor-pointer transition-colors flex items-center gap-1"
          >
            <Download size={14} /> Export Backup
          </button>
        </div>
      </div>

      {/* Main Student details Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Side: Avatar Card & Stats summary */}
        <div className="space-y-6">
          <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-6 text-center space-y-4 shadow-sm">
            <div 
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`relative group w-32 h-32 mx-auto rounded-full cursor-pointer transition-all ${
                isDragging ? 'scale-105 ring-4 ring-blue-500 ring-offset-2' : ''
              }`}
              title="Drag and Drop picture file or click to upload"
            >
              <img
                src={formData.profilePhoto || "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=200"}
                alt="Student Profile Photo"
                className="w-32 h-32 rounded-full object-cover border-4 border-blue-500/20 ring-4 ring-blue-500/10 shadow-lg mx-auto transition-all group-hover:brightness-75 group-hover:opacity-90"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=200";
                }}
              />
              <label className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 rounded-full opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                <Camera size={20} className="text-white mb-1 animate-pulse" />
                <span className="text-[9px] text-white font-extrabold uppercase tracking-wider text-center px-2">Upload Photo</span>
                <input 
                  type="file" 
                  accept="image/*" 
                  className="hidden" 
                  onChange={handleFileChange} 
                />
              </label>
            </div>

            {isEditing ? (
              <div className="space-y-3 pt-2">
                {/* Dashed Drag and Drop Zone */}
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  className={`border-2 border-dashed rounded-xl p-4 transition-all text-center flex flex-col items-center justify-center gap-1.5 cursor-pointer ${
                    isDragging
                      ? 'border-blue-500 bg-blue-500/10 scale-[1.01]'
                      : 'border-[var(--border-main)] hover:border-blue-500/50 bg-black/15'
                  }`}
                >
                  <label className="cursor-pointer flex flex-col items-center justify-center w-full">
                    <UploadCloud className={`h-7 w-7 text-blue-400 ${isDragging ? 'animate-bounce' : ''}`} />
                    <span className="text-[11px] font-black text-[var(--text-primary)] mt-1.5 uppercase tracking-wide">
                      Drag & Drop Photo Here
                    </span>
                    <span className="text-[9px] text-[var(--text-muted)] mt-0.5">
                      or click to explore files (Max 5MB)
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </label>
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] text-[var(--text-muted)] font-bold uppercase tracking-wider block text-left">Or Profile Image URL</label>
                  <input
                    type="text"
                    name="profilePhoto"
                    value={formData.profilePhoto}
                    onChange={handleChange}
                    className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-xs text-[var(--text-primary)] rounded px-2.5 py-1.5 focus:outline-hidden font-mono"
                    placeholder="Paste direct HTTPS photo URL link..."
                  />
                </div>
              </div>
            ) : (
              <p className="text-[10px] text-[var(--text-muted)] italic font-mono">
                💡 Drag & drop or click photo to change instantly
              </p>
            )}

            <div>
              <h2 className="text-lg font-bold text-[var(--text-primary)]">{profile.name}</h2>
              <span className="text-xs text-blue-500 font-bold font-mono tracking-wider">{profile.studentId}</span>
              <div className="mt-2 text-[10px] bg-blue-500/10 text-blue-500 border border-blue-500/20 px-3 py-1 rounded-full font-bold inline-block select-none">
                {profile.academicStatus}
              </div>
            </div>

            <div className="pt-4 border-t border-[var(--border-main)] grid grid-cols-2 gap-2 text-left text-xs">
              <div>
                <span className="text-[10px] text-[var(--text-muted)] block uppercase font-bold">University ID</span>
                <span className="font-mono font-semibold text-[var(--text-secondary)]">{profile.universityId}</span>
              </div>
              <div>
                <span className="text-[10px] text-[var(--text-muted)] block uppercase font-bold">Passport ID</span>
                <span className="font-mono font-semibold text-[var(--text-secondary)]">{profile.passportNumber}</span>
              </div>
            </div>
          </div>

          {/* Institutional Stamp Info */}
          <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 space-y-3 shadow-xs">
            <h3 className="text-xs font-bold text-[var(--text-primary)] uppercase tracking-wider flex items-center gap-1.5 border-b pb-2 border-[var(--border-main)]">
              <Database size={14} className="text-indigo-400" /> System Integration Status
            </h3>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between items-center bg-black/10 p-2 rounded border border-[var(--border-main)]">
                <span className="text-[var(--text-secondary)]">Offline Cache System</span>
                <span className="text-emerald-500 font-mono font-bold">IndexedDB Ready</span>
              </div>
              <div className="flex justify-between items-center bg-black/10 p-2 rounded border border-[var(--border-main)]">
                <span className="text-[var(--text-secondary)]">Cloud Synchronization</span>
                <span className="text-indigo-400 font-mono font-bold">Encrypted JSON</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Detailed editable ledger data sheets (colspan-2) */}
        <div className="lg:col-span-2">
          <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-6 space-y-6 shadow-sm">
            <h3 className="text-sm font-bold text-[var(--text-primary)] uppercase tracking-wider border-b pb-2 border-[var(--border-main)] flex items-center gap-2">
              <User size={16} className="text-blue-500" /> Academic & Personal Registry Fields
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 text-sm">
              {/* Field: Name */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-[var(--text-muted)] font-extrabold uppercase tracking-wider flex items-center gap-1">
                  <User size={10} /> Student Full Name
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg px-3 py-2 text-xs text-[var(--text-primary)] focus:outline-hidden"
                  />
                ) : (
                  <div className="bg-[var(--bg-app)] border border-transparent rounded-lg px-3 py-2 text-xs text-[var(--text-primary)] font-semibold">
                    {profile.name}
                  </div>
                )}
              </div>

              {/* Field: Student ID */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-[var(--text-muted)] font-extrabold uppercase tracking-wider flex items-center gap-1">
                  <Briefcase size={10} /> Program Registration ID
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    name="studentId"
                    value={formData.studentId}
                    onChange={handleChange}
                    className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg px-3 py-2 text-xs text-[var(--text-primary)] font-mono focus:outline-hidden"
                  />
                ) : (
                  <div className="bg-[var(--bg-app)] border border-transparent rounded-lg px-3 py-2 text-xs text-[var(--text-primary)] font-mono font-semibold">
                    {profile.studentId}
                  </div>
                )}
              </div>

              {/* Field: University ID */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-[var(--text-muted)] font-extrabold uppercase tracking-wider flex items-center gap-1">
                  <Shield size={10} /> Local SDUT ID Number
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    name="universityId"
                    value={formData.universityId}
                    onChange={handleChange}
                    className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg px-3 py-2 text-xs text-[var(--text-primary)] font-mono focus:outline-hidden"
                  />
                ) : (
                  <div className="bg-[var(--bg-app)] border border-transparent rounded-lg px-3 py-2 text-xs text-[var(--text-primary)] font-mono">
                    {profile.universityId}
                  </div>
                )}
              </div>

              {/* Field: Passport */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-[var(--text-muted)] font-extrabold uppercase tracking-wider flex items-center gap-1">
                  <Compass size={10} /> International Passport Number
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    name="passportNumber"
                    value={formData.passportNumber}
                    onChange={handleChange}
                    className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg px-3 py-2 text-xs text-[var(--text-primary)] font-mono focus:outline-hidden"
                  />
                ) : (
                  <div className="bg-[var(--bg-app)] border border-transparent rounded-lg px-3 py-2 text-xs text-[var(--text-primary)] font-mono">
                    {profile.passportNumber}
                  </div>
                )}
              </div>

              {/* Field: Email */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-[var(--text-muted)] font-extrabold uppercase tracking-wider flex items-center gap-1">
                  <Mail size={10} /> Email Communication Address
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg px-3 py-2 text-xs text-[var(--text-primary)] focus:outline-hidden"
                  />
                ) : (
                  <div className="bg-[var(--bg-app)] border border-transparent rounded-lg px-3 py-2 text-xs text-[var(--text-primary)]">
                    {profile.email}
                  </div>
                )}
              </div>

              {/* Field: Phone */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-[var(--text-muted)] font-extrabold uppercase tracking-wider flex items-center gap-1">
                  <Phone size={10} /> Contact Phone Number
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg px-3 py-2 text-xs text-[var(--text-primary)] focus:outline-hidden"
                  />
                ) : (
                  <div className="bg-[var(--bg-app)] border border-transparent rounded-lg px-3 py-2 text-xs text-[var(--text-primary)]">
                    {profile.phone}
                  </div>
                )}
              </div>

              {/* Field: Admission Info */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-[var(--text-muted)] font-extrabold uppercase tracking-wider flex items-center gap-1">
                  <BookOpen size={10} /> Admission Intake Details
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    name="admissionInfo"
                    value={formData.admissionInfo}
                    onChange={handleChange}
                    className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg px-3 py-2 text-xs text-[var(--text-primary)] focus:outline-hidden"
                  />
                ) : (
                  <div className="bg-[var(--bg-app)] border border-transparent rounded-lg px-3 py-2 text-xs text-[var(--text-secondary)]">
                    {profile.admissionInfo}
                  </div>
                )}
              </div>

              {/* Field: Scholarship */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-[var(--text-muted)] font-extrabold uppercase tracking-wider flex items-center gap-1">
                  <Award size={10} /> Scholarship Information Label
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    name="scholarshipInfo"
                    value={formData.scholarshipInfo}
                    onChange={handleChange}
                    className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg px-3 py-2 text-xs text-[var(--text-primary)] focus:outline-hidden"
                  />
                ) : (
                  <div className="bg-[var(--bg-app)] border border-transparent rounded-lg px-3 py-2 text-xs text-[var(--text-secondary)]">
                    {profile.scholarshipInfo}
                  </div>
                )}
              </div>

              {/* Field: Address */}
              <div className="space-y-1.5 sm:col-span-2">
                <label className="text-[10px] text-[var(--text-muted)] font-extrabold uppercase tracking-wider flex items-center gap-1">
                  <MapPin size={10} /> Registry Post Mailing Address
                </label>
                {isEditing ? (
                  <textarea
                    name="address"
                    value={formData.address}
                    onChange={handleChange}
                    rows={2}
                    className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg px-3 py-2 text-xs text-[var(--text-primary)] focus:outline-hidden"
                  />
                ) : (
                  <div className="bg-[var(--bg-app)] border border-transparent rounded-lg px-3 py-2 text-xs text-[var(--text-primary)]">
                    {profile.address}
                  </div>
                )}
              </div>

              {/* Field: Emergency Contact */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-[var(--text-muted)] font-extrabold uppercase tracking-wider flex items-center gap-1">
                  <Contact size={10} /> Emergency Contact Hotlines
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    name="emergencyContact"
                    value={formData.emergencyContact}
                    onChange={handleChange}
                    className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg px-3 py-2 text-xs text-[var(--text-primary)] focus:outline-hidden"
                  />
                ) : (
                  <div className="bg-[var(--bg-app)] border border-transparent rounded-lg px-3 py-2 text-xs text-[var(--text-primary)]">
                    {profile.emergencyContact}
                  </div>
                )}
              </div>

              {/* Field: Parent Info */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-[var(--text-muted)] font-extrabold uppercase tracking-wider flex items-center gap-1">
                  <User size={10} /> Parent Registry Specifications
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    name="parentInfo"
                    value={formData.parentInfo}
                    onChange={handleChange}
                    className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg px-3 py-2 text-xs text-[var(--text-primary)] focus:outline-hidden"
                  />
                ) : (
                  <div className="bg-[var(--bg-app)] border border-transparent rounded-lg px-3 py-2 text-xs text-[var(--text-secondary)]">
                    {profile.parentInfo}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  );
}
