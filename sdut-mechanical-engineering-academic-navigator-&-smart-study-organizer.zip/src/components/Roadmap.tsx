import React, { useState } from 'react';
import { Semester, Course } from '../types';
import CourseDetail from './CourseDetail';
import {
  Map,
  Compass,
  CheckCircle2,
  Lock,
  ChevronRight,
  Sparkles,
  BookOpen,
  Eye,
  Bookmark,
  Plus
} from 'lucide-react';

interface RoadmapProps {
  semesters: Semester[];
  setSemesters: (s: Semester[]) => void;
  bookmarks: any[];
  onToggleBookmark: (item: any) => void;
  selectedCourseId: string | null;
  setSelectedCourseId: (id: string | null) => void;
}

export default function Roadmap({
  semesters,
  setSemesters,
  bookmarks,
  onToggleBookmark,
  selectedCourseId,
  setSelectedCourseId
}: RoadmapProps) {
  const [activeTab, setActiveTab] = useState<number>(2); // Semester 2 default
  const [filterCompleted, setFilterCompleted] = useState<'all' | 'ongoing' | 'finished'>('all');

  // Find currently selected course
  const allCourses = semesters.flatMap((s) => s.courses);
  const selectedCourse = allCourses.find((c) => c.id === selectedCourseId) || null;

  const currentSemesterIndex = semesters.findIndex((s) => s.id === activeTab);
  const activeSemester = semesters[currentSemesterIndex] || semesters[0];

  const handleToggleCourseCompleted = (courseId: string) => {
    const updated = semesters.map((sem) => {
      const updatedCourses = sem.courses.map((c) => {
        if (c.id === courseId) {
          const nextCompletedState = !c.completed;
          // Dynamically trigger corresponding subtopics as completed also for better progress user experience
          const updatedTopics = (c.topics || []).map((t) => ({
            ...t,
            completed: nextCompletedState,
            subtopics: (t.subtopics || []).map((sub) => ({ ...sub, completed: nextCompletedState }))
          }));
          return { ...c, completed: nextCompletedState, topics: updatedTopics };
        }
        return c;
      });
      return { ...sem, courses: updatedCourses };
    });
    setSemesters(updated);
  };

  // Filter list of courses inside the active semester tab
  const activeSemCoursesFiltered = activeSemester.courses.filter((c) => {
    if (filterCompleted === 'finished') return c.completed;
    if (filterCompleted === 'ongoing') return !c.completed;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Upper header */}
      <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[var(--text-primary)] flex items-center gap-2">
            <Compass className="text-blue-500" size={24} /> Degree Roadmap & Program Guide
          </h1>
          <p className="text-xs text-[var(--text-secondary)]">
            Configure semesters tabs, check progress, browse curriculum topics, equations, laboratories, and bookmarks.
          </p>
        </div>

        {/* Course Filter control */}
        <div className="flex bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg p-1 text-xs">
          <button
            onClick={() => setFilterCompleted('all')}
            className={`px-3 py-1.5 rounded-md font-bold transition-all cursor-pointer ${
              filterCompleted === 'all' ? 'bg-blue-600 text-white' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
          >
            All Courses
          </button>
          <button
            onClick={() => setFilterCompleted('ongoing')}
            className={`px-3 py-1.5 rounded-md font-bold transition-all cursor-pointer ${
              filterCompleted === 'ongoing' ? 'bg-blue-600 text-white' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
          >
            Ongoing
          </button>
          <button
            onClick={() => setFilterCompleted('finished')}
            className={`px-3 py-1.5 rounded-md font-bold transition-all cursor-pointer ${
              filterCompleted === 'finished' ? 'bg-blue-600 text-white' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
          >
            Finished
          </button>
        </div>
      </div>

      {/* Horizontal Semesters Navigator Row */}
      <div className="flex overflow-x-auto pb-2 gap-2 border-b border-[var(--border-main)] scrollbar-thin">
        {semesters.map((sem) => {
          const isSelected = sem.id === activeTab;
          const completedCount = sem.courses.filter((c) => c.completed).length;
          const totalCount = sem.courses.length;
          const percentage = Math.round((completedCount / totalCount) * 100);

          return (
            <button
              key={sem.id}
              onClick={() => setActiveTab(sem.id)}
              className={`flex-shrink-0 px-4 py-3 rounded-xl border transition-all cursor-pointer text-left min-w-[130px] ${
                isSelected
                  ? 'bg-blue-600 border-blue-600 text-white shadow-lg shadow-blue-500/10'
                  : 'bg-[var(--bg-card)] border-[var(--border-main)] text-[var(--text-secondary)] hover:border-slate-500'
              }`}
            >
              <span className="text-[10px] uppercase tracking-wider font-extrabold block">SDUT</span>
              <p className="text-xs font-bold mt-0.5">{sem.name}</p>
              <div className="flex items-center space-x-1.5 mt-2">
                <div className="w-full bg-black/20 h-1.5 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${isSelected ? 'bg-white' : 'bg-blue-500'}`}
                    style={{ width: `${percentage}%` }}
                  />
                </div>
                <span className="text-[9px] font-bold font-mono">{percentage}%</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Main Grid: Left side (Active semester list), Right side (Detailed view panel of chosen course) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        
        {/* Left column: Courses checklist of active semester */}
        <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-2xl p-5 sm:p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b pb-3 border-[var(--border-main)]">
            <h2 className="text-sm font-black text-[var(--text-primary)] uppercase tracking-wider flex items-center gap-2">
              <BookOpen size={16} className="text-indigo-400" /> {activeSemester?.name || 'Semester Info'} Courses
            </h2>
            <span className="text-xs bg-slate-800 text-slate-300 font-mono font-bold px-2 py-0.5 rounded-full">
              {activeSemester?.courses.filter((c) => c.completed).length}/{activeSemester?.courses.length} Completed
            </span>
          </div>

          <div className="space-y-3">
            {activeSemCoursesFiltered.length > 0 ? (
              activeSemCoursesFiltered.map((course) => {
                const isSelected = course.id === selectedCourseId;
                return (
                  <div
                    key={course.id}
                    className={`p-4 rounded-xl border transition-all flex flex-col justify-between gap-3 cursor-pointer ${
                      isSelected
                        ? 'border-blue-500 bg-blue-500/5 shadow-md shadow-blue-500/5'
                        : 'border-[var(--border-main)] bg-[var(--bg-card-hover)]/30 hover:bg-[var(--bg-card-hover)]'
                    }`}
                    onClick={() => setSelectedCourseId(course.id)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="min-w-0 flex-1">
                        <span className="text-[9px] font-mono uppercase bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-bold">
                          {course.code || 'SDUT-ME'}
                        </span>
                        <h4 className="text-xs font-bold text-[var(--text-primary)] mt-1.5 leading-snug line-clamp-1">
                          {course.name}
                        </h4>
                      </div>

                      {/* Complete toggle checkbox button */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleCourseCompleted(course.id);
                        }}
                        className={`w-6 h-6 rounded-full flex items-center justify-center transition-colors border cursor-pointer ${
                          course.completed
                            ? 'bg-emerald-500 border-emerald-500 text-white'
                            : 'border-[var(--border-main)] hover:border-emerald-500 text-transparent'
                        }`}
                        title="Toggle Entire Course Completed Status"
                      >
                        ✓
                      </button>
                    </div>

                    <p className="text-[11px] text-[var(--text-secondary)] line-clamp-2 leading-relaxed">
                      {course.overview || 'General introductory language or foundational course for Shandong University of Technology students.'}
                    </p>

                    <div className="flex items-center justify-between pt-2 border-t border-[var(--border-main)]">
                      <span className="text-[9px] font-bold text-[var(--text-muted)] font-mono">
                        {(course.topics || []).length} Main Topics Listed
                      </span>
                      <span className="text-[10px] text-blue-500 font-semibold hover:underline flex items-center gap-0.5">
                        Open details <ChevronRight size={12} />
                      </span>
                    </div>
                  </div>
                );
              })
            ) : (
              <p className="text-xs text-[var(--text-muted)] italic py-4 text-center">No matching courses for current filter options.</p>
            )}
          </div>
        </div>

        {/* Right column: Interactive curriculum details sheet */}
        <div>
          {selectedCourse ? (
            <CourseDetail
              course={selectedCourse}
              onToggleCompleted={() => handleToggleCourseCompleted(selectedCourse.id)}
              isBookmarked={bookmarks.some((b) => b.itemId === selectedCourse.id)}
              onToggleBookmark={() => onToggleBookmark({
                id: `bm-${selectedCourse.id}`,
                type: 'course',
                itemId: selectedCourse.id,
                title: selectedCourse.name,
                subTitle: `${selectedCourse.code || 'ME'} • Semester Tabs`
              })}
              onToggleSubtopic={(topicIndex, subtopicIndex) => {
                // Inline subtopic toggling reactively update semesters
                const updated = semesters.map((sem) => {
                  const updatedCourses = sem.courses.map((c) => {
                    if (c.id === selectedCourse.id) {
                      const updatedTopics = [...c.topics];
                      const targetTopic = updatedTopics[topicIndex];
                      const targetSub = targetTopic.subtopics[subtopicIndex];
                      targetSub.completed = !targetSub.completed;

                      // If all subtopics in this topic are checked, mark topic completed!
                      const allSubsDone = targetTopic.subtopics.every((sub) => sub.completed);
                      targetTopic.completed = allSubsDone;

                      // If all topics in this course are checked, mark course completed!
                      const allTopicsDone = updatedTopics.every((t) => t.completed);
                      c.completed = allTopicsDone;

                      return { ...c, topics: updatedTopics };
                    }
                    return c;
                  });
                  return { ...sem, courses: updatedCourses };
                });
                setSemesters(updated);
              }}
            />
          ) : (
            <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-2xl p-8 text-center shadow-sm text-xs text-[var(--text-muted)] italic">
              <Compass size={40} className="mx-auto text-[var(--text-muted)] opacity-20 mb-3 animate-pulse" />
              Select any engineering curriculum course on the left column to display the detailed knowledge map, laboratory configurations, vector formulas, books, projects, and learning pathways.
            </div>
          )}
        </div>
        
      </div>
    </div>
  );
}
