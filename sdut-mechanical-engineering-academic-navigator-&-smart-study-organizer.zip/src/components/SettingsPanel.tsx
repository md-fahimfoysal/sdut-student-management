import React, { useState } from 'react';
import {
  StudentProfile,
  Semester,
  Course,
  Topic,
  Subtopic,
  ThemeType,
  AppSettings
} from '../types';
import { StorageService } from '../utils/storage';
import {
  Sliders,
  Palette,
  Network,
  Database,
  CloudLightning,
  BellRing,
  Trash2,
  Plus,
  Compass,
  CheckCircle,
  HelpCircle,
  FolderPlus,
  UploadCloud,
  FileMinus,
  Wrench,
  Wifi,
  ChevronDown
} from 'lucide-react';

interface SettingsPanelProps {
  settings: AppSettings;
  setSettings: (s: AppSettings) => void;
  profile: StudentProfile;
  setProfile: (p: StudentProfile) => void;
  semesters: Semester[];
  setSemesters: (s: Semester[]) => void;
  isOnline: boolean;
  setIsOnline: (on: boolean) => void;
}

export default function SettingsPanel({
  settings,
  setSettings,
  profile,
  setProfile,
  semesters,
  setSemesters,
  isOnline,
  setIsOnline
}: SettingsPanelProps) {
  // Tabs for settings sections
  const [activeTab, setActiveTab] = useState<'themes' | 'academic-editor' | 'backups-sync' | 'system'>('themes');

  const [notification, setNotification] = useState<string | null>(null);

  const displayNotif = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  // 21 Themes listings
  const themesList: { id: ThemeType; label: string; preview: string }[] = [
    { id: 'clean-minimalism', label: 'Clean Minimalism ✦', preview: 'bg-[#0A0A0B] border-slate-500' },
    { id: 'elegant-dark', label: 'Elegant Dark', preview: 'bg-slate-950 border-slate-600' },
    { id: 'white-academic', label: 'White Academic ☀️', preview: 'bg-white border-slate-400' },
    { id: 'ivory-warm', label: 'Ivory Warm ☕', preview: 'bg-[#FAF9F5] border-amber-800' },
    { id: 'nordic-light', label: 'Nordic Light ❄️', preview: 'bg-[#F0F4F8] border-sky-400' },
    { id: 'sage-ceramic', label: 'Sage Ceramic 🌿', preview: 'bg-[#F3F7F4] border-emerald-600' },
    { id: 'minimal-grey', label: 'Minimal Slate Grey 🔘', preview: 'bg-[#F9FAFB] border-slate-700' },
    { id: 'mint-green', label: 'Mint Green', preview: 'bg-emerald-950 border-emerald-600' },
    { id: 'ocean-blue', label: 'Ocean Blue', preview: 'bg-blue-950 border-blue-600' },
    { id: 'cyber-cyan', label: 'Cyber Cyan', preview: 'bg-cyan-950 border-cyan-400' },
    { id: 'deep-navy', label: 'Deep Navy', preview: 'bg-indigo-950 border-indigo-600' },
    { id: 'crimson-red', label: 'Crimson Red', preview: 'bg-rose-950 border-rose-600' },
    { id: 'sunset-orange', label: 'Sunset Orange', preview: 'bg-orange-950 border-orange-600' },
    { id: 'galaxy-purple', label: 'Galaxy Purple', preview: 'bg-purple-950 border-purple-600' },
    { id: 'titanium-black', label: 'Titanium Black', preview: 'bg-zinc-950 border-zinc-700' },
    { id: 'golden-executive', label: 'Golden Executive', preview: 'bg-amber-950 border-yellow-500' },
    { id: 'forest-green', label: 'Forest Green', preview: 'bg-green-950 border-green-600' },
    { id: 'nordic-frost', label: 'Nordic Frost ❄', preview: 'bg-[#18232c] border-sky-400' },
    { id: 'sakura-pink', label: 'Sakura Pink 🌸', preview: 'bg-[#2c1a1f] border-rose-400' },
    { id: 'royal-emerald', label: 'Royal Emerald 👑', preview: 'bg-[#042e1d] border-amber-400' },
    { id: 'retro-amber', label: 'Retro Amber 📟', preview: 'bg-[#1c1405] border-yellow-500' }
  ];

  const handleSelectTheme = (thm: ThemeType) => {
    const updated = { ...settings, theme: thm };
    setSettings(updated);
    StorageService.saveSettings(updated);
    displayNotif(`Theme switched successfully to ${thm}!`);
  };

  const [generalTitleInput, setGeneralTitleInput] = useState(settings.generalTitle);
  const handleSaveTitleChange = () => {
    const updated = { ...settings, generalTitle: generalTitleInput };
    setSettings(updated);
    StorageService.saveSettings(updated);
    displayNotif('Application header branding updated!');
  };

  // State elements for Academic Schema Tree Editor (Semester -> Course -> Topic -> Subtopic Managers!)
  const [selectedSemId, setSelectedSemId] = useState<number>(semesters[0]?.id || 1);
  const [selectedCourseId, setSelectedCourseId] = useState<string>('');
  const [selectedTopicId, setSelectedTopicId] = useState<string>('');
  const [courseEditorTab, setCourseEditorTab] = useState<'details' | 'topics' | 'equations' | 'outcomes'>('details');

  // Sibling lookup items
  const activeSemester = semesters.find((s) => s.id === selectedSemId) || semesters[0];
  const activeCourses = activeSemester ? activeSemester.courses : [];
  const activeCourse = activeCourses.find((c) => c.id === selectedCourseId);
  const activeTopics = activeCourse ? activeCourse.topics || [] : [];
  const activeTopic = activeTopics.find((t) => t.id === selectedTopicId);

  // Schema Action: Add new Semester
  const handleAddSemester = () => {
    const nextId = semesters.length > 0 ? Math.max(...semesters.map(s => s.id)) + 1 : 1;
    const newSem: Semester = {
      id: nextId,
      name: `Semester ${nextId}`,
      courses: []
    };
    const updated = [...semesters, newSem];
    setSemesters(updated);
    StorageService.saveSemesters(updated);
    setSelectedSemId(nextId);
    displayNotif(`Semester ${nextId} appended successfully into program roadmap!`);
  };

  const handleDeleteSemester = (id: number) => {
    if (semesters.length <= 1) {
      alert('You must have at least one active semester in standard program frameworks!');
      return;
    }
    const updated = semesters.filter((s) => s.id !== id);
    setSemesters(updated);
    StorageService.saveSemesters(updated);
    setSelectedSemId(updated[0]?.id || 1);
    displayNotif(`Deleted custom semester entry.`);
  };

  const handleRenameSemester = (id: number, newName: string) => {
    if (!newName.trim()) return;
    const updated = semesters.map((s) => s.id === id ? { ...s, name: newName } : s);
    setSemesters(updated);
    StorageService.saveSemesters(updated);
    displayNotif(`Semester renamed to: "${newName}"`);
  };

  const handleUpdateCourseField = (courseId: string, updates: Partial<Course>) => {
    const updated = semesters.map((s) => {
      if (s.id === selectedSemId) {
        return {
          ...s,
          courses: s.courses.map((c) => c.id === courseId ? { ...c, ...updates } : c)
        };
      }
      return s;
    });
    setSemesters(updated);
    StorageService.saveSemesters(updated);
    displayNotif(`Course specifications updated successfully!`);
  };

  const handleUpdateTopicName = (topicId: string, newName: string) => {
    if (!newName.trim()) return;
    const updated = semesters.map((s) => {
      if (s.id === selectedSemId) {
        return {
          ...s,
          courses: s.courses.map((c) => {
            if (c.id === selectedCourseId) {
              return {
                ...c,
                topics: (c.topics || []).map((t) => t.id === topicId ? { ...t, name: newName } : t)
              };
            }
            return c;
          })
        };
      }
      return s;
    });
    setSemesters(updated);
    StorageService.saveSemesters(updated);
    displayNotif(`Topic title revised.`);
  };

  const handleUpdateSubtopicName = (subId: string, newName: string) => {
    if (!newName.trim()) return;
    const updated = semesters.map((s) => {
      if (s.id === selectedSemId) {
        return {
          ...s,
          courses: s.courses.map((c) => {
            if (c.id === selectedCourseId) {
              return {
                ...c,
                topics: (c.topics || []).map((t) => {
                  if (t.id === selectedTopicId) {
                    return {
                      ...t,
                      subtopics: (t.subtopics || []).map((sub) => sub.id === subId ? { ...sub, name: newName } : sub)
                    };
                  }
                  return t;
                })
              };
            }
            return c;
          })
        };
      }
      return s;
    });
    setSemesters(updated);
    StorageService.saveSemesters(updated);
    displayNotif(`Subtopic revised.`);
  };

  // Schema Action: Add new Course to active Semester
  const [newCourseName, setNewCourseName] = useState('');
  const [newCourseCode, setNewCourseCode] = useState('');
  const [newCourseOverview, setNewCourseOverview] = useState('');

  const handleAddCourse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCourseName.trim()) return;

    const courseId = `custom-c-${Date.now()}`;
    const newC: Course = {
      id: courseId,
      name: newCourseName,
      code: newCourseCode || `SDUT-ME${Math.floor(Math.random() * 500)}`,
      completed: false,
      overview: newCourseOverview || 'Custom course syllabus.',
      topics: [],
      recommendedBooks: ['Unspecified SDUT Engineering Guidebooks']
    };

    const updated = semesters.map((s) => {
      if (s.id === selectedSemId) {
        return { ...s, courses: [...s.courses, newC] };
      }
      return s;
    });

    setSemesters(updated);
    StorageService.saveSemesters(updated);
    setSelectedCourseId(courseId);
    setNewCourseName('');
    setNewCourseCode('');
    setNewCourseOverview('');
    displayNotif('Curriculum course appended safely into selected semester block!');
  };

  const handleDeleteCourse = (courseId: string) => {
    const updated = semesters.map((s) => {
      if (s.id === selectedSemId) {
        return { ...s, courses: s.courses.filter((c) => c.id !== courseId) };
      }
      return s;
    });
    setSemesters(updated);
    StorageService.saveSemesters(updated);
    setSelectedCourseId('');
    displayNotif('Course deleted successfully.');
  };

  const handleAddEquationToCourse = (courseId: string) => {
    const freshEq = {
      name: "Fourier Conduction Eq",
      formula: "q = -k A \\frac{dT}{dx}",
      explanation: "Heat flow rates relative to surface profiles."
    };
    const currentEqs = activeCourse?.importantEquations || [];
    handleUpdateCourseField(courseId, {
      importantEquations: [...currentEqs, freshEq]
    });
  };

  const handleUpdateEquationInCourse = (courseId: string, index: number, field: string, value: string) => {
    const currentEqs = [...(activeCourse?.importantEquations || [])];
    if (currentEqs[index]) {
      currentEqs[index] = { ...currentEqs[index], [field]: value };
      handleUpdateCourseField(courseId, { importantEquations: currentEqs });
    }
  };

  const handleDeleteEquationFromCourse = (courseId: string, index: number) => {
    const currentEqs = (activeCourse?.importantEquations || []).filter((_, idx) => idx !== index);
    handleUpdateCourseField(courseId, { importantEquations: currentEqs });
  };

  const handleAddOutcomeToCourse = (courseId: string) => {
    const current = activeCourse?.learningOutcomes || [];
    handleUpdateCourseField(courseId, {
      learningOutcomes: [...current, "Understand foundational principles of this curriculum topic."]
    });
  };

  const handleUpdateOutcomeInCourse = (courseId: string, index: number, value: string) => {
    const current = [...(activeCourse?.learningOutcomes || [])];
    current[index] = value;
    handleUpdateCourseField(courseId, { learningOutcomes: current });
  };

  const handleDeleteOutcomeFromCourse = (courseId: string, index: number) => {
    const current = (activeCourse?.learningOutcomes || []).filter((_, idx) => idx !== index);
    handleUpdateCourseField(courseId, { learningOutcomes: current });
  };

  const handleAddBookToCourse = (courseId: string) => {
    const current = activeCourse?.recommendedBooks || [];
    handleUpdateCourseField(courseId, {
      recommendedBooks: [...current, "Advanced Engineering Textbook / Guidebook"]
    });
  };

  const handleUpdateBookInCourse = (courseId: string, index: number, value: string) => {
    const current = [...(activeCourse?.recommendedBooks || [])];
    current[index] = value;
    handleUpdateCourseField(courseId, { recommendedBooks: current });
  };

  const handleDeleteBookFromCourse = (courseId: string, index: number) => {
    const current = (activeCourse?.recommendedBooks || []).filter((_, idx) => idx !== index);
    handleUpdateCourseField(courseId, { recommendedBooks: current });
  };

  // Schema Action: Add new Topic to active Course
  const [newTopicName, setNewTopicName] = useState('');
  const handleAddTopic = () => {
    if (!newTopicName.trim() || !selectedCourseId) return;

    const topicId = `custom-t-${Date.now()}`;
    const newT: Topic = {
      id: topicId,
      name: newTopicName,
      completed: false,
      subtopics: []
    };

    const updated = semesters.map((s) => {
      if (s.id === selectedSemId) {
        const updatedCourses = s.courses.map((c) => {
          if (c.id === selectedCourseId) {
            return { ...c, topics: [...(c.topics || []), newT] };
          }
          return c;
        });
        return { ...s, courses: updatedCourses };
      }
      return s;
    });

    setSemesters(updated);
    StorageService.saveSemesters(updated);
    setSelectedTopicId(topicId);
    setNewTopicName('');
    displayNotif('Topic block appended into course directory!');
  };

  const handleDeleteTopic = (topicId: string) => {
    const updated = semesters.map((s) => {
      if (s.id === selectedSemId) {
        const updatedCourses = s.courses.map((c) => {
          if (c.id === selectedCourseId) {
            return { ...c, topics: (c.topics || []).filter((t) => t.id !== topicId) };
          }
          return c;
        });
        return { ...s, courses: updatedCourses };
      }
      return s;
    });
    setSemesters(updated);
    StorageService.saveSemesters(updated);
    setSelectedTopicId('');
    displayNotif('Deleted syllabus unit topic.');
  };

  // Schema Action: Add new Subtopic to active Topic
  const [newSubtopicName, setNewSubtopicName] = useState('');
  const handleAddSubtopic = () => {
    if (!newSubtopicName.trim() || !selectedTopicId) return;

    const subId = `custom-sub-${Date.now()}`;
    const newSub: Subtopic = {
      id: subId,
      name: newSubtopicName,
      completed: false
    };

    const updated = semesters.map((s) => {
      if (s.id === selectedSemId) {
        const updatedCourses = s.courses.map((c) => {
          if (c.id === selectedCourseId) {
            const updatedTopics = (c.topics || []).map((t) => {
              if (t.id === selectedTopicId) {
                return { ...t, subtopics: [...(t.subtopics || []), newSub] };
              }
              return t;
            });
            return { ...c, topics: updatedTopics };
          }
          return c;
        });
        return { ...s, courses: updatedCourses };
      }
      return s;
    });

    setSemesters(updated);
    StorageService.saveSemesters(updated);
    setNewSubtopicName('');
    displayNotif('Incremental subtopic entry added.');
  };

  const handleDeleteSubtopic = (subId: string) => {
    const updated = semesters.map((s) => {
      if (s.id === selectedSemId) {
        const updatedCourses = s.courses.map((c) => {
          if (c.id === selectedCourseId) {
            const updatedTopics = (c.topics || []).map((t) => {
              if (t.id === selectedTopicId) {
                return { ...t, subtopics: (t.subtopics || []).filter((sub) => sub.id !== subId) };
              }
              return t;
            });
            return { ...c, topics: updatedTopics };
          }
          return c;
        });
        return { ...s, courses: updatedCourses };
      }
      return s;
    });
    setSemesters(updated);
    StorageService.saveSemesters(updated);
    displayNotif('Subtopic deleted.');
  };

  // Dynamic back up and sync operations states
  const [importJsonText, setImportJsonText] = useState('');

  const handleManualImport = () => {
    if (!importJsonText.trim()) return;
    const success = StorageService.importAllData(importJsonText);
    if (success) {
      displayNotif('Success! Symmetrical backup bundle loaded and updated reactively!');
      setTimeout(() => window.location.reload(), 1000);
    } else {
      alert('Violation during JSON bundle decompression! Verify structure syntax.');
    }
  };

  const handleResetToFactoryDefaults = () => {
    if (confirm('Critical: This resets the entire SDUT mechanical database clearing any customized planners or notes edits! Continue?')) {
      StorageService.resetToDefaults();
      displayNotif('Cache structures cleared. Reloading standard values...');
      setTimeout(() => window.location.reload(), 1200);
    }
  };

  // Simulated Cloud Sync control
  const [cloudEmail, setCloudEmail] = useState(settings.cloudSyncUser);
  
  const handleSwitchAndSyncProvider = (provider: 'none' | 'google-drive' | 'onedrive' | 'dropbox' | 'firebase') => {
    const updated = {
      ...settings,
      cloudProvider: provider,
      cloudSyncStatus: 'syncing' as const
    };
    setSettings(updated);
    StorageService.saveSettings(updated);
    displayNotif(`Establishing Cloud Tunnel with ${provider === 'google-drive' ? 'Google Drive' : provider === 'onedrive' ? 'Microsoft OneDrive' : provider === 'dropbox' ? 'Dropbox' : 'Firebase Cloud'}...`);
    
    setTimeout(() => {
      const now = new Date().toISOString();
      const updatedSynced = {
        ...updated,
        cloudSyncStatus: 'synced' as const,
        cloudSyncLastSuccess: now
      };
      setSettings(updatedSynced);
      StorageService.saveSettings(updatedSynced);
      displayNotif('State integration complete! Device verified and synchronized.');
    }, 1500);
  };

  const handleTriggerImmediateSync = () => {
    const updated = {
      ...settings,
      cloudSyncStatus: 'syncing' as const
    };
    setSettings(updated);
    StorageService.saveSettings(updated);
    displayNotif('Enqueuing immediate metadata synchronizations...');
    
    setTimeout(() => {
      const now = new Date().toISOString();
      const updatedSynced = {
        ...updated,
        cloudSyncStatus: 'synced' as const,
        cloudSyncLastSuccess: now
      };
      setSettings(updatedSynced);
      StorageService.saveSettings(updatedSynced);
      displayNotif('Success! Symmetrical Sync locks matching other clients.');
    }, 1500);
  };

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {notification && (
        <div className="fixed bottom-5 right-5 z-50 bg-blue-600 text-white px-4 py-2 text-xs font-bold rounded-lg border border-blue-500 shadow-xl animate-slide-in flex items-center space-x-2">
          <CheckCircle size={14} />
          <span>{notification}</span>
        </div>
      )}

      {/* Header element */}
      <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[var(--text-primary)] flex items-center gap-2">
            <Sliders className="text-blue-500" size={24} /> Management Cockpit & Settings Interface
          </h1>
          <p className="text-xs text-[var(--text-secondary)]">
            Configure application branding headers, switch between the 17 premium presets, restructure curriculum schemas, and sync databases.
          </p>
        </div>

        {/* Setting Selector Tabs */}
        <div className="flex bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg p-1 text-xs">
          <button
            onClick={() => setActiveTab('themes')}
            className={`px-3 py-1.5 rounded-md font-bold transition-all cursor-pointer ${
              activeTab === 'themes' ? 'bg-blue-600 text-white' : 'text-[var(--text-secondary)] hover:text-white'
            }`}
          >
            Themes & Brand
          </button>
          <button
            onClick={() => setActiveTab('academic-editor')}
            className={`px-3 py-1.5 rounded-md font-bold transition-all cursor-pointer ${
              activeTab === 'academic-editor' ? 'bg-blue-600 text-white' : 'text-[var(--text-secondary)] hover:text-white'
            }`}
          >
            Academic Trees
          </button>
          <button
            onClick={() => setActiveTab('backups-sync')}
            className={`px-3 py-1.5 rounded-md font-bold transition-all cursor-pointer ${
              activeTab === 'backups-sync' ? 'bg-blue-600 text-white' : 'text-[var(--text-secondary)] hover:text-white'
            }`}
          >
            Database & Sync
          </button>
          <button
            onClick={() => setActiveTab('system')}
            className={`px-3 py-1.5 rounded-md font-bold transition-all cursor-pointer ${
              activeTab === 'system' ? 'bg-blue-600 text-white' : 'text-[var(--text-secondary)] hover:text-white'
            }`}
          >
            System Args
          </button>
        </div>
      </div>

      {/* Workspace Display sheets */}
      <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 sm:p-6 shadow-xs">
        
        {/* TAB 1: Themes & Branding Title */}
        {activeTab === 'themes' && (
          <div className="space-y-6">
            <div className="border-b pb-3 border-[var(--border-main)] flex items-center justify-between">
              <h3 className="text-sm font-black text-[var(--text-primary)] uppercase tracking-wider flex items-center gap-2">
                <Palette className="text-emerald-400" size={16} /> Switch Application Color Themes
              </h3>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2.5 py-0.5 rounded-full font-bold">
                21 Themes Presets
              </span>
            </div>

            {/* Title override */}
            <div className="bg-black/10 border border-[var(--border-main)] rounded-lg p-4 max-w-xl text-xs space-y-3">
              <span className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Customize Application Header Brand Title</span>
              <div className="flex gap-2.5">
                <input
                  type="text"
                  value={generalTitleInput}
                  onChange={(e) => setGeneralTitleInput(e.target.value)}
                  className="flex-1 bg-[var(--bg-app)] text-xs text-[var(--text-primary)] border border-[var(--border-main)] rounded-lg px-3 py-2 focus:outline-hidden focus:border-blue-500"
                  placeholder="Insert custom application title label..."
                />
                <button
                  onClick={handleSaveTitleChange}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-bold cursor-pointer transition-colors"
                >
                  Save Title
                </button>
              </div>
            </div>

            {/* Grid of 12 Themes Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5 pt-3">
              {themesList.map((thm) => {
                const isSelected = settings.theme === thm.id;
                return (
                  <button
                    key={thm.id}
                    onClick={() => handleSelectTheme(thm.id)}
                    className={`p-4 rounded-xl border text-left flex flex-col justify-between h-24 transition-all cursor-pointer hover:-translate-y-0.5 ${
                      isSelected ? 'border-blue-500 bg-blue-500/5' : 'border-[var(--border-main)] bg-[var(--bg-card-hover)]/20 hover:bg-[var(--bg-card-hover)]'
                    }`}
                  >
                    <div>
                      <span className="font-bold text-xs text-[var(--text-primary)] block">{thm.label}</span>
                      <span className="text-[9px] text-[var(--text-muted)] font-mono">Selector ID: {thm.id}</span>
                    </div>

                    <div className="flex items-center space-x-2 self-end">
                      {/* Theme color previews dot */}
                      <span className={`w-3.5 h-3.5 rounded-full border ${thm.preview}`} />
                      {isSelected && (
                        <span className="text-[10px] text-blue-500 font-extrabold uppercase font-mono">Active</span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 2: Academic Program Tree Editor */}
        {activeTab === 'academic-editor' && (
          <div className="space-y-6">
            <div className="border-b pb-3 border-[var(--border-main)]">
              <h3 className="text-sm font-black text-[var(--text-primary)] uppercase tracking-wider flex items-center gap-2">
                <Network className="text-blue-500" size={16} /> Schema Trees / Curriculum Structure Manager
              </h3>
              <p className="text-xs text-[var(--text-muted)] mt-1">Configure Semesters, core Curriculum Courses, topics, and subtopic checkboxes.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left Side: Selectors (Slices of Tree) */}
              <div className="space-y-4 text-xs">
                
                {/* Selector: Semesters Selector with Add Sem */}
                <div className="bg-black/10 border border-[var(--border-main)] rounded-lg p-3.5 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">1. Active Semester</label>
                    <button
                      onClick={handleAddSemester}
                      className="text-[9px] bg-blue-600 hover:bg-blue-700 text-white rounded px-2.5 py-1 font-bold flex items-center gap-0.5 cursor-pointer"
                    >
                      <Plus size={10} /> Add Semester
                    </button>
                  </div>
                  <div className="flex gap-2">
                    <select
                      value={selectedSemId}
                      onChange={(e) => {
                        setSelectedSemId(Number(e.target.value));
                        setSelectedCourseId('');
                        setSelectedTopicId('');
                      }}
                      className="flex-1 bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg px-2.5 py-2 text-xs text-[var(--text-primary)] focus:outline-hidden font-bold"
                    >
                      {semesters.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name}
                        </option>
                      ))}
                    </select>
                    
                    <button
                      onClick={() => handleDeleteSemester(selectedSemId)}
                      className="p-2 border border-red-500/20 text-red-500 hover:bg-red-500/5 rounded-lg font-bold cursor-pointer transition-colors"
                      title="Delete Active Semester"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>

                  {/* Rename Semester Control inline */}
                  <div className="pt-1.5 space-y-1">
                    <label className="text-[9px] text-[var(--text-muted)] font-medium uppercase block">Rename Selected Term</label>
                    <input
                      type="text"
                      placeholder="e.g., Sophomore Year Summer"
                      value={activeSemester?.name || ''}
                      onChange={(e) => handleRenameSemester(selectedSemId, e.target.value)}
                      className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] rounded px-2 py-1 text-[11px] text-[var(--text-primary)] focus:outline-hidden font-bold"
                    />
                  </div>
                </div>

                {/* Selector: Courses Selector inside Semester */}
                <div className="bg-black/10 border border-[var(--border-main)] rounded-lg p-3.5 space-y-2">
                  <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase block">2. Select Course to Edit</label>
                  <select
                    value={selectedCourseId}
                    onChange={(e) => {
                      setSelectedCourseId(e.target.value);
                      setSelectedTopicId('');
                    }}
                    className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg px-2.5 py-2 text-xs text-[var(--text-primary)] focus:outline-hidden cursor-pointer"
                  >
                    <option value="">-- Choose Course --</option>
                    {activeCourses.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.code || 'ME'} • {c.name.slice(0, 32)}...
                      </option>
                    ))}
                  </select>
                  {selectedCourseId && (
                    <button
                      onClick={() => handleDeleteCourse(selectedCourseId)}
                      className="w-full flex items-center justify-center gap-1.5 p-1.5 border border-red-500/20 text-red-500 hover:bg-red-500/5 rounded text-[10px] font-bold mt-1.5 cursor-pointer"
                    >
                      <Trash2 size={12} /> Delete Selected Course
                    </button>
                  )}
                </div>

                {/* Selector: Focus Unit Topic within Course */}
                {selectedCourseId && (
                  <div className="bg-black/10 border border-[var(--border-main)] rounded-lg p-3.5 space-y-2">
                    <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase block">3. Select Syllabus Unit Topic</label>
                    <select
                      value={selectedTopicId}
                      onChange={(e) => setSelectedTopicId(e.target.value)}
                      className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg px-2.5 py-2 text-xs text-[var(--text-primary)] focus:outline-hidden cursor-pointer"
                    >
                      <option value="">-- Choose Unit Topic --</option>
                      {activeTopics.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.name.slice(0, 32)}...
                        </option>
                      ))}
                    </select>
                    {selectedTopicId && (
                      <button
                        onClick={() => handleDeleteTopic(selectedTopicId)}
                        className="w-full flex items-center justify-center gap-1.5 p-1.5 border border-red-500/20 text-red-500 hover:bg-red-500/5 rounded text-[10px] font-bold mt-1.5 cursor-pointer"
                      >
                        <Trash2 size={12} /> Delete Selected Topic
                      </button>
                    )}
                  </div>
                )}
              </div>

              {/* Right Side: Editors Workspace Panel (col-span-2) */}
              <div className="lg:col-span-2 space-y-5">
                
                {/* Case A: Course is Selected - Display fully-fleshed out Course Studio Editor */}
                {selectedCourseId && activeCourse ? (
                  <div className="border border-[var(--border-main)] rounded-2xl p-5 bg-[var(--bg-card)]/50 space-y-5">
                    
                    {/* Header bar of Course Studio */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[var(--border-main)]">
                      <div>
                        <span className="text-[9px] font-mono text-purple-400 bg-purple-500/10 px-2.5 py-0.5 rounded-full font-bold uppercase">
                          Syllabus Editor Cockpit
                        </span>
                        <h4 className="text-sm font-black text-[var(--text-primary)] mt-1">
                          {activeCourse.code || 'ME-XXX'} • {activeCourse.name}
                        </h4>
                      </div>
                      
                      <button
                        onClick={() => setSelectedCourseId('')}
                        className="text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg font-bold font-mono transition-all cursor-pointer inline-flex items-center gap-1"
                      >
                        ← Back to Adding Course
                      </button>
                    </div>

                    {/* Editor Sub Tabs Selector */}
                    <div className="flex border-b border-[var(--border-main)] text-[11px] gap-1 font-mono font-bold">
                      <button
                        onClick={() => setCourseEditorTab('details')}
                        className={`px-3 py-2 border-b-2 transition-colors cursor-pointer ${
                          courseEditorTab === 'details'
                            ? 'border-blue-500 text-blue-400 bg-blue-500/5'
                            : 'border-transparent text-[var(--text-secondary)] hover:text-white'
                        }`}
                      >
                        📋 Core Specs
                      </button>
                      <button
                        onClick={() => setCourseEditorTab('topics')}
                        className={`px-3 py-2 border-b-2 transition-colors cursor-pointer ${
                          courseEditorTab === 'topics'
                            ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5'
                            : 'border-transparent text-[var(--text-secondary)] hover:text-white'
                        }`}
                      >
                        📚 Unit Units
                      </button>
                      <button
                        onClick={() => setCourseEditorTab('equations')}
                        className={`px-3 py-2 border-b-2 transition-colors cursor-pointer ${
                          courseEditorTab === 'equations'
                            ? 'border-emerald-500 text-emerald-400 bg-emerald-500/5'
                            : 'border-transparent text-[var(--text-secondary)] hover:text-white'
                        }`}
                      >
                        🧮 Equations
                      </button>
                      <button
                        onClick={() => setCourseEditorTab('outcomes')}
                        className={`px-3 py-2 border-b-2 transition-colors cursor-pointer ${
                          courseEditorTab === 'outcomes'
                            ? 'border-amber-500 text-amber-400 bg-amber-500/5'
                            : 'border-transparent text-[var(--text-secondary)] hover:text-white'
                        }`}
                      >
                        🎖️ Outcomes & Books
                      </button>
                    </div>

                    {/* Sub-tab Content Workspace */}
                    <div className="space-y-4 pt-1">
                      
                      {/* Sub-Tab 1: CORE DETAILS */}
                      {courseEditorTab === 'details' && (
                        <div className="space-y-3.5 text-xs">
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <div className="sm:col-span-2 space-y-1">
                              <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Course Name</label>
                              <input
                                type="text"
                                value={activeCourse.name}
                                onChange={(e) => handleUpdateCourseField(activeCourse.id, { name: e.target.value })}
                                className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded-lg px-2.5 py-1.5 focus:outline-hidden focus:border-blue-500 font-semibold"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Course Code</label>
                              <input
                                type="text"
                                value={activeCourse.code || ''}
                                onChange={(e) => handleUpdateCourseField(activeCourse.id, { code: e.target.value })}
                                className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded-lg px-2.5 py-1.5 focus:outline-hidden focus:border-blue-500 font-mono"
                              />
                            </div>
                          </div>

                          <div className="space-y-1">
                            <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Overview details</label>
                            <textarea
                              rows={3}
                              value={activeCourse.overview || ''}
                              onChange={(e) => handleUpdateCourseField(activeCourse.id, { overview: e.target.value })}
                              className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded-lg p-2.5 focus:outline-hidden focus:border-blue-500"
                              placeholder="Describe core course overview definitions..."
                            />
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div className="space-y-1">
                              <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Purpose of Study</label>
                              <textarea
                                rows={3}
                                value={activeCourse.purpose || ''}
                                onChange={(e) => handleUpdateCourseField(activeCourse.id, { purpose: e.target.value })}
                                className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded-lg p-2.5 focus:outline-hidden focus:border-blue-500"
                                placeholder="Why study this? Enter purpose..."
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Importance Keynotes</label>
                              <textarea
                                rows={3}
                                value={activeCourse.importance || ''}
                                onChange={(e) => handleUpdateCourseField(activeCourse.id, { importance: e.target.value })}
                                className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded-lg p-2.5 focus:outline-hidden focus:border-blue-500"
                                placeholder="Curriculum significance details..."
                              />
                            </div>
                          </div>

                          <div className="flex items-center space-x-2 bg-black/10 p-3 rounded-lg border border-[var(--border-main)]">
                            <input
                              type="checkbox"
                              id="completed-course-check"
                              checked={activeCourse.completed}
                              onChange={(e) => handleUpdateCourseField(activeCourse.id, { completed: e.target.checked })}
                              className="w-4 h-4 rounded border-[var(--border-main)] bg-transparent text-emerald-500 focus:outline-hidden accent-emerald-500 cursor-pointer"
                            />
                            <label htmlFor="completed-course-check" className="text-xs font-semibold text-[var(--text-primary)] cursor-pointer">
                              Mark this core degree course as officially COMPLETED / Passed
                            </label>
                          </div>
                        </div>
                      )}

                      {/* Sub-Tab 2: TOPICS & SUBTOPICS */}
                      {courseEditorTab === 'topics' && (
                        <div className="space-y-4 text-xs">
                          
                          {/* Add a Topic form block */}
                          <div className="bg-black/10 border border-[var(--border-main)] p-3 rounded-xl space-y-2">
                            <label className="text-[10px] text-indigo-400 font-bold uppercase block">Append New Syllabus Unit Topic</label>
                            <div className="flex gap-2">
                              <input
                                type="text"
                                placeholder="e.g., Unit 5: Heat exchangers modeling"
                                value={newTopicName}
                                onChange={(e) => setNewTopicName(e.target.value)}
                                className="flex-1 bg-[var(--bg-app)] border border-[var(--border-main)] text-xs text-[var(--text-primary)] rounded-lg px-2.5 py-1.5 focus:outline-hidden"
                              />
                              <button
                                onClick={handleAddTopic}
                                className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg px-3 py-1.5 font-bold cursor-pointer transition-colors whitespace-nowrap"
                              >
                                + Add Topic
                              </button>
                            </div>
                          </div>

                          {/* List of current topics / subtopics with rename & delete capability */}
                          <div className="space-y-3.5 max-h-[280px] overflow-y-auto pr-1">
                            <span className="text-[10px] text-[var(--text-muted)] font-extrabold uppercase block font-mono">
                              Current Unit Topics & Subtopics Checklists ({activeCourse.topics?.length || 0})
                            </span>
                            
                            {activeCourse.topics && activeCourse.topics.length > 0 ? (
                              activeCourse.topics.map((topic) => {
                                const isTopicSelected = selectedTopicId === topic.id;
                                return (
                                  <div key={topic.id} className="border border-[var(--border-main)] rounded-xl p-3 bg-black/5 space-y-2.5">
                                    <div className="flex items-center justify-between gap-2">
                                      {/* Inline edit Topic Name */}
                                      <input
                                        type="text"
                                        value={topic.name}
                                        onChange={(e) => handleUpdateTopicName(topic.id, e.target.value)}
                                        className="bg-transparent border-b border-transparent hover:border-[var(--border-main)] focus:border-blue-500 font-bold text-xs text-[var(--text-primary)] py-0.5 px-1 w-[80%] focus:outline-hidden"
                                      />
                                      
                                      <div className="flex items-center space-x-1.5">
                                        <button
                                          onClick={() => {
                                            setSelectedTopicId(isTopicSelected ? '' : topic.id);
                                          }}
                                          className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer transition-colors ${
                                            isTopicSelected ? 'bg-amber-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                                          }`}
                                        >
                                          {isTopicSelected ? 'Collapse Subtopics' : 'Manage Subtopics'}
                                        </button>
                                        
                                        <button
                                          onClick={() => handleDeleteTopic(topic.id)}
                                          className="text-slate-400 hover:text-red-500 p-1 cursor-pointer transition-colors"
                                          title="Delete topic"
                                        >
                                          <Trash2 size={13} />
                                        </button>
                                      </div>
                                    </div>

                                    {/* Expanded subtopics details for active topic */}
                                    {isTopicSelected && (
                                      <div className="pl-3.5 border-l-2 border-dashed border-[var(--border-main)] space-y-2 pt-1.5">
                                        {/* Subtopic Append Block */}
                                        <div className="flex gap-1.5">
                                          <input
                                            type="text"
                                            placeholder="Insert micro subtopic step..."
                                            value={newSubtopicName}
                                            onChange={(e) => setNewSubtopicName(e.target.value)}
                                            className="flex-1 bg-[var(--bg-app)] border border-[var(--border-main)] rounded text-[11px] px-2 py-1 text-[var(--text-primary)] focus:outline-hidden"
                                          />
                                          <button
                                            onClick={handleAddSubtopic}
                                            className="bg-amber-600 hover:bg-amber-700 text-white text-[10px] rounded px-2.5 py-1 font-bold cursor-pointer"
                                          >
                                            + Add
                                          </button>
                                        </div>

                                        {/* List of subtopics in active selected topic */}
                                        <div className="space-y-1 max-h-[120px] overflow-y-auto pr-0.5">
                                          {topic.subtopics && topic.subtopics.length > 0 ? (
                                            topic.subtopics.map((sub) => (
                                              <div key={sub.id} className="flex justify-between items-center bg-[var(--bg-app)] text-[11px] p-1.5 rounded border border-[var(--border-main)]">
                                                <input
                                                  type="text"
                                                  value={sub.name}
                                                  onChange={(e) => handleUpdateSubtopicName(sub.id, e.target.value)}
                                                  className="bg-transparent border-b border-transparent hover:border-[var(--border-main)] focus:border-blue-500 py-0 px-1 text-[var(--text-secondary)] focus:outline-hidden flex-1"
                                                />
                                                <button
                                                  onClick={() => handleDeleteSubtopic(sub.id)}
                                                  className="text-slate-500 hover:text-red-500 p-0.5 cursor-pointer ml-1"
                                                >
                                                  <Trash2 size={11} />
                                                </button>
                                              </div>
                                            ))
                                          ) : (
                                            <p className="text-[9px] text-[var(--text-muted)] italic text-center py-1">No micro subtopics configured. Enter one above!</p>
                                          )}
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                );
                              })
                            ) : (
                              <p className="text-xs text-[var(--text-muted)] italic text-center py-6">No study topics defined for this course yet.</p>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Sub-Tab 3: IMPORTANT EQUATIONS */}
                      {courseEditorTab === 'equations' && (
                        <div className="space-y-4 text-xs">
                          <div className="flex items-center justify-between pb-1 border-b border-[var(--border-main)]">
                            <span className="text-[10px] text-emerald-400 font-extrabold uppercase font-mono">
                              LaTeX Chemical / Physical Equations Builder ({activeCourse.importantEquations?.length || 0})
                            </span>
                            <button
                              onClick={() => handleAddEquationToCourse(activeCourse.id)}
                              className="text-[10px] bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg px-3 py-1 font-bold cursor-pointer transition-colors"
                            >
                              + New Formula Block
                            </button>
                          </div>

                          <div className="space-y-3.5 max-h-[300px] overflow-y-auto pr-1">
                            {activeCourse.importantEquations && activeCourse.importantEquations.length > 0 ? (
                              activeCourse.importantEquations.map((eq, i) => (
                                <div key={i} className="border border-[var(--border-main)] rounded-xl p-3 bg-black/10 space-y-2">
                                  <div className="flex items-center justify-between gap-2 pb-1 border-b border-white/5">
                                    <span className="text-[10px] font-mono text-[var(--text-muted)] font-black">Equation #{i+1}</span>
                                    <button
                                      onClick={() => handleDeleteEquationFromCourse(activeCourse.id, i)}
                                      className="text-slate-400 hover:text-red-500 p-0.5 cursor-pointer transition-colors"
                                      title="Delete equation"
                                    >
                                      <Trash2 size={12} />
                                    </button>
                                  </div>

                                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                                    <div className="space-y-1">
                                      <label className="text-[9px] text-[var(--text-muted)] font-bold uppercase">Equation Label Title</label>
                                      <input
                                        type="text"
                                        value={eq.name}
                                        onChange={(e) => handleUpdateEquationInCourse(activeCourse.id, i, 'name', e.target.value)}
                                        className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded px-2 py-1 text-[11px] focus:outline-hidden"
                                      />
                                    </div>
                                    <div className="space-y-1">
                                      <label className="text-[9px] text-[var(--text-muted)] font-bold uppercase">Formula (LaTeX string)</label>
                                      <input
                                        type="text"
                                        value={eq.formula}
                                        onChange={(e) => handleUpdateEquationInCourse(activeCourse.id, i, 'formula', e.target.value)}
                                        className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded px-2 py-1 text-[11px] focus:outline-hidden font-mono"
                                      />
                                    </div>
                                  </div>

                                  <div className="space-y-1">
                                    <label className="text-[9px] text-[var(--text-muted)] font-bold uppercase">Short Scientific Explanation</label>
                                    <input
                                      type="text"
                                      value={eq.explanation}
                                      onChange={(e) => handleUpdateEquationInCourse(activeCourse.id, i, 'explanation', e.target.value)}
                                      className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded px-2 py-1 text-[11px] focus:outline-hidden"
                                    />
                                  </div>
                                </div>
                              ))
                            ) : (
                              <p className="text-xs text-[var(--text-muted)] italic text-center py-8">No specific academic formulas set yet. Press plus to create one.</p>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Sub-Tab 4: OUTCOMES & BOOKS */}
                      {courseEditorTab === 'outcomes' && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                          {/* Learning Outcomes Column */}
                          <div className="space-y-3.5 border border-[var(--border-main)] rounded-xl p-3.5 bg-black/5">
                            <div className="flex items-center justify-between pb-1.5 border-b border-white/5">
                              <span className="text-[10px] text-amber-400 font-extrabold uppercase font-mono">Learning Outcomes</span>
                              <button
                                onClick={() => handleAddOutcomeToCourse(activeCourse.id)}
                                className="bg-amber-600/10 hover:bg-amber-600/20 text-amber-400 font-mono px-2 py-0.5 rounded text-[9px] font-bold cursor-pointer"
                              >
                                + Bullet
                              </button>
                            </div>

                            <div className="space-y-2 max-h-[220px] overflow-y-auto pr-0.5">
                              {activeCourse.learningOutcomes && activeCourse.learningOutcomes.length > 0 ? (
                                activeCourse.learningOutcomes.map((out, idx) => (
                                  <div key={idx} className="flex gap-2 items-start bg-[var(--bg-app)] border border-[var(--border-main)] p-2 rounded">
                                    <textarea
                                      rows={2}
                                      value={out}
                                      onChange={(e) => handleUpdateOutcomeInCourse(activeCourse.id, idx, e.target.value)}
                                      className="flex-1 bg-transparent text-[11px] text-[var(--text-secondary)] focus:outline-hidden resize-none word-break"
                                    />
                                    <button
                                      onClick={() => handleDeleteOutcomeFromCourse(activeCourse.id, idx)}
                                      className="text-slate-500 hover:text-red-500 p-0.5 cursor-pointer"
                                      title="Delete outcome highlight"
                                    >
                                      <Trash2 size={11} />
                                    </button>
                                  </div>
                                ))
                              ) : (
                                <p className="text-[10px] text-[var(--text-muted)] italic text-center py-6">No specific learning outcome objectives defined.</p>
                              )}
                            </div>
                          </div>

                          {/* Recommended Textbook readings Column */}
                          <div className="space-y-3.5 border border-[var(--border-main)] rounded-xl p-3.5 bg-black/5">
                            <div className="flex items-center justify-between pb-1.5 border-b border-white/5">
                              <span className="text-[10px] text-sky-400 font-extrabold uppercase font-mono">Recommended Textbooks</span>
                              <button
                                onClick={() => handleAddBookToCourse(activeCourse.id)}
                                className="bg-sky-600/10 hover:bg-sky-600/20 text-sky-400 font-mono px-2 py-0.5 rounded text-[9px] font-bold cursor-pointer"
                              >
                                + Book
                              </button>
                            </div>

                            <div className="space-y-2 max-h-[220px] overflow-y-auto pr-0.5">
                              {activeCourse.recommendedBooks && activeCourse.recommendedBooks.length > 0 ? (
                                activeCourse.recommendedBooks.map((book, idx) => (
                                  <div key={idx} className="flex gap-2 items-start bg-[var(--bg-app)] border border-[var(--border-main)] p-2 rounded">
                                    <textarea
                                      rows={2}
                                      value={book}
                                      onChange={(e) => handleUpdateBookInCourse(activeCourse.id, idx, e.target.value)}
                                      className="flex-1 bg-transparent text-[11px] text-[var(--text-secondary)] focus:outline-hidden resize-none word-break"
                                    />
                                    <button
                                      onClick={() => handleDeleteBookFromCourse(activeCourse.id, idx)}
                                      className="text-slate-500 hover:text-red-500 p-0.5 cursor-pointer"
                                      title="Delete textbook recommendation"
                                    >
                                      <Trash2 size={11} />
                                    </button>
                                  </div>
                                ))
                              ) : (
                                <p className="text-[10px] text-[var(--text-muted)] italic text-center py-6">No textbooks listed. Add references above!</p>
                              )}
                            </div>
                          </div>
                        </div>
                      )}

                    </div>
                  </div>
                ) : (
                  // Case B: No Course Selected - Default view is the Course Append layout 
                  <div className="space-y-4">
                    <div className="border border-[var(--border-main)] rounded-2xl p-5 space-y-4 bg-black/10">
                      <div>
                        <span className="text-[9px] font-mono text-blue-400 bg-blue-500/10 px-2.5 py-0.5 rounded-full font-bold uppercase">
                          Curriculum Course Builder
                        </span>
                        <h4 className="text-sm font-black text-[var(--text-primary)] mt-1.5">
                          Create & Insert Course to {activeSemester?.name || 'Academic Roadmap'}
                        </h4>
                        <p className="text-[11px] text-[var(--text-secondary)] mt-1 leading-relaxed">
                          Define custom degree paths. Fill key inputs below to insert curriculum courses. Click on any course in the selector on the left to edit its full topics, LaTeX equations, outcomes, or textbooks.
                        </p>
                      </div>
                      
                      <form onSubmit={handleAddCourse} className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs pt-1.5">
                        <div className="space-y-1">
                          <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Course Name</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g., Thermal Dynamics & Fluid Kinetics"
                            value={newCourseName}
                            onChange={(e) => setNewCourseName(e.target.value)}
                            className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded-lg px-2.5 py-2 focus:outline-hidden focus:border-blue-500"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Syllabus Course Code</label>
                          <input
                            type="text"
                            placeholder="e.g., SDUT-ME201"
                            value={newCourseCode}
                            onChange={(e) => setNewCourseCode(e.target.value)}
                            className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded-lg px-2.5 py-2 focus:outline-hidden focus:border-blue-500 font-mono"
                          />
                        </div>
                        <div className="sm:col-span-2 space-y-1 font-sans">
                          <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Syllabus Overview Synopsis</label>
                          <textarea
                            rows={2}
                            placeholder="Describe course content overview, key learning pathways, experimental topics..."
                            value={newCourseOverview}
                            onChange={(e) => setNewCourseOverview(e.target.value)}
                            className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded-lg p-2.5 focus:outline-hidden focus:border-blue-500"
                          />
                        </div>
                        <button
                          type="submit"
                          className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg py-2.5 text-xs font-bold font-mono transition-colors sm:col-span-2 cursor-pointer text-center"
                        >
                          Commence Inserting Course into {activeSemester?.name}
                        </button>
                      </form>
                    </div>

                    {/* Friendly hints context */}
                    <div className="p-4 bg-blue-600/5 rounded-xl border border-blue-500/10 text-xs flex items-start gap-2 text-[var(--text-secondary)]">
                      <Compass size={16} className="text-blue-400 mt-0.5 shrink-0" />
                      <div>
                        <p className="font-bold text-[var(--text-primary)]">Tip: Full Restructuring of Roads & Trees</p>
                        <p className="mt-1 leading-relaxed text-[11px]">
                          Select a course from Selector #2 on the left. The editor will transition into specialized tabs, giving you comprehensive authority to add, update, and remove equations, textbooks, syllabus units, and degree priorities in real-time.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: Backup Managers & Cloud Sync Config panel */}
        {activeTab === 'backups-sync' && (
          <div className="space-y-6">
            <div className="border-b pb-3 border-[var(--border-main)] flex items-center justify-between">
              <h3 className="text-sm font-black text-[var(--text-primary)] uppercase tracking-wider flex items-center gap-2">
                <Database className="text-indigo-400" size={16} /> Backups Manager & Cloud Sync Integrator
              </h3>
              <span className="text-[10px] bg-red-500/10 text-rose-400 border border-red-500/20 px-2 py-0.5 rounded-full font-mono uppercase font-bold">
                conflict-wins: latest updates
              </span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Backups panel column */}
              <div className="space-y-4">
                <div className="bg-black/15 p-4 rounded-xl border border-[var(--border-main)] space-y-3 text-xs">
                  <span className="text-[10px] text-[var(--text-muted)] font-extrabold uppercase block font-mono">
                    A: Raw database JSON upload loader
                  </span>
                  <p className="text-[11px] text-[var(--text-secondary)]">Paste your previously compiled `.json` Academic OS backup files code below to restore states.</p>
                  
                  <textarea
                    rows={4}
                    value={importJsonText}
                    onChange={(e) => setImportJsonText(e.target.value)}
                    placeholder="Paste database JSON string blocks here..."
                    className="w-full bg-[var(--bg-app)] text-xs text-[var(--text-primary)] border border-[var(--border-main)] p-3 rounded-lg focus:outline-hidden font-mono"
                  />

                  <button
                    onClick={handleManualImport}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-mono py-2 text-xs font-bold rounded-lg cursor-pointer flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <UploadCloud size={14} /> Commit decompressed database override
                  </button>
                </div>

                <div className="bg-red-500/10 border border-red-500/20 p-5 rounded-xl space-y-3.5 text-xs">
                  <span className="text-[10px] text-rose-500 font-extrabold uppercase block">
                    B: Danger Zone / Destructive Clear
                  </span>
                  <p className="text-[11px] text-rose-300 leading-relaxed">
                    Clears your local caches completely, deleting custom notes, planners and resetting the core Mechanical program topics to standard factory configurations.
                  </p>
                  <button
                    onClick={handleResetToFactoryDefaults}
                    className="bg-red-600 hover:bg-red-700 text-white rounded-lg py-2 px-4 text-xs font-bold transition-colors cursor-pointer"
                  >
                    Reset standard program defaults
                  </button>
                </div>
              </div>

              {/* Simulated Cloud Synchronizer details */}
              <div className="bg-black/10 border border-[var(--border-main)] p-5 rounded-xl space-y-4 text-xs h-full flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between border-b pb-2.5 border-[var(--border-main)]/65">
                    <div className="flex items-center space-x-2 text-amber-400">
                      <CloudLightning className="animate-pulse" size={17} />
                      <span className="text-[11px] font-black uppercase tracking-wider text-[var(--text-primary)]">Cloud Account Synchronization</span>
                    </div>
                    <span className={`text-[9px] px-2 py-0.5 rounded-full font-mono uppercase font-bold ${
                      isOnline ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-500/10 text-slate-400'
                    }`}>
                      {isOnline ? 'Active Online Link' : 'Offline Mode'}
                    </span>
                  </div>
                  
                  <p className="text-[11px] text-[var(--text-secondary)] leading-relaxed mt-2.5">
                    Sync checklists, goals, semester notes, and settings automatically across any of your computers or mobile phone browsers in real-time.
                  </p>

                  {/* Connected details */}
                  <div className="mt-4 p-3 bg-black/25 rounded-lg border border-[var(--border-main)]/50 space-y-2">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-[var(--text-muted)] font-mono">SELECTED CLOUD:</span>
                      <span className="font-extrabold text-blue-400 tracking-wide uppercase font-mono">
                        {settings.cloudProvider === 'google-drive' ? 'Google Drive' :
                         settings.cloudProvider === 'onedrive' ? 'Microsoft OneDrive' :
                         settings.cloudProvider === 'dropbox' ? 'Dropbox Sync' :
                         settings.cloudProvider === 'firebase' ? 'Firebase Cloud' : 'Offline Core Sync'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] font-mono">
                      <span className="text-[var(--text-muted)]">SYNC STATUS:</span>
                      <span className={`font-semibold flex items-center gap-1 ${
                        !isOnline ? 'text-amber-400' :
                        settings.cloudSyncStatus === 'syncing' ? 'text-blue-400 animate-pulse' : 'text-emerald-400'
                      }`}>
                        <span className="w-1.5 h-1.5 rounded-full bg-current animate-ping" />
                        {!isOnline ? 'Offline Queue' :
                         settings.cloudSyncStatus === 'syncing' ? 'Synchronizing files...' : 'Synced (Identical)'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[10px] text-[var(--text-muted)] font-mono">
                      <span>Last Success:</span>
                      <span>{settings.cloudSyncLastSuccess ? new Date(settings.cloudSyncLastSuccess).toLocaleTimeString() : 'Never'}</span>
                    </div>
                  </div>

                  {/* Cloud provider switch list */}
                  <div className="mt-4 space-y-2">
                    <label className="text-[9px] text-[var(--text-muted)] font-bold uppercase tracking-wider block">Choose or Switch Active Provider</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => handleSwitchAndSyncProvider('google-drive')}
                        className={`p-2 rounded-lg border text-left flex items-center justify-between cursor-pointer transition-all ${
                          settings.cloudProvider === 'google-drive'
                            ? 'bg-blue-600/10 border-blue-500/50 text-blue-400 font-semibold'
                            : 'bg-black/15 border-[var(--border-main)]/50 text-[var(--text-secondary)] hover:border-slate-500'
                        }`}
                      >
                        <span className="font-mono text-[10px]">Google Drive</span>
                        {settings.cloudProvider === 'google-drive' && <span className="text-[9px] bg-blue-500 text-white rounded-full w-4 h-4 flex items-center justify-center">✓</span>}
                      </button>

                      <button
                        onClick={() => handleSwitchAndSyncProvider('onedrive')}
                        className={`p-2 rounded-lg border text-left flex items-center justify-between cursor-pointer transition-all ${
                          settings.cloudProvider === 'onedrive'
                            ? 'bg-indigo-600/10 border-indigo-500/50 text-indigo-400 font-semibold'
                            : 'bg-black/15 border-[var(--border-main)]/50 text-[var(--text-secondary)] hover:border-slate-500'
                        }`}
                      >
                        <span className="font-mono text-[10px]">OneDrive</span>
                        {settings.cloudProvider === 'onedrive' && <span className="text-[9px] bg-indigo-500 text-white rounded-full w-4 h-4 flex items-center justify-center">✓</span>}
                      </button>

                      <button
                        onClick={() => handleSwitchAndSyncProvider('dropbox')}
                        className={`p-2 rounded-lg border text-left flex items-center justify-between cursor-pointer transition-all ${
                          settings.cloudProvider === 'dropbox'
                            ? 'bg-sky-600/10 border-sky-500/50 text-sky-450 font-semibold'
                            : 'bg-black/15 border-[var(--border-main)]/50 text-[var(--text-secondary)] hover:border-slate-500'
                        }`}
                      >
                        <span className="font-mono text-[10px]">Dropbox</span>
                        {settings.cloudProvider === 'dropbox' && <span className="text-[9px] bg-sky-500 text-white rounded-full w-4 h-4 flex items-center justify-center">✓</span>}
                      </button>

                      <button
                        onClick={() => handleSwitchAndSyncProvider('firebase')}
                        className={`p-2 rounded-lg border text-left flex items-center justify-between cursor-pointer transition-all ${
                          settings.cloudProvider === 'firebase'
                            ? 'bg-amber-600/10 border-amber-500/50 text-amber-400 font-semibold'
                            : 'bg-black/15 border-[var(--border-main)]/50 text-[var(--text-secondary)] hover:border-slate-500'
                        }`}
                      >
                        <span className="font-mono text-[10px]">Firebase Store</span>
                        {settings.cloudProvider === 'firebase' && <span className="text-[9px] bg-amber-500 text-slate-950 rounded-full w-4 h-4 flex items-center justify-center">✓</span>}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-3 mt-4">
                    <div className="space-y-1">
                      <label className="text-[9px] text-[var(--text-muted)] font-bold uppercase tracking-wider block">Synchronization email account</label>
                      <input
                        type="email"
                        value={cloudEmail}
                        onChange={(e) => {
                          setCloudEmail(e.target.value);
                          setSettings({ ...settings, cloudSyncUser: e.target.value });
                          StorageService.saveSettings({ ...settings, cloudSyncUser: e.target.value });
                        }}
                        className="w-full bg-[var(--bg-app)] text-xs text-[var(--text-primary)] border border-[var(--border-main)] rounded-lg p-2.5 focus:outline-hidden font-mono"
                        placeholder="yourname@gmail.com"
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-5 space-y-2">
                  <button
                    onClick={handleTriggerImmediateSync}
                    disabled={settings.cloudSyncStatus === 'syncing'}
                    className={`w-full text-white rounded-lg py-2.5 text-xs font-black cursor-pointer transition-colors text-center uppercase tracking-wider flex items-center justify-center gap-1.5 ${
                      settings.cloudSyncStatus === 'syncing' ? 'bg-blue-800 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'
                    }`}
                  >
                    {settings.cloudSyncStatus === 'syncing' ? (
                      <span className="flex items-center gap-1.5 justify-center">
                        <span className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin block shrink-0" />
                        Performing synchronous verification...
                      </span>
                    ) : (
                      'Synchronize files with cloud database'
                    )}
                  </button>
                  <p className="text-[9px] text-[var(--text-muted)] text-center font-mono">
                    Conflict resolution model: Latest timestamp writes dominate.
                  </p>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* TAB 4: System Parameters */}
        {activeTab === 'system' && (
          <div className="space-y-6">
            <div className="border-b pb-3 border-[var(--border-main)] flex items-center justify-between">
              <h3 className="text-sm font-black text-[var(--text-primary)] uppercase tracking-wider flex items-center gap-2">
                <Wrench className="text-amber-500" size={16} /> Technical Parameters
              </h3>
              <span className="text-[10px] bg-slate-800 text-slate-400 font-mono font-bold px-2 py-0.5 rounded-full">
                Zibo, Shandong UTC+8
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
              
              {/* Notifications switcher */}
              <div className="bg-black/10 border border-[var(--border-main)] p-4 rounded-lg space-y-3.5">
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-xs text-[var(--text-primary)] flex items-center gap-1">
                    <BellRing size={14} className="text-teal-400 animate-pulse" /> Trigger Sound Alarms
                  </span>
                  <input
                    type="checkbox"
                    checked={settings.notificationsEnabled}
                    onChange={(e) => {
                      const updated = { ...settings, notificationsEnabled: e.target.checked };
                      setSettings(updated);
                      StorageService.saveSettings(updated);
                      displayNotif('Notification rules saved.');
                    }}
                    className="w-4 h-4 cursor-pointer"
                  />
                </div>
                <p className="text-[11px] text-[var(--text-muted)] leading-relaxed">
                  Controls bell rings and sound tones when focus timelines reach zero limit values. Uses Web Audio API.
                </p>
              </div>

              {/* Time zone configs */}
              <div className="bg-black/10 border border-[var(--border-main)] p-4 rounded-lg space-y-2">
                <span className="font-extrabold text-xs text-[var(--text-primary)] block">Active Campus Time zone Label</span>
                <input
                  type="text"
                  value={settings.activeTimezone || 'Local Browser Time'}
                  onChange={(e) => {
                    const updated = { ...settings, activeTimezone: e.target.value };
                    setSettings(updated);
                    StorageService.saveSettings(updated);
                  }}
                  className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-xs text-[var(--text-primary)] rounded-lg p-2.5 focus:outline-hidden font-mono"
                  placeholder="e.g. Asia/Shanghai (GMT+8)"
                />
                <p className="text-[10px] text-[var(--text-muted)] italic">Customize the label visible in the Campus Clock Tower observatory.</p>
              </div>

              {/* Live Location Config */}
              <div className="bg-black/10 border border-[var(--border-main)] p-4 rounded-lg space-y-3">
                <span className="font-extrabold text-xs text-[var(--text-primary)] block">Default Lab/Campus Location</span>
                <input
                  type="text"
                  value={settings.academicLocation || ''}
                  onChange={(e) => {
                    const updated = { ...settings, academicLocation: e.target.value };
                    setSettings(updated);
                    StorageService.saveSettings(updated);
                  }}
                  className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-xs text-[var(--text-primary)] rounded-lg p-2.5 focus:outline-hidden font-medium"
                  placeholder="e.g. Mechanical Engineering Lab, Zibo Campus"
                />
                <p className="text-[10px] text-[var(--text-muted)]">Customize the primary location tag displayed across status boards and tickers.</p>
              </div>

              {/* Activity Status Config */}
              <div className="bg-black/10 border border-[var(--border-main)] p-4 rounded-lg space-y-3">
                <span className="font-extrabold text-xs text-[var(--text-primary)] block">Current Activity & Status Action</span>
                <input
                  type="text"
                  value={settings.customStatus || ''}
                  onChange={(e) => {
                    const updated = { ...settings, customStatus: e.target.value };
                    setSettings(updated);
                    StorageService.saveSettings(updated);
                  }}
                  className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-xs text-[var(--text-primary)] rounded-lg p-2.5 focus:outline-hidden font-medium"
                  placeholder="e.g. 🛠️ Designing SolidWorks CAM Models"
                />
                <p className="text-[10px] text-[var(--text-muted)]">Updates the micro-activity status line on the live Observatory.</p>
              </div>

              {/* Clock display style options */}
              <div className="bg-black/10 border border-[var(--border-main)] p-4 rounded-lg md:col-span-2 space-y-3">
                <span className="font-extrabold text-xs text-[var(--text-primary)] block">Clock Ticking Mechanics</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between bg-[var(--bg-app)] p-3 rounded-md border border-[var(--border-main)]">
                    <span className="font-bold text-xs text-[var(--text-secondary)]">24-Hour Military Format</span>
                    <input
                      type="checkbox"
                      checked={settings.timeFormat === '24h'}
                      onChange={(e) => {
                        const updated = { ...settings, timeFormat: e.target.checked ? '24h' : '12h' as '12h' | '24h' };
                        setSettings(updated);
                        StorageService.saveSettings(updated);
                        displayNotif(`Clock set to ${e.target.checked ? '24-hour' : '12-hour'} format.`);
                      }}
                      className="w-4 h-4 cursor-pointer"
                    />
                  </div>

                  <div className="flex items-center justify-between bg-[var(--bg-app)] p-3 rounded-md border border-[var(--border-main)]">
                    <span className="font-bold text-xs text-[var(--text-secondary)]">Render Live Seconds Interval</span>
                    <input
                      type="checkbox"
                      checked={settings.showSeconds !== false}
                      onChange={(e) => {
                        const updated = { ...settings, showSeconds: e.target.checked };
                        setSettings(updated);
                        StorageService.saveSettings(updated);
                        displayNotif(`Live seconds ticking ${e.target.checked ? 'enabled' : 'disabled'}.`);
                      }}
                      className="w-4 h-4 cursor-pointer"
                    />
                  </div>
                </div>
              </div>

            </div>
          </div>
        )}
        
      </div>
    </div>
  );
}
