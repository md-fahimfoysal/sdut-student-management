import React, { useState } from 'react';
import { Bookmark, Semester, AcademicNote } from '../types';
import { StorageService } from '../utils/storage';
import {
  Bookmark as BookmarkIcon,
  Trash2,
  ExternalLink,
  BookOpen,
  Compass,
  FileText,
  Calculator,
  Search,
  Check
} from 'lucide-react';

interface BookmarksProps {
  bookmarks: Bookmark[];
  setBookmarks: (b: Bookmark[]) => void;
  semesters: Semester[];
  notes: AcademicNote[];
  onSelectCourse: (courseId: string) => void;
  setCurrentTab: (tab: string) => void;
}

export default function Bookmarks({
  bookmarks,
  setBookmarks,
  semesters,
  notes,
  onSelectCourse,
  setCurrentTab
}: BookmarksProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [notification, setNotification] = useState<string | null>(null);

  const displayNotif = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 2500);
  };

  const handleDeleteBookmark = (id: string) => {
    const updated = bookmarks.filter((bm) => bm.id !== id);
    setBookmarks(updated);
    StorageService.saveBookmarks(updated);
    displayNotif('Bookmark removed.');
  };

  const handleNavigateToBookmark = (bm: Bookmark) => {
    if (bm.type === 'course') {
      onSelectCourse(bm.itemId);
      setCurrentTab('roadmap');
    } else if (bm.type === 'note') {
      setCurrentTab('notes');
    } else {
      // Equations or other - redirect to general course details in Roadmap
      setCurrentTab('roadmap');
    }
  };

  const filtered = bookmarks.filter((bm) => {
    const textStr = (bm.title + ' ' + (bm.subTitle || '')).toLowerCase();
    return textStr.includes(searchQuery.toLowerCase());
  });

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {notification && (
        <div className="fixed bottom-5 right-5 z-50 bg-blue-600 text-white px-4 py-2.5 rounded-lg text-xs font-bold border border-blue-500 shadow-xl animate-slide-in flex items-center space-x-2">
          <Check size={14} />
          <span>{notification}</span>
        </div>
      )}

      {/* Header section card */}
      <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[var(--text-primary)] flex items-center gap-2">
            <BookmarkIcon className="text-blue-500 animate-pulse animate-bounce" size={24} /> Bookmarked Registries
          </h1>
          <p className="text-xs text-[var(--text-secondary)]">
            Quickly jump directly to bookmarked mechanical courses, specific unit topics, critical formulas, and customized study notes.
          </p>
        </div>
      </div>

      <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b pb-3.5 border-[var(--border-main)]">
          <div className="relative w-full sm:max-w-xs">
            <input
              type="text"
              placeholder="Search bookmarks registry..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-xs text-[var(--text-primary)] rounded-lg pl-8 pr-3 py-2.5 focus:outline-hidden"
            />
            <Search size={14} className="absolute left-2.5 top-3 text-[var(--text-muted)]" />
          </div>

          <span className="text-[10px] bg-indigo-500/10 text-indigo-400 font-mono font-bold px-2.5 py-0.5 rounded-full uppercase">
            {filtered.length} Bookmarks Found
          </span>
        </div>

        {/* Bookmarks Grid layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
          {filtered.length > 0 ? (
            filtered.map((bm) => {
              return (
                <div
                  key={bm.id}
                  className="p-4 rounded-xl border border-[var(--border-main)] bg-[var(--bg-card-hover)]/25 hover:bg-[var(--bg-card-hover)]/50 hover:border-slate-500 transition-all flex flex-col justify-between space-y-4 relative group"
                >
                  <div className="space-y-1.5 pr-6">
                    <span className="text-[8px] font-mono font-extrabold uppercase bg-indigo-500/10 text-indigo-400 px-2 py-0.5 rounded block w-max">
                      {bm.type} Registry
                    </span>
                    <h4 className="text-xs sm:text-sm font-extrabold text-[var(--text-primary)] leading-snug">
                      {bm.title}
                    </h4>
                    {bm.subTitle && (
                      <p className="text-[11px] text-[var(--text-secondary)] font-mono leading-relaxed">
                        {bm.subTitle}
                      </p>
                    )}
                  </div>

                  {/* Actions bar at bottom of card */}
                  <div className="flex items-center justify-between pt-3 border-t border-[var(--border-main)]">
                    <button
                      onClick={() => handleNavigateToBookmark(bm)}
                      className="text-[10px] bg-blue-600 hover:bg-blue-700 text-white font-bold px-3 py-1.5 rounded-lg cursor-pointer transition-colors flex items-center gap-1"
                    >
                      <ExternalLink size={10} /> Navigate to Tab
                    </button>

                    <button
                      onClick={() => handleDeleteBookmark(bm.id)}
                      className="text-slate-500 hover:text-red-500 transition-colors p-1"
                      title="Remove Bookmark Link"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="col-span-1 md:col-span-2 lg:col-span-3 text-center py-12 text-xs text-[var(--text-muted)] italic">
              No bookmarked catalog registries matched the specified parameters. Bookmark courses from the Degree Roadmap syllabus views!
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
