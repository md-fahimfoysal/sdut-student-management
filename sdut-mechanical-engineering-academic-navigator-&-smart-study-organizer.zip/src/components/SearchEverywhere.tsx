import React, { useState } from 'react';
import { Semester, AcademicNote, Bookmark } from '../types';
import {
  Search,
  X,
  Compass,
  FileText,
  Calculator,
  Navigation,
  ChevronRight
} from 'lucide-react';

interface SearchEverywhereProps {
  isOpen: boolean;
  onClose: () => void;
  semesters: Semester[];
  notes: AcademicNote[];
  bookmarks: Bookmark[];
  onSelectCourse: (courseId: string) => void;
  setCurrentTab: (tab: string) => void;
}

export default function SearchEverywhere({
  isOpen,
  onClose,
  semesters,
  notes,
  bookmarks,
  onSelectCourse,
  setCurrentTab
}: SearchEverywhereProps) {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const coursesList = semesters.flatMap((s) => s.courses);

  // Filter lists based on query
  const matchingCourses = query.trim()
    ? coursesList.filter(
        (c) =>
          c.name.toLowerCase().includes(query.toLowerCase()) ||
          (c.code && c.code.toLowerCase().includes(query.toLowerCase()))
      )
    : coursesList.slice(0, 4);

  const matchingNotes = query.trim()
    ? notes.filter(
        (n) =>
          n.title.toLowerCase().includes(query.toLowerCase()) ||
          n.content.toLowerCase().includes(query.toLowerCase())
      )
    : notes.slice(0, 3);

  // Global critical equations database
  const physicalEquations = [
    { name: "Fourier's Heat Conduction Law", formula: "q = -k A (dT/dx)", context: "Fundamentals of Thermodynamics & Heat Transfer" },
    { name: "Newton's Cooling Formulation", formula: "q = h A (Ts - T_inf)", context: "Fundamentals of Thermodynamics & Heat Transfer" },
    { name: "Ideal Gas Law State Equation", formula: "P V = n R T", context: "Power Heat Transformation Core" },
    { name: "FEA Stiffness Equilibrium Form", formula: "[K] {u} = {F}", context: "Finite Element Analysis" },
    { name: "Bernoulli Static Velocity Pressure Preservation", formula: "P + 1/2 rho V^2 + rho g z = C", context: "Fluid Mechanics" },
    { name: "Hooke Elastic Strain Stress Tensor", formula: "sigma = E epsilon", context: "Mechanics of Materials" },
    { name: "Nyquist Sensor Sampling Boundary Limit", formula: "fs >= 2 f_max", explanation: "Testing Technology sensor frequencies" }
  ];

  const matchingEquations = query.trim()
    ? physicalEquations.filter(
        (eq) =>
          eq.name.toLowerCase().includes(query.toLowerCase()) ||
          eq.formula.toLowerCase().includes(query.toLowerCase())
      )
    : physicalEquations.slice(0, 3);

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="w-full max-w-2xl bg-[var(--bg-card)] border border-[var(--border-main)] rounded-2xl shadow-2xl shadow-black/60 overflow-hidden flex flex-col max-h-[500px]">
        
        {/* Search header bar */}
        <div className="flex items-center justify-between p-4 border-b border-[var(--border-main)]">
          <div className="flex items-center space-x-3 flex-1">
            <Search className="text-[var(--text-muted)]" size={18} />
            <input
              type="text"
              placeholder="Search courses, formulas, study notes everywhere..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full bg-transparent border-0 text-sm text-[var(--text-primary)] focus:outline-hidden"
              autoFocus
            />
          </div>
          <button
            onClick={onClose}
            className="p-1 px-2 text-xs bg-[var(--bg-app)] hover:text-white rounded border border-[var(--border-main)] cursor-pointer text-[var(--text-secondary)]"
          >
            <X size={14} />
          </button>
        </div>

        {/* Categories Results Lists */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          
          {/* Section: Courses */}
          <div className="space-y-2">
            <span className="text-[10px] text-[var(--text-muted)] font-extrabold uppercase font-mono tracking-wider block">
              Program Syllabus Courses ({matchingCourses.length})
            </span>
            <div className="grid grid-cols-1 gap-1.5">
              {matchingCourses.map((c) => (
                <div
                  key={c.id}
                  onClick={() => {
                    onSelectCourse(c.id);
                    setCurrentTab('roadmap');
                    onClose();
                  }}
                  className="flex justify-between items-center p-2 rounded-lg bg-black/15 border border-[var(--border-main)] hover:border-slate-500 cursor-pointer text-xs"
                >
                  <div className="min-w-0 pr-2">
                    <span className="text-[9px] font-mono font-bold uppercase text-blue-400">[{c.code || 'SDUT'}]</span>
                    <span className="font-semibold text-[var(--text-primary)] ml-2">{c.name}</span>
                  </div>
                  <ChevronRight size={12} className="text-slate-500" />
                </div>
              ))}
            </div>
          </div>

          {/* Section: Revision Notes */}
          <div className="space-y-2">
            <span className="text-[10px] text-[var(--text-muted)] font-extrabold uppercase font-mono tracking-wider block">
              Study Notes ({matchingNotes.length})
            </span>
            <div className="grid grid-cols-1 gap-1.5">
              {matchingNotes.map((n) => (
                <div
                  key={n.id}
                  onClick={() => {
                    setCurrentTab('notes');
                    onClose();
                  }}
                  className="flex items-center space-x-3 p-2 rounded-lg bg-black/15 border border-[var(--border-main)] hover:border-slate-500 cursor-pointer text-xs"
                >
                  <FileText size={14} className="text-emerald-400" />
                  <span className="font-semibold text-[var(--text-primary)] flex-1 truncate">{n.title}</span>
                  <span className="text-[10px] text-[var(--text-muted)] font-mono">{new Date(n.lastModifiedAt).toLocaleDateString()}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Section: Formula / Calculations */}
          <div className="space-y-2">
            <span className="text-[10px] text-[var(--text-muted)] font-extrabold uppercase font-mono tracking-wider block">
              Engineering Formulations ({matchingEquations.length})
            </span>
            <div className="grid grid-cols-1 gap-1.5">
              {matchingEquations.map((eq, idx) => (
                <div
                  key={idx}
                  className="p-2.5 rounded-lg bg-[var(--bg-app)] border border-[var(--border-main)] text-xs flex justify-between items-center"
                >
                  <div>
                    <span className="font-bold text-[var(--text-primary)] block text-xs">{eq.name}</span>
                    <span className="text-[10px] mt-0.5 text-[var(--text-muted)] inline-block uppercase bg-slate-800 text-slate-400 px-1 py-0.2 rounded">{eq.context}</span>
                  </div>
                  <span className="font-mono text-xs text-rose-400 bg-black/30 p-1 rounded border border-rose-500/10 font-bold">{eq.formula}</span>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Footer info tip */}
        <div className="p-3 bg-black/25 text-[10px] text-[var(--text-secondary)] text-center border-t border-[var(--border-main)]">
          Pro-Tip: Press <kbd className="bg-slate-800 px-1.5 py-0.5 rounded text-white font-bold text-[9px]">Ctrl</kbd> + <kbd className="bg-slate-800 px-1.5 py-0.5 rounded text-white font-bold text-[9px]">K</kbd> to launch search overlays on the go.
        </div>
      </div>
    </div>
  );
}
