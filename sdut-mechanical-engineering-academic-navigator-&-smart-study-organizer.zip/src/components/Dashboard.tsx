import React, { useState, useEffect } from 'react';
import {
  StudentProfile,
  Semester,
  DailyTask,
  WeeklyGoal,
  SemesterGoal,
  ExamRoutine,
  AcademicNote,
  Bookmark,
  PomodoroHistoryItem,
  AppSettings
} from '../types';
import { StorageService } from '../utils/storage';
import CircularProgress from './CircularProgress';
import {
  GraduationCap,
  CalendarCheck,
  ClipboardList,
  Target,
  FileClock,
  Sparkles,
  BookMarked,
  Hourglass,
  CheckSquare,
  Plus,
  Flame,
  FileSymlink,
  Heart,
  ChevronRight,
  TrendingUp,
  Settings,
  Clock,
  MapPin,
  Activity,
  Globe,
  Edit,
  Check,
  X
} from 'lucide-react';

interface DashboardProps {
  profile: StudentProfile;
  setProfile: (p: StudentProfile) => void;
  semesters: Semester[];
  setSemesters: (s: Semester[]) => void;
  dailyTasks: DailyTask[];
  setDailyTasks: (t: DailyTask[]) => void;
  weeklyGoals: WeeklyGoal[];
  setWeeklyGoals: (g: WeeklyGoal[]) => void;
  semesterGoals: SemesterGoal[];
  setSemesterGoals: (g: SemesterGoal[]) => void;
  exams: ExamRoutine[];
  setExams: (e: ExamRoutine[]) => void;
  notes: AcademicNote[];
  bookmarks: Bookmark[];
  pomodoroHistory: PomodoroHistoryItem[];
  settings: AppSettings;
  setSettings: (s: AppSettings) => void;
  setCurrentTab: (tab: string) => void;
  setSelectedCourseId: (id: string | null) => void;
}

export default function Dashboard({
  profile,
  setProfile,
  semesters,
  setSemesters,
  dailyTasks,
  setDailyTasks,
  weeklyGoals,
  setWeeklyGoals,
  semesterGoals,
  setSemesterGoals,
  exams,
  setExams,
  notes,
  bookmarks,
  pomodoroHistory,
  settings,
  setSettings,
  setCurrentTab,
  setSelectedCourseId
}: DashboardProps) {
  // Stats derivations
  const totalCourses = semesters.reduce((sum, s) => sum + s.courses.length, 0);
  const completedCourses = semesters.reduce(
    (sum, s) => sum + s.courses.filter((c) => c.completed).length,
    0
  );
  const degreeProgressPercent = totalCourses > 0 ? Math.round((completedCourses / totalCourses) * 100) : 0;

  // Semester level info (let's assume current active is Semester 2 by default, or let user pick)
  const [activeSemId, setActiveSemId] = useState<number>(2);
  const activeSemester = semesters.find((s) => s.id === activeSemId) || semesters[0];
  const activeSemesterCourses = activeSemester ? activeSemester.courses : [];
  const activeSemTotal = activeSemesterCourses.length;
  const activeSemCompleted = activeSemesterCourses.filter((c) => c.completed).length;
  const semesterProgressPercent = activeSemTotal > 0 ? Math.round((activeSemCompleted / activeSemTotal) * 100) : 0;

  const finishedDailyCount = dailyTasks.filter((t) => t.completedProgress === 100).length;
  const dailyProgressPercent = dailyTasks.length > 0 ? Math.round((finishedDailyCount / dailyTasks.length) * 100) : 0;

  const finishedWeeklyCount = weeklyGoals.filter((w) => w.completedProgress === 100).length;
  const weeklyProgressPercent = weeklyGoals.length > 0 ? Math.round((finishedWeeklyCount / weeklyGoals.length) * 100) : 0;

  const finishedSemGoalsCount = semesterGoals.filter((g) => g.completedProgress === 100).length;
  const semGoalsProgressPercent = semesterGoals.length > 0 ? Math.round((finishedSemGoalsCount / semesterGoals.length) * 100) : 0;

  // Live running time and date
  const [liveTime, setLiveTime] = useState<Date>(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setLiveTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    const is12h = settings.timeFormat !== '24h';
    const withSecs = settings.showSeconds !== false;
    
    const options: Intl.DateTimeFormatOptions = {
      hour: '2-digit',
      minute: '2-digit',
      second: withSecs ? '2-digit' : undefined,
      hour12: is12h,
    };
    
    if (settings.activeTimezone && settings.activeTimezone !== 'Local Browser Time') {
      try {
        options.timeZone = settings.activeTimezone;
      } catch (e) {
        // Fallback for custom labels
      }
    }
    
    try {
      return date.toLocaleTimeString(undefined, options);
    } catch (e) {
      delete options.timeZone;
      return date.toLocaleTimeString(undefined, options);
    }
  };

  const formatDate = (date: Date) => {
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    };
    
    if (settings.activeTimezone && settings.activeTimezone !== 'Local Browser Time') {
      try {
        options.timeZone = settings.activeTimezone;
      } catch (e) {
        // Fallback
      }
    }
    
    try {
      return date.toLocaleDateString(undefined, options);
    } catch (e) {
      delete options.timeZone;
      return date.toLocaleDateString(undefined, options);
    }
  };

  // New quick tasks control
  const [newTaskText, setNewTaskText] = useState('');
  const [newPriority, setNewPriority] = useState<'High' | 'Medium' | 'Low'>('Medium');
  const [plannerTab, setPlannerTab] = useState<'daily' | 'weekly' | 'semester'>('daily');

  // Exam list closest calculation
  const [examTimeLeft, setExamTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
    active: boolean;
  }>({ days: 0, hours: 0, minutes: 0, seconds: 0, active: false });

  const upcomingExam = exams.length > 0 ? exams[0] : null;

  useEffect(() => {
    if (!upcomingExam) {
      setExamTimeLeft(prev => ({ ...prev, active: false }));
      return;
    }
    const updateCountdown = () => {
      const examDateTimeStr = `${upcomingExam.date}T${upcomingExam.time || '09:00'}:00`;
      const targetTime = new Date(examDateTimeStr).getTime();
      const now = Date.now();
      const diff = targetTime - now;

      if (diff <= 0) {
        setExamTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0, active: false });
      } else {
        const d = Math.floor(diff / (1000 * 60 * 60 * 24));
        const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const s = Math.floor((diff % (1000 * 60)) / 1000);
        setExamTimeLeft({ days: d, hours: h, minutes: m, seconds: s, active: true });
      }
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [upcomingExam]);

  const handleAddQuickPlannerItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskText.trim()) return;

    if (plannerTab === 'daily') {
      const newTask: DailyTask = {
        id: `quick-dt-${Date.now()}`,
        task: newTaskText,
        date: new Date().toISOString().split('T')[0],
        time: '09:00',
        dayName: 'Today',
        priority: newPriority,
        notes: 'Added from Quick Actions dashboard panel.',
        completedProgress: 0
      };
      setDailyTasks([...dailyTasks, newTask]);
    } else if (plannerTab === 'weekly') {
      const today = new Date();
      const nextWeek = new Date();
      nextWeek.setDate(today.getDate() + 7);
      const newWeekly: WeeklyGoal = {
        id: `quick-wg-${Date.now()}`,
        goal: newTaskText,
        startDate: today.toISOString().split('T')[0],
        endDate: nextWeek.toISOString().split('T')[0],
        dayName: 'Weekly Focus',
        completedProgress: 0
      };
      setWeeklyGoals([...weeklyGoals, newWeekly]);
    } else if (plannerTab === 'semester') {
      const today = new Date();
      const nextMonth = new Date();
      nextMonth.setDate(today.getDate() + 30);
      const newSemesterGoal: SemesterGoal = {
        id: `quick-sg-${Date.now()}`,
        goal: newTaskText,
        deadline: nextMonth.toISOString().split('T')[0],
        completedProgress: 0
      };
      setSemesterGoals([...semesterGoals, newSemesterGoal]);
    }

    setNewTaskText('');
  };

  const toggleTaskComplete = (id: string) => {
    setDailyTasks(
      dailyTasks.map((t) =>
        t.id === id
          ? { ...t, completedProgress: t.completedProgress === 100 ? 0 : 100 }
          : t
      )
    );
  };

  const toggleWeeklyComplete = (id: string) => {
    setWeeklyGoals(
      weeklyGoals.map((w) =>
        w.id === id
          ? { ...w, completedProgress: w.completedProgress === 100 ? 0 : 100 }
          : w
      )
    );
  };

  const toggleSemesterComplete = (id: string) => {
    setSemesterGoals(
      semesterGoals.map((g) =>
        g.id === id
          ? { ...g, completedProgress: g.completedProgress === 100 ? 0 : 100 }
          : g
      )
    );
  };

  // Editable Widget controls
  const [editTargetField, setEditTargetField] = useState<'streak' | 'generalTitle' | null>(null);
  const [editVal, setEditVal] = useState('');
  const [isObsEditing, setIsObsEditing] = useState(false);

  const saveEdit = () => {
    if (editTargetField === 'streak') {
      const parsed = parseInt(editVal);
      if (!isNaN(parsed)) {
        setSettings({ ...settings, studyStreak: parsed });
      }
    } else if (editTargetField === 'generalTitle') {
      setSettings({ ...settings, generalTitle: editVal });
    }
    setEditTargetField(null);
  };

  const renderCircularProgress = (percent: number, size = 110, strokeWidth = 10, color = 'stroke-blue-500') => {
    const textColorClass = color.replace('stroke-', 'text-');
    return (
      <CircularProgress value={percent} size={size} strokeWidth={strokeWidth} colorClass={textColorClass} />
    );
  };

  return (
    <div className="space-y-6">
      {/* Real-time Campus Observatory Header Bar */}
      <div id="top-campus-observatory" className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-2xl p-4 md:p-5 shadow-sm relative overflow-hidden transition-all hover:border-slate-500/25">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-5">
          {/* Day, Date & Live Clock Col */}
          <div className="flex items-center space-x-4 min-w-0 flex-1">
            <div className="p-3 bg-blue-500/10 text-blue-500 rounded-xl flex flex-col items-center justify-center font-mono min-w-[70px] border border-blue-500/20 shrink-0">
              <span className="text-[10px] font-black uppercase tracking-wider text-blue-400">
                {liveTime.toLocaleDateString(undefined, { weekday: 'short' })}
              </span>
              <span className="text-xl font-black text-[var(--text-primary)]">
                {liveTime.getDate()}
              </span>
            </div>
            
            <div className="space-y-1 min-w-0 flex-1">
              <div className="flex items-center space-x-2 text-[10px] text-[var(--text-muted)] font-bold uppercase tracking-wider">
                <Clock size={12} className="text-blue-500 animate-pulse shrink-0" />
                <span>Campus Clock Tower</span>
              </div>
              <div className="flex items-baseline space-x-2.5">
                <h2 className="text-2xl md:text-3xl font-black font-mono tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-[var(--text-primary)] to-blue-400 select-all leading-none">
                  {formatTime(liveTime)}
                </h2>
                <span className="text-xs font-mono text-indigo-400 font-extrabold tracking-tight hidden sm:inline">
                  ({settings.activeTimezone || 'Local Browser Time'})
                </span>
              </div>
              <p className="text-[11px] font-bold text-[var(--text-secondary)]">
                {liveTime.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </p>
            </div>
          </div>

          {/* Location & Micro-status Info Col */}
          <div className="flex flex-col sm:flex-row md:items-center gap-4 border-t md:border-t-0 md:border-l border-[var(--border-main)] pt-4 md:pt-0 md:pl-5 flex-1 min-w-0">
            <div className="space-y-1 min-w-0 flex-1">
              <div className="flex items-center space-x-2 text-[10px] text-[var(--text-muted)] font-black uppercase tracking-wider">
                <MapPin size={12} className="text-rose-500 shrink-0" />
                <span>Campus Location</span>
              </div>
              <h3 className="text-xs font-black text-[var(--text-primary)] truncate flex items-center gap-1.5" title={settings.academicLocation || 'Mechanical Engineering Lab, Zibo Campus'}>
                🏢 {settings.academicLocation || 'Mechanical Engineering Lab, Zibo Campus'}
              </h3>
              
              <div className="flex items-center gap-1.5 mt-1">
                <span className="relative flex h-2 w-2 shrink-0">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span className="text-[10px] font-mono text-[var(--text-muted)] truncate" title={settings.customStatus || '🛠️ Designing SolidWorks CAM Models'}>
                  {settings.customStatus || '🛠️ Designing SolidWorks CAM Models'}
                </span>
              </div>
            </div>

            {/* Quick config options & Edit toggle button */}
            <div className="flex items-center gap-2 self-end sm:self-auto shrink-0 animate-fadeIn">
              <button
                id="toggle-obs-edit-button"
                onClick={() => setIsObsEditing(!isObsEditing)}
                className={`py-1.5 px-3 rounded-lg text-xs font-extrabold uppercase tracking-wider flex items-center gap-1.5 transition-all outline-hidden border cursor-pointer ${
                  isObsEditing 
                    ? 'bg-emerald-600 border-emerald-500 text-white hover:bg-emerald-700' 
                    : 'bg-black/15 border-[var(--border-main)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-black/25'
                }`}
              >
                {isObsEditing ? (
                  <>
                    <Check size={13} />
                    <span>Done</span>
                  </>
                ) : (
                  <>
                    <Edit size={12} />
                    <span>Edit Live Info</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Small Inline Customizer Form that works on spot */}
        {isObsEditing && (
          <div id="obs-inline-editor" className="mt-4 pt-4 border-t border-[var(--border-main)] grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 bg-black/15 p-3 rounded-xl animate-fadeIn animate-duration-150">
            <div className="space-y-1">
              <label className="text-[9px] text-[var(--text-muted)] font-black uppercase tracking-wider block">🏢 Campus/Lab Location</label>
              <input
                id="obs-academic-location-input"
                type="text"
                value={settings.academicLocation || ''}
                onChange={(e) => {
                  const updated = { ...settings, academicLocation: e.target.value };
                  setSettings(updated);
                  StorageService.saveSettings(updated);
                }}
                className="w-full bg-[var(--bg-app)] text-[var(--text-primary)] border border-[var(--border-main)] text-[11px] rounded-lg px-2.5 py-1.5 focus:outline-hidden font-semibold"
                placeholder="Change location..."
              />
            </div>

            <div className="space-y-1">
              <label className="text-[9px] text-[var(--text-muted)] font-black uppercase tracking-wider block">🛠️ Activity/Status Info</label>
              <input
                id="obs-custom-status-input"
                type="text"
                value={settings.customStatus || ''}
                onChange={(e) => {
                  const updated = { ...settings, customStatus: e.target.value };
                  setSettings(updated);
                  StorageService.saveSettings(updated);
                }}
                className="w-full bg-[var(--bg-app)] text-[var(--text-primary)] border border-[var(--border-main)] text-[11px] rounded-lg px-2.5 py-1.5 focus:outline-hidden font-semibold"
                placeholder="Change active status..."
              />
            </div>

            <div className="space-y-1">
              <label className="text-[9px] text-[var(--text-muted)] font-black uppercase tracking-wider block">🌍 Select Timezone & Location Preset</label>
              <select
                id="obs-timezone-select"
                value={settings.activeTimezone || 'Local Browser Time'}
                onChange={(e) => {
                  const val = e.target.value;
                  // If it's a presets update location, if applicable
                  let updatedLocation = settings.academicLocation;
                  if (val === 'Asia/Dhaka') updatedLocation = 'Dhaka Campus, Bangladesh';
                  if (val === 'Asia/Shanghai') updatedLocation = 'Zibo Campus, Shandong';
                  if (val === 'Asia/Kolkata') updatedLocation = 'Kolkata Lab Facility, India';
                  if (val === 'Europe/London') updatedLocation = 'Imperial College Campus, London';
                  if (val === 'America/New_York') updatedLocation = 'Columbia Science Lab, New York';
                  if (val === 'America/Los_Angeles') updatedLocation = 'Stanford Research Suite, California';
                  if (val === 'Asia/Tokyo') updatedLocation = 'Todai Tech Hub, Tokyo';
                  if (val === 'Asia/Singapore') updatedLocation = 'NUS Innovation Block, Singapore';

                  const updated = { 
                    ...settings, 
                    activeTimezone: val,
                    academicLocation: updatedLocation
                  };
                  setSettings(updated);
                  StorageService.saveSettings(updated);
                }}
                className="w-full bg-[var(--bg-app)] text-[var(--text-primary)] border border-[var(--border-main)] text-[11px] rounded-lg px-2 py-1.5 focus:outline-hidden font-semibold font-mono"
              >
                <option value="Local Browser Time">📍 Local Browser Time (Auto)</option>
                <option value="Asia/Dhaka">🇧🇩 Asia/Dhaka (GMT+6)</option>
                <option value="Asia/Shanghai">🇨🇳 Asia/Shanghai (GMT+8)</option>
                <option value="Asia/Kolkata">🇮🇳 Asia/Kolkata (GMT+5:30)</option>
                <option value="Asia/Singapore">🇸🇬 Asia/Singapore (GMT+8)</option>
                <option value="Asia/Tokyo">🇯🇵 Asia/Tokyo (GMT+9)</option>
                <option value="Europe/London">🇬🇧 Europe/London (GMT+1)</option>
                <option value="Europe/Paris">🇫🇷 Europe/Paris (GMT+2)</option>
                <option value="America/New_York">🇺🇸 America/New_York (EST)</option>
                <option value="America/Chicago">🇺🇸 America/Chicago (CST)</option>
                <option value="America/Denver">🇺🇸 America/Denver (MST)</option>
                <option value="America/Los_Angeles">🇺🇸 America/Los_Angeles (PST)</option>
                <option value="UTC">🌌 UTC / GMT Zero</option>
              </select>
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="text-[9px] text-[var(--text-muted)] font-black uppercase tracking-wider block">🌍 Or Custom Timezone IANA</label>
                <button
                  id="detect-timezone-btn"
                  type="button"
                  onClick={() => {
                    try {
                      const detected = Intl.DateTimeFormat().resolvedOptions().timeZone;
                      if (detected) {
                        // Attempt to extract city
                        let cleanCity = detected.split('/').pop()?.replace('_', ' ') || 'Local';
                        const updated = {
                          ...settings,
                          activeTimezone: detected,
                          academicLocation: `Laboratory, ${cleanCity} Campus`
                        };
                        setSettings(updated);
                        StorageService.saveSettings(updated);
                      }
                    } catch (err) {
                      console.error('Failed to auto detect timezone', err);
                    }
                  }}
                  className="text-[8px] text-blue-400 hover:text-blue-500 font-extrabold uppercase tracking-widest cursor-pointer underline decoration-dotted"
                  title="Detects timezone and location city automatically from your actual web browser hardware location"
                >
                  🎯 Auto-Detect
                </button>
              </div>
              <input
                id="obs-timezone-input"
                type="text"
                value={settings.activeTimezone || 'Local Browser Time'}
                onChange={(e) => {
                  const updated = { ...settings, activeTimezone: e.target.value };
                  setSettings(updated);
                  StorageService.saveSettings(updated);
                }}
                className="w-full bg-[var(--bg-app)] text-[var(--text-primary)] border border-[var(--border-main)] text-[11px] rounded-lg px-2.5 py-1.5 focus:outline-hidden font-mono"
                placeholder="e.g. Asia/Dhaka or America/New_York"
              />
            </div>

            <div className="flex flex-col justify-end gap-1.5">
              <span className="text-[9px] text-[var(--text-muted)] font-black uppercase tracking-wider block pb-0.5">⏱️ Display Preferences</span>
              <div className="flex items-center gap-2">
                <button
                  id="obs-toggle-format-button"
                  type="button"
                  onClick={() => {
                    const updatedFormat = settings.timeFormat === '24h' ? '12h' : '24h';
                    const updated = { ...settings, timeFormat: updatedFormat as '12h' | '24h' };
                    setSettings(updated);
                    StorageService.saveSettings(updated);
                  }}
                  className="flex-1 text-[9px] font-black uppercase tracking-wider text-blue-400 bg-blue-500/10 border border-blue-500/20 rounded-md py-1 px-1.5 cursor-pointer text-center hover:bg-blue-500/15"
                >
                  {settings.timeFormat || '12h'} Format
                </button>
                <button
                  id="obs-toggle-seconds-button"
                  type="button"
                  onClick={() => {
                    const updated = { ...settings, showSeconds: !settings.showSeconds };
                    setSettings(updated);
                    StorageService.saveSettings(updated);
                  }}
                  className="flex-1 text-[9px] font-black uppercase tracking-wider text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 rounded-md py-1 px-1.5 cursor-pointer text-center hover:bg-indigo-500/15"
                >
                  Secs {settings.showSeconds ? 'ON' : 'OFF'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Dynamic Header Greeting card */}
      <div className="relative overflow-hidden rounded-2xl bg-linear-to-r from-blue-700 to-indigo-900 border border-indigo-500/20 px-8 py-7 shadow-lg">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 opacity-10 pointer-events-none">
          <GraduationCap size={240} className="text-white" />
        </div>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <span className="bg-amber-400 text-slate-900 text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded-full shadow-xs">
                SDUT Intelligent Production Program
              </span>
              <span className="text-[10px] bg-white/20 text-white px-2 py-0.5 rounded-full font-semibold">
                8-Semester OS
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
              {settings.generalTitle}
            </h1>
            <p className="text-slate-200 text-sm max-w-xl">
              Welcome back, <span className="font-semibold text-white">{profile.name}</span>! Student profile <span className="underline font-mono">{profile.studentId}</span> operates live offline caches.
            </p>
          </div>

          {/* study streak widget editable */}
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-3.5 border border-white/10 flex items-center space-x-3.5 self-start md:self-auto min-w-[200px] shadow-sm relative group">
            <div className="p-3 bg-amber-500/20 text-amber-300 rounded-lg">
              <Flame size={24} className="animate-pulse" />
            </div>
            <div>
              {editTargetField === 'streak' ? (
                <div className="flex items-center space-x-1">
                  <input
                    type="number"
                    value={editVal}
                    onChange={(e) => setEditVal(e.target.value)}
                    className="w-16 bg-slate-800 text-white text-xs border border-blue-500 rounded px-1.5 focus:outline-hidden"
                    autoFocus
                  />
                  <button onClick={saveEdit} className="text-xs bg-emerald-600 text-white rounded px-1.5 py-0.5 font-bold cursor-pointer">OK</button>
                </div>
              ) : (
                <>
                  <div className="text-[10px] text-slate-300 uppercase font-semibold flex items-center justify-between">
                    Study Streak
                    <button
                      onClick={() => { setEditTargetField('streak'); setEditVal(String(settings.studyStreak)); }}
                      className="opacity-0 group-hover:opacity-100 text-[9px] hover:text-white underline cursor-pointer transition-opacity"
                    >
                      Edit
                    </button>
                  </div>
                  <div className="text-xl font-black text-rose-100">{settings.studyStreak} Days</div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
      {/* Bento Grid Analytics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Degree Progress ring */}
        <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 flex items-center justify-between shadow-xs relative">
          <div className="space-y-1">
            <span className="text-xs text-[var(--text-secondary)] font-medium">Degree Roadmap</span>
            <h3 className="text-xl font-bold tracking-tight text-[var(--text-primary)]">Completed</h3>
            <p className="text-[11px] text-[var(--text-muted)]">
              {completedCourses}/{totalCourses} Courses finished
            </p>
            <button
              onClick={() => setCurrentTab('roadmap')}
              className="mt-3 text-xs text-blue-500 font-semibold hover:underline flex items-center cursor-pointer"
            >
              Explore Roadmap <ChevronRight size={14} />
            </button>
          </div>
          {renderCircularProgress(degreeProgressPercent, 80, 8, 'stroke-blue-500')}
        </div>

        {/* Semester Progress ring widget with Custom selector */}
        <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 flex items-center justify-between shadow-xs">
          <div className="space-y-1 flex-1 min-w-0 pr-1">
            <div className="flex items-center justify-between">
              <select
                value={activeSemId}
                onChange={(e) => setActiveSemId(Number(e.target.value))}
                className="bg-transparent border-0 text-xs text-[var(--text-secondary)] font-medium focus:outline-hidden cursor-pointer hover:font-semibold"
              >
                {semesters.map((s) => (
                  <option key={s.id} value={s.id} className="bg-[var(--bg-card)] text-[var(--text-primary)]">
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
            <h3 className="text-xl font-bold tracking-tight text-[var(--text-primary)] truncate">
              {activeSemester ? activeSemester.name : 'Semester'}
            </h3>
            <p className="text-[11px] text-[var(--text-muted)]">
              {activeSemCompleted}/{activeSemTotal} finished courses
            </p>
            <button
              onClick={() => setCurrentTab('roadmap')}
              className="mt-3 text-xs text-indigo-400 font-semibold hover:underline flex items-center cursor-pointer"
            >
              Degree Roadmaps <ChevronRight size={14} />
            </button>
          </div>
          {renderCircularProgress(semesterProgressPercent, 80, 8, 'stroke-indigo-400')}
        </div>

        {/* Milestone Statistics Widget Card */}
        <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 flex flex-col justify-between shadow-xs">
          <div className="flex items-center justify-between border-b pb-2.5 border-[var(--border-main)]">
            <div className="flex items-center space-x-2 text-emerald-400">
              <Target size={18} />
              <span className="text-xs font-semibold">Active Planners</span>
            </div>
            <span className="text-emerald-500 text-[10px] font-bold font-mono">D / W / S</span>
          </div>

          <div className="grid grid-cols-3 gap-2 py-3 text-center">
            <div className="flex flex-col items-center justify-center">
              <span className="text-[9px] text-[var(--text-secondary)] uppercase font-semibold tracking-wider mb-2">Daily</span>
              <CircularProgress value={dailyProgressPercent} size={44} strokeWidth={4} colorClass="text-blue-500" />
            </div>
            <div className="flex flex-col items-center justify-center">
              <span className="text-[9px] text-[var(--text-secondary)] uppercase font-semibold tracking-wider mb-2">Weekly</span>
              <CircularProgress value={weeklyProgressPercent} size={44} strokeWidth={4} colorClass="text-indigo-400" />
            </div>
            <div className="flex flex-col items-center justify-center">
              <span className="text-[9px] text-[var(--text-secondary)] uppercase font-semibold tracking-wider mb-2">Semester</span>
              <CircularProgress value={semGoalsProgressPercent} size={44} strokeWidth={4} colorClass="text-emerald-500" />
            </div>
          </div>

          <button
            onClick={() => setCurrentTab('planner')}
            className="text-xs text-emerald-400 font-semibold hover:underline flex items-center justify-center cursor-pointer pt-1"
          >
            Manage Goals <ChevronRight size={14} />
          </button>
        </div>

        {/* Closest Exam ticker Countdown widget */}
        <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 flex flex-col justify-between shadow-sm min-h-[190px]">
          <div className="flex items-center justify-between border-b pb-2.5 border-[var(--border-main)]">
            <div className="flex items-center space-x-2 text-rose-500">
              <FileClock size={16} className="animate-pulse text-rose-500" />
              <span className="text-xs font-black uppercase tracking-wider text-[var(--text-primary)]">Exam Routine Ticker</span>
            </div>
            <span className="text-rose-500 font-mono text-[8px] tracking-widest bg-rose-500/10 px-2 py-0.5 rounded-full uppercase font-bold animate-pulse">LIVE</span>
          </div>

          <div className="py-3">
            {upcomingExam ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-bold text-[var(--text-primary)] truncate shrink-0 max-w-[140px]" title={upcomingExam.subject}>
                    {upcomingExam.subject}
                  </p>
                  <span className="text-[9px] font-mono text-[var(--text-muted)] bg-black/15 px-2 py-0.5 rounded border border-[var(--border-main)] pb-0.5">
                    Room {upcomingExam.room}
                  </span>
                </div>
                
                {/* 4-Column Ticking boxes */}
                {examTimeLeft.active ? (
                  <div className="grid grid-cols-4 gap-1 text-center font-mono text-[var(--text-primary)]">
                    <div className="bg-black/25 rounded-md p-1.5 border border-[var(--border-main)]">
                      <div className="text-sm font-extrabold text-rose-400 leading-none">{String(examTimeLeft.days).padStart(2, '0')}</div>
                      <div className="text-[7px] text-[var(--text-muted)] uppercase mt-1 font-bold">Days</div>
                    </div>
                    <div className="bg-black/25 rounded-md p-1.5 border border-[var(--border-main)]">
                      <div className="text-sm font-extrabold text-rose-400 leading-none">{String(examTimeLeft.hours).padStart(2, '0')}</div>
                      <div className="text-[7px] text-[var(--text-muted)] uppercase mt-1 font-bold">Hours</div>
                    </div>
                    <div className="bg-black/25 rounded-md p-1.5 border border-[var(--border-main)]">
                      <div className="text-sm font-extrabold text-rose-400 leading-none">{String(examTimeLeft.minutes).padStart(2, '0')}</div>
                      <div className="text-[7px] text-[var(--text-muted)] uppercase mt-1 font-bold">Mins</div>
                    </div>
                    <div className="bg-black/25 rounded-md p-1.5 border border-[var(--border-main)]/70 relative">
                      <div className="text-sm font-extrabold text-rose-500 leading-none animate-pulse">{String(examTimeLeft.seconds).padStart(2, '0')}</div>
                      <div className="text-[7px] text-[var(--text-muted)] uppercase mt-1 font-bold">Secs</div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-2 bg-slate-500/10 text-rose-400 border border-slate-500/15 rounded-md text-[10px] font-bold uppercase font-mono tracking-wider">
                     ✍️ Exam Commencing / Active
                  </div>
                )}
                
                <p className="text-[9px] text-[var(--text-muted)] font-mono text-center">
                  Target: {upcomingExam.date} @ {upcomingExam.time}
                </p>
              </div>
            ) : (
              <div className="text-center py-5 text-[var(--text-muted)] italic text-[11px]">
                No future exam schedules listed inside your Routine.
              </div>
            )}
          </div>

          <button
            onClick={() => setCurrentTab('exams')}
            className="text-xs text-rose-500 hover:text-rose-600 font-bold flex items-center justify-center cursor-pointer pt-2 border-t border-[var(--border-main)] uppercase tracking-wider text-[10px]"
          >
            Go to Routine Planners <ChevronRight size={14} />
          </button>
        </div>
      </div>

      {/* Main Grid: Left column (Planners, Interactive checklists) & Right column (Bookmarks, Notes, Pomodoro action link) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Columns (colspan-2) */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Daily/Weekly/Semester Planners & Interactive Checklists Workspace */}
          <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 shadow-xs">
            <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[var(--border-main)] gap-4">
              <div>
                <h3 className="text-sm sm:text-base font-extrabold text-[var(--text-primary)] flex items-center gap-2">
                  <CalendarCheck className="text-blue-500" size={18} /> Interactive Academic Planners & Checklists
                </h3>
                <p className="text-xs text-[var(--text-muted)]">Track, tick, and complete your learning milestones directly on this dashboard.</p>
              </div>
              
              {/* Separate completion metrics */}
              <div className="flex flex-wrap gap-2">
                <span className="text-[10px] bg-blue-500/10 text-blue-400 font-mono px-2.5 py-1 rounded-full font-bold uppercase tracking-wider">
                  D: {dailyProgressPercent}%
                </span>
                <span className="text-[10px] bg-purple-500/10 text-purple-400 font-mono px-2.5 py-1 rounded-full font-bold uppercase tracking-wider">
                  W: {weeklyProgressPercent}%
                </span>
                <span className="text-[10px] bg-emerald-500/10 text-emerald-400 font-mono px-2.5 py-1 rounded-full font-bold uppercase tracking-wider">
                  S: {semGoalsProgressPercent}%
                </span>
              </div>
            </div>

            {/* Seamless Selector Tabs with Integrated Percentages */}
            <div className="flex border-b border-[var(--border-main)] mt-3">
              <button
                type="button"
                onClick={() => setPlannerTab('daily')}
                className={`flex-1 py-3 text-xs font-bold text-center border-b-2 transition-colors cursor-pointer ${
                  plannerTab === 'daily'
                    ? 'border-blue-500 text-blue-400 font-black bg-blue-500/5'
                    : 'border-transparent text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                }`}
              >
                Daily Tasks ({finishedDailyCount}/{dailyTasks.length})
              </button>
              <button
                type="button"
                onClick={() => setPlannerTab('weekly')}
                className={`flex-1 py-3 text-xs font-bold text-center border-b-2 transition-colors cursor-pointer ${
                  plannerTab === 'weekly'
                    ? 'border-purple-500 text-purple-400 font-black bg-purple-500/5'
                    : 'border-transparent text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                }`}
              >
                Weekly Goals ({finishedWeeklyCount}/{weeklyGoals.length})
              </button>
              <button
                type="button"
                onClick={() => setPlannerTab('semester')}
                className={`flex-1 py-3 text-xs font-bold text-center border-b-2 transition-colors cursor-pointer ${
                  plannerTab === 'semester'
                    ? 'border-emerald-500 text-emerald-400 font-black bg-emerald-500/5'
                    : 'border-transparent text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                }`}
              >
                Semester Benchmarks ({finishedSemGoalsCount}/{semesterGoals.length})
              </button>
            </div>

            {/* Main Interactive Checklist Body */}
            <div className="divide-y divide-[var(--border-main)] mt-2 min-h-[160px] max-h-[380px] overflow-y-auto pr-1">
              {plannerTab === 'daily' && (
                dailyTasks.length > 0 ? (
                  dailyTasks.map((task) => (
                    <div key={task.id} className="flex items-start justify-between py-3.5 group">
                      <div className="flex items-start space-x-3 max-w-[85%]">
                        <button
                          type="button"
                          onClick={() => toggleTaskComplete(task.id)}
                          className={`mt-0.5 w-5 h-5 rounded-md border flex items-center justify-center transition-all cursor-pointer ${
                            task.completedProgress === 100
                              ? 'bg-emerald-500 border-emerald-500 text-white shadow-xs'
                              : 'border-[var(--border-main)] hover:border-blue-500 bg-transparent'
                          }`}
                        >
                          {task.completedProgress === 100 && <span className="text-[10px] font-bold">✓</span>}
                        </button>
                        <div>
                          <p
                            className={`text-xs font-semibold ${
                              task.completedProgress === 100
                                ? 'line-through text-[var(--text-muted)] font-normal'
                                : 'text-[var(--text-primary)]'
                            }`}
                          >
                            {task.task}
                          </p>
                          <p className="text-[10px] text-[var(--text-muted)] mt-0.5 font-mono">
                            Time: {task.time || '09:00'} • Priority:{' '}
                            <span
                              className={
                                task.priority === 'High'
                                  ? 'text-rose-400 font-bold'
                                  : task.priority === 'Medium'
                                  ? 'text-amber-400'
                                  : 'text-slate-400'
                              }
                            >
                              {task.priority || 'Medium'}
                            </span>
                          </p>
                          {task.notes && (
                            <p className="text-[10px] italic text-[var(--text-secondary)] mt-1.5 bg-black/15 px-2.5 py-1 rounded max-w-lg">
                              {task.notes}
                            </p>
                          )}
                        </div>
                      </div>
                      <CircularProgress value={task.completedProgress} size={32} strokeWidth={3} colorClass="text-blue-400" />
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-[var(--text-muted)] italic py-10 text-center">No daily goals yet. Register high priority tasks below!</p>
                )
              )}

              {plannerTab === 'weekly' && (
                weeklyGoals.length > 0 ? (
                  weeklyGoals.map((w) => (
                    <div key={w.id} className="flex items-start justify-between py-3.5 group">
                      <div className="flex items-start space-x-3 max-w-[85%]">
                        <button
                          type="button"
                          onClick={() => toggleWeeklyComplete(w.id)}
                          className={`mt-0.5 w-5 h-5 rounded-md border flex items-center justify-center transition-all cursor-pointer ${
                            w.completedProgress === 100
                              ? 'bg-emerald-500 border-emerald-500 text-white shadow-xs'
                              : 'border-[var(--border-main)] hover:border-purple-500 bg-transparent'
                          }`}
                        >
                          {w.completedProgress === 100 && <span className="text-[10px] font-bold">✓</span>}
                        </button>
                        <div>
                          <p
                            className={`text-xs font-semibold ${
                              w.completedProgress === 100
                                ? 'line-through text-[var(--text-muted)] font-normal'
                                : 'text-[var(--text-primary)]'
                            }`}
                          >
                            {w.goal}
                          </p>
                          <p className="text-[10px] text-[var(--text-muted)] mt-1 font-mono">
                            Span: {w.startDate} to {w.endDate} • {w.dayName || 'Weekly Plan'}
                          </p>
                        </div>
                      </div>
                      <CircularProgress value={w.completedProgress} size={32} strokeWidth={3} colorClass="text-indigo-400" />
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-[var(--text-muted)] italic py-10 text-center">No weekly goals listed. Plan study milestones below!</p>
                )
              )}

              {plannerTab === 'semester' && (
                semesterGoals.length > 0 ? (
                  semesterGoals.map((g) => (
                    <div key={g.id} className="flex items-start justify-between py-3.5 group">
                      <div className="flex items-start space-x-3 max-w-[85%]">
                        <button
                          type="button"
                          onClick={() => toggleSemesterComplete(g.id)}
                          className={`mt-0.5 w-5 h-5 rounded-md border flex items-center justify-center transition-all cursor-pointer ${
                            g.completedProgress === 100
                              ? 'bg-emerald-500 border-emerald-500 text-white shadow-xs'
                              : 'border-[var(--border-main)] hover:border-emerald-500 bg-transparent'
                          }`}
                        >
                          {g.completedProgress === 100 && <span className="text-[10px] font-bold">✓</span>}
                        </button>
                        <div>
                          <p
                            className={`text-xs font-semibold ${
                              g.completedProgress === 100
                                ? 'line-through text-[var(--text-muted)] font-normal'
                                : 'text-[var(--text-primary)]'
                            }`}
                          >
                            {g.goal}
                          </p>
                          <p className="text-[10px] text-[var(--text-muted)] mt-1 font-mono">
                            Target Deadline: {g.deadline}
                          </p>
                        </div>
                      </div>
                      <CircularProgress value={g.completedProgress} size={32} strokeWidth={3} colorClass="text-emerald-400" />
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-[var(--text-muted)] italic py-10 text-center">No semester benchmarks yet. Outline core degree paths below!</p>
                )
              )}
            </div>

            {/* Quick Add Form */}
            <form onSubmit={handleAddQuickPlannerItem} className="mt-4 pt-4 border-t border-[var(--border-main)] flex gap-2">
              <input
                type="text"
                required
                placeholder={
                  plannerTab === 'daily'
                    ? "New daily academic task..."
                    : plannerTab === 'weekly'
                    ? "New weekly curriculum focus..."
                    : "New semester level milestone..."
                }
                value={newTaskText}
                onChange={(e) => setNewTaskText(e.target.value)}
                className="flex-1 bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg px-3 py-2 text-xs text-[var(--text-primary)] focus:outline-hidden focus:border-blue-500"
              />
              {plannerTab === 'daily' && (
                <select
                  value={newPriority}
                  onChange={(e) => setNewPriority(e.target.value as any)}
                  className="bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg px-2 text-xs text-[var(--text-secondary)] focus:outline-hidden cursor-pointer"
                >
                  <option value="High">🔴 High</option>
                  <option value="Medium">🟡 Mid</option>
                  <option value="Low">🟢 Low</option>
                </select>
              )}
              <button
                type="submit"
                className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-3 py-2 text-xs font-extrabold flex items-center gap-1 cursor-pointer transition-colors"
              >
                <Plus size={14} /> Add Goal
              </button>
            </form>
          </div>

          {/* Quick Academic Navigation widgets */}
          <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 shadow-xs">
            <h3 className="text-sm font-bold text-[var(--text-primary)] mb-3 flex items-center gap-2">
              <Sparkles className="text-amber-400" size={16} /> Quick access learning resources
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <button
                onClick={() => { setSelectedCourseId('c-thermodynamics'); setCurrentTab('roadmap'); }}
                className="p-3.5 rounded-lg border border-[var(--border-main)] hover:bg-[var(--bg-card-hover)] text-left cursor-pointer transition-all"
              >
                <span className="text-[10px] text-blue-500 font-bold font-mono">SDUT-ME201</span>
                <p className="text-xs font-bold text-[var(--text-primary)] mt-1">Thermodynamics & Heat Transfer</p>
                <p className="text-[10px] text-[var(--text-muted)] mt-0.5">Explore principles, cycles & Fourier formulations</p>
              </button>
              <button
                onClick={() => { setSelectedCourseId('c-fea'); setCurrentTab('roadmap'); }}
                className="p-3.5 rounded-lg border border-[var(--border-main)] hover:bg-[var(--bg-card-hover)] text-left cursor-pointer transition-all"
              >
                <span className="text-[10px] text-indigo-400 font-bold font-mono">SDUT-ME702</span>
                <p className="text-xs font-bold text-[var(--text-primary)] mt-1">Finite Element Analysis</p>
                <p className="text-[10px] text-[var(--text-muted)] mt-0.5">Stiffness matrices assemblies & Abaqus CAD tasks</p>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          
          {/* Bookmark list and Notes Count summary */}
          <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3.5 border-b border-[var(--border-main)] mb-3.5">
              <h3 className="text-sm font-bold text-[var(--text-primary)] flex items-center gap-2">
                <BookMarked className="text-amber-500" size={16} /> Bookmarked Items
              </h3>
              <span className="text-xs bg-amber-500/10 text-amber-500 border border-amber-500/20 px-2 py-0.5 rounded-full font-bold">
                {bookmarks.length} Total
              </span>
            </div>

            <div className="space-y-2.5">
              {bookmarks.length > 0 ? (
                bookmarks.map((b) => (
                  <div
                    key={b.id}
                    onClick={() => {
                      if (b.type === 'course') {
                        setSelectedCourseId(b.itemId);
                        setCurrentTab('roadmap');
                      } else {
                        setCurrentTab(b.type === 'note' ? 'notes' : 'roadmap');
                      }
                    }}
                    className="flex justify-between items-center p-2.5 rounded-lg border border-[var(--border-main)] hover:bg-[var(--bg-card-hover)] cursor-pointer transition-colors"
                  >
                    <div className="min-w-0 flex-1 pr-2">
                      <p className="text-xs font-bold text-[var(--text-primary)] truncate">{b.title}</p>
                      <p className="text-[10px] text-[var(--text-muted)] truncate">{b.subTitle || b.type}</p>
                    </div>
                    <ChevronRight size={14} className="text-[var(--text-muted)]" />
                  </div>
                ))
              ) : (
                <p className="text-xs text-[var(--text-muted)] italic py-2">No bookmarks found.</p>
              )}
            </div>
          </div>

          {/* Academic Notes Summary widget */}
          <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3.5 border-b border-[var(--border-main)] mb-3.5">
              <h3 className="text-sm font-bold text-[var(--text-primary)] flex items-center gap-2">
                <ClipboardList className="text-emerald-500" size={16} /> Academic Study Notes
              </h3>
              <span className="text-xs bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 px-2 py-0.5 rounded-full font-bold">
                {notes.length} Total
              </span>
            </div>

            <div className="space-y-2.5">
              {notes.slice(0, 3).map((n) => (
                <div
                  key={n.id}
                  onClick={() => setCurrentTab('notes')}
                  className="p-2.5 rounded-lg border border-[var(--border-main)] hover:bg-[var(--bg-card-hover)] cursor-pointer transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[var(--text-primary)] truncate">{n.title}</span>
                    {n.isFavorite && <Heart size={10} className="fill-rose-500 stroke-rose-500" />}
                  </div>
                  <p className="text-[10px] text-[var(--text-muted)] truncate mt-1">
                    {n.content.replace(/[#*`$]/g, '').slice(0, 80)}...
                  </p>
                </div>
              ))}
              <button
                onClick={() => setCurrentTab('notes')}
                className="w-full text-center text-xs text-blue-500 hover:underline font-semibold cursor-pointer pt-2"
              >
                Launch Study Workspace
              </button>
            </div>
          </div>

          {/* Pomodoro Action Prompt Widget */}
          <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 shadow-xs">
            <div className="flex items-center space-x-3 mb-3">
              <div className="p-2.5 bg-rose-500/10 text-rose-500 rounded-lg">
                <Hourglass size={18} className="animate-spin" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-[var(--text-primary)]">Intelligent Study Session</h4>
                <p className="text-[10px] text-[var(--text-muted)]">Build your high-focus sequential timeline</p>
              </div>
            </div>
            <p className="text-[11px] text-[var(--text-secondary)] leading-relaxed">
              Build customizable study sequences configured with automated alarm triggers and cycle logs.
            </p>
            <button
              onClick={() => setCurrentTab('pomodoro')}
              className="mt-4 w-full bg-linear-to-r from-red-600 to-rose-700 hover:from-red-700 hover:to-rose-800 text-white rounded-lg py-2 text-xs font-extrabold cursor-pointer transition-all text-center"
            >
              Start Focus Session
            </button>
          </div>
          
        </div>
      </div>
    </div>
  );
}
