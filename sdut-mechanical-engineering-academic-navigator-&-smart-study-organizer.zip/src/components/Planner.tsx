import React, { useState } from 'react';
import { DailyTask, WeeklyGoal, SemesterGoal } from '../types';
import CircularProgress from './CircularProgress';
import {
  CalendarDays,
  Plus,
  Trash2,
  CheckCircle,
  Clock,
  Gauge,
  Edit2,
  Trash,
  Check
} from 'lucide-react';

interface PlannerProps {
  dailyTasks: DailyTask[];
  setDailyTasks: (t: DailyTask[]) => void;
  weeklyGoals: WeeklyGoal[];
  setWeeklyGoals: (g: WeeklyGoal[]) => void;
  semesterGoals: SemesterGoal[];
  setSemesterGoals: (g: SemesterGoal[]) => void;
}

export default function Planner({
  dailyTasks,
  setDailyTasks,
  weeklyGoals,
  setWeeklyGoals,
  semesterGoals,
  setSemesterGoals
}: PlannerProps) {
  // Tabs for sub-planners
  const [activeTab, setActiveTab] = useState<'daily' | 'weekly' | 'semester'>('daily');

  // Input states for Daily Goals
  const [dailyTask, setDailyTask] = useState('');
  const [dailyTime, setDailyTime] = useState('09:00');
  const [dailyPriority, setDailyPriority] = useState<'High' | 'Medium' | 'Low'>('Medium');
  const [dailyNotes, setDailyNotes] = useState('');
  const [dailyHasAlarm, setDailyHasAlarm] = useState(false);
  const [dailyAlarmTone, setDailyAlarmTone] = useState<'chime' | 'beep' | 'retro' | 'synth'>('chime');

  // Input states for Weekly Goals
  const [weeklyGoal, setWeeklyGoal] = useState('');
  const [weeklyStart, setWeeklyStart] = useState('');
  const [weeklyEnd, setWeeklyEnd] = useState('');

  // Input states for Semester Goals
  const [semesterGoal, setSemesterGoal] = useState('');
  const [semesterDeadline, setSemesterDeadline] = useState('');

  const [notification, setNotification] = useState<string | null>(null);

  const displayNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 2500);
  };

  // Handlers for Daily tasks
  const handleAddDaily = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dailyTask.trim()) return;

    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const currentDayName = days[new Date().getDay()];

    const newTask: DailyTask = {
      id: `dt-${Date.now()}`,
      task: dailyTask,
      date: new Date().toISOString().split('T')[0],
      time: dailyTime,
      dayName: currentDayName,
      priority: dailyPriority,
      notes: dailyNotes,
      completedProgress: 0,
      alarmEnabled: dailyHasAlarm,
      alarmSound: dailyAlarmTone
    };

    setDailyTasks([...dailyTasks, newTask]);
    setDailyTask('');
    setDailyNotes('');
    setDailyHasAlarm(false);
    displayNotification('Added item with customized Academic Alarm configurations!');
  };

  const handleDeleteDaily = (id: string) => {
    setDailyTasks(dailyTasks.filter((t) => t.id !== id));
    displayNotification('Deleted daily task entry.');
  };

  const handleUpdateDailyProgress = (id: string, progress: number) => {
    setDailyTasks(
      dailyTasks.map((t) => (t.id === id ? { ...t, completedProgress: progress } : t))
    );
  };

  // Handlers for Weekly goals
  const handleAddWeekly = (e: React.FormEvent) => {
    e.preventDefault();
    if (!weeklyGoal.trim()) return;

    const newGoal: WeeklyGoal = {
      id: `wg-${Date.now()}`,
      goal: weeklyGoal,
      startDate: weeklyStart || new Date().toISOString().split('T')[0],
      endDate: weeklyEnd || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      dayName: 'Weekly Target',
      completedProgress: 0
    };

    setWeeklyGoals([...weeklyGoals, newGoal]);
    setWeeklyGoal('');
    setWeeklyStart('');
    setWeeklyEnd('');
    displayNotification('Added goal to Weekly Milestone targets!');
  };

  const handleDeleteWeekly = (id: string) => {
    setWeeklyGoals(weeklyGoals.filter((g) => g.id !== id));
    displayNotification('Deleted weekly goal entry.');
  };

  const handleUpdateWeeklyProgress = (id: string, progress: number) => {
    setWeeklyGoals(
      weeklyGoals.map((g) => (g.id === id ? { ...g, completedProgress: progress } : g))
    );
  };

  // Handlers for Semester planning
  const handleAddSemester = (e: React.FormEvent) => {
    e.preventDefault();
    if (!semesterGoal.trim()) return;

    const newSemGoal: SemesterGoal = {
      id: `sg-${Date.now()}`,
      goal: semesterGoal,
      deadline: semesterDeadline || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      completedProgress: 0
    };

    setSemesterGoals([...semesterGoals, newSemGoal]);
    setSemesterGoal('');
    setSemesterDeadline('');
    displayNotification('Added goal to Semester Syllabus milestones!');
  };

  const handleDeleteSemester = (id: string) => {
    setSemesterGoals(semesterGoals.filter((g) => g.id !== id));
    displayNotification('Deleted semester goal entry.');
  };

  const handleUpdateSemProgress = (id: string, progress: number) => {
    setSemesterGoals(
      semesterGoals.map((g) => (g.id === id ? { ...g, completedProgress: progress } : g))
    );
  };

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {notification && (
        <div className="fixed bottom-5 right-5 z-50 bg-blue-600 text-white px-4 py-2.5 rounded-lg shadow-lg text-xs font-bold border border-blue-500 animate-slide-in flex items-center space-x-2">
          <Check size={14} />
          <span>{notification}</span>
        </div>
      )}

      {/* Header section card */}
      <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[var(--text-primary)] flex items-center gap-2">
            <CalendarDays className="text-blue-500" size={24} /> Academic Planners & Milestone Management
          </h1>
          <p className="text-xs text-[var(--text-secondary)]">
            Configure daily study timings, weekly objectives, and long-term semester milestones. Synchronized with live database rings.
          </p>
        </div>

        {/* Multi tab navigator */}
        <div className="flex bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg p-1 text-xs">
          <button
            onClick={() => setActiveTab('daily')}
            className={`px-3.5 py-2 rounded-md font-bold transition-all cursor-pointer ${
              activeTab === 'daily' ? 'bg-blue-600 text-white' : 'text-[var(--text-secondary)] hover:text-white'
            }`}
          >
            Daily Tasks
          </button>
          <button
            onClick={() => setActiveTab('weekly')}
            className={`px-3.5 py-2 rounded-md font-bold transition-all cursor-pointer ${
              activeTab === 'weekly' ? 'bg-blue-600 text-white' : 'text-[var(--text-secondary)] hover:text-white'
            }`}
          >
            Weekly Goals
          </button>
          <button
            onClick={() => setActiveTab('semester')}
            className={`px-3.5 py-2 rounded-md font-bold transition-all cursor-pointer ${
              activeTab === 'semester' ? 'bg-blue-600 text-white' : 'text-[var(--text-secondary)] hover:text-white'
            }`}
          >
            Semester Goals
          </button>
        </div>
      </div>

      {/* Grid workspace editor */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        
        {/* Left column: Add Goals / Tasks Form */}
        <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 shadow-xs space-y-4">
          <h3 className="text-xs font-bold uppercase text-[var(--text-primary)] border-b pb-2 border-[var(--border-main)] flex items-center gap-2">
            <Plus size={14} /> New{' '}
            {activeTab === 'daily' ? 'Daily Task' : activeTab === 'weekly' ? 'Weekly Milestone' : 'Semester Goal'}
          </h3>

          {/* Form: DAILY PLANNER */}
          {activeTab === 'daily' && (
            <form onSubmit={handleAddDaily} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Task Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Study Thermodynamics formulas"
                  value={dailyTask}
                  onChange={(e) => setDailyTask(e.target.value)}
                  className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded-lg px-3 py-2 focus:outline-hidden focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Timings</label>
                  <input
                    type="time"
                    required
                    value={dailyTime}
                    onChange={(e) => setDailyTime(e.target.value)}
                    className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded-lg px-2.5 py-1.5 focus:outline-hidden"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Priority</label>
                  <select
                    value={dailyPriority}
                    onChange={(e) => setDailyPriority(e.target.value as any)}
                    className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-secondary)] rounded-lg px-2 py-1.5 focus:outline-hidden cursor-pointer font-bold"
                  >
                    <option value="High">🟥 High Priority</option>
                    <option value="Medium">🟨 Mid Priority</option>
                    <option value="Low">🟩 Low Priority</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase font-mono">Detailed notes</label>
                <textarea
                  placeholder="Textbook tasks, chapters numbers, laboratory guidelines..."
                  value={dailyNotes}
                  onChange={(e) => setDailyNotes(e.target.value)}
                  rows={2}
                  className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded-lg p-3 focus:outline-hidden"
                />
              </div>

              {/* Study Session Alarm and Timer reminder selections */}
              <div className="p-3 bg-black/15 rounded-lg border border-[var(--border-main)] space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-[var(--text-primary)] uppercase tracking-wide flex items-center gap-1.5">
                    🔔 Set Study Session Alarm
                  </span>
                  <input
                    type="checkbox"
                    checked={dailyHasAlarm}
                    onChange={(e) => setDailyHasAlarm(e.target.checked)}
                    className="w-4 h-4 cursor-pointer accent-blue-500 rounded"
                  />
                </div>
                {dailyHasAlarm && (
                  <div className="space-y-1">
                    <label className="text-[9px] text-[var(--text-muted)] font-bold uppercase tracking-wider block">Alarm sound audio preset</label>
                    <select
                      value={dailyAlarmTone}
                      onChange={(e) => setDailyAlarmTone(e.target.value as any)}
                      className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-secondary)] rounded-lg px-2 py-1 focus:outline-hidden cursor-pointer font-mono font-bold text-[10px]"
                    >
                      <option value="chime">🔔 Traditional Chime (Uplifting)</option>
                      <option value="beep">📢 Digital Beep Alert</option>
                      <option value="retro">👾 8-Bit Retro Pulse</option>
                      <option value="synth">🌌 Cosmic Pad Synthesizer</option>
                    </select>
                  </div>
                )}
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-lg py-2.5 font-bold cursor-pointer transition-colors"
              >
                Insert Task to Ledger
              </button>
            </form>
          )}

          {/* Form: WEEKLY PLANNER */}
          {activeTab === 'weekly' && (
            <form onSubmit={handleAddWeekly} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Weekly Objective</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Complete Ansys FEA strain-stress testing"
                  value={weeklyGoal}
                  onChange={(e) => setWeeklyGoal(e.target.value)}
                  className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded-lg px-3 py-2 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Start Date</label>
                  <input
                    type="date"
                    value={weeklyStart}
                    onChange={(e) => setWeeklyStart(e.target.value)}
                    className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-secondary)] rounded-lg px-2.5 py-1.5 focus:outline-hidden"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">End Date</label>
                  <input
                    type="date"
                    value={weeklyEnd}
                    onChange={(e) => setWeeklyEnd(e.target.value)}
                    className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-secondary)] rounded-lg px-2.5 py-1.5 focus:outline-hidden"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-lg py-2.5 font-bold cursor-pointer transition-colors"
              >
                Set Weekly Goal
              </button>
            </form>
          )}

          {/* Form: SEMESTER PLANNER */}
          {activeTab === 'semester' && (
            <form onSubmit={handleAddSemester} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Long-Term Milestone</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Certifying HSK Level 4 Exam with passing marks"
                  value={semesterGoal}
                  onChange={(e) => setSemesterGoal(e.target.value)}
                  className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded-lg px-3 py-2 focus:outline-hidden"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Deadline Target</label>
                <input
                  type="date"
                  value={semesterDeadline}
                  onChange={(e) => setSemesterDeadline(e.target.value)}
                  className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-secondary)] rounded-lg px-2.5 py-1.5 focus:outline-hidden"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-lg py-2.5 font-bold cursor-pointer"
              >
                Commit Semester Plan
              </button>
            </form>
          )}
        </div>

        {/* Right column: active list view with interactive drag progress indicators (colspan-2) */}
        <div className="lg:col-span-2 space-y-4 bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 sm:p-6 shadow-xs">
          <div className="flex items-center justify-between border-b pb-3 border-[var(--border-main)]">
            <h3 className="text-sm font-black text-[var(--text-primary)] uppercase tracking-wider flex items-center gap-2">
              <Gauge className="text-indigo-400" size={16} /> Registry Planner Items / Progress Timelines
            </h3>
            <span className="text-[10px] bg-indigo-500/10 text-indigo-400 font-bold px-2.5 py-0.5 rounded-full font-mono uppercase">
              {activeTab} scope
            </span>
          </div>

          <div className="space-y-3">
            {/* List: DAILY PLANNER */}
            {activeTab === 'daily' && (
              dailyTasks.length > 0 ? (
                dailyTasks.map((task) => (
                  <div key={task.id} className="p-4 rounded-xl border border-[var(--border-main)] bg-[var(--bg-card-hover)]/35 space-y-3 relative group">
                    <button
                      onClick={() => handleDeleteDaily(task.id)}
                      className="absolute top-4 right-4 text-slate-500 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100 cursor-pointer"
                      title="Delete target task"
                    >
                      <Trash2 size={14} />
                    </button>

                    <div className="pr-4">
                      <div className="flex items-center space-x-2">
                        <span className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded font-mono ${
                          task.priority === 'High' ? 'bg-red-500/10 text-red-500' : task.priority === 'Medium' ? 'bg-amber-500/10 text-amber-500' : 'bg-slate-500/15 text-slate-400'
                        }`}>
                          {task.priority} Priority
                        </span>
                        <span className="text-[10px] text-[var(--text-muted)] font-mono">{task.time} • {task.dayName}</span>
                        {task.alarmEnabled && (
                          <span className="text-[9px] bg-blue-500/15 text-blue-400 font-mono font-bold px-1.5 py-0.5 rounded flex items-center gap-0.5 animate-pulse" title={`Preset sound: ${task.alarmSound}`}>
                            🔔 Alarm Active
                          </span>
                        )}
                      </div>
                      <p className="text-xs font-semibold mt-1.5 text-[var(--text-primary)] leading-snug">{task.task}</p>
                      {task.notes && <p className="text-[11px] text-[var(--text-secondary)] italic mt-1 bg-black/10 p-2 rounded">{task.notes}</p>}
                    </div>

                    {/* Completion Symmetrical slider widgets with Circular Progress */}
                    <div className="flex items-center space-x-3.5 pt-2.5 border-t border-[var(--border-main)]/60">
                      <span className="text-[10px] text-[var(--text-muted)] font-bold uppercase tracking-wider">Progress</span>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        step="10"
                        value={task.completedProgress}
                        onChange={(e) => handleUpdateDailyProgress(task.id, Number(e.target.value))}
                        className="flex-1 cursor-pointer accent-blue-500 bg-slate-100 dark:bg-slate-800 rounded-lg appearance-none h-1.5"
                      />
                      <CircularProgress value={task.completedProgress} size={38} colorClass="text-blue-500" />
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-[var(--text-muted)] italic py-8 text-center">No daily tasks configured. Inject one on the left!</p>
              )
            )}

            {/* List: WEEKLY PLANNER */}
            {activeTab === 'weekly' && (
              weeklyGoals.length > 0 ? (
                weeklyGoals.map((g) => (
                  <div key={g.id} className="p-4 rounded-xl border border-[var(--border-main)] bg-[var(--bg-card-hover)]/35 space-y-3 relative group">
                    <button
                      onClick={() => handleDeleteWeekly(g.id)}
                      className="absolute top-4 right-4 text-slate-500 hover:text-red-500 opacity-0 group-hover:opacity-100 cursor-pointer"
                    >
                      <Trash2 size={14} />
                    </button>

                    <div>
                      <span className="text-[9px] font-mono bg-indigo-500/10 text-indigo-400 px-2.5 py-0.5 rounded font-bold uppercase">Weekly goal</span>
                      <p className="text-xs font-semibold text-[var(--text-primary)] mt-1.5 leading-snug">{g.goal}</p>
                      <p className="text-[10px] text-[var(--text-muted)] mt-1 font-mono">Span: {g.startDate} to {g.endDate}</p>
                    </div>

                    <div className="flex items-center space-x-3.5 pt-2.5 border-t border-[var(--border-main)]/60">
                      <span className="text-[10px] text-[var(--text-muted)] font-bold uppercase tracking-wider">Status</span>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        step="5"
                        value={g.completedProgress}
                        onChange={(e) => handleUpdateWeeklyProgress(g.id, Number(e.target.value))}
                        className="flex-1 cursor-pointer accent-indigo-500 bg-slate-100 dark:bg-slate-800 rounded-lg appearance-none h-1.5"
                      />
                      <CircularProgress value={g.completedProgress} size={38} colorClass="text-indigo-400" />
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-[var(--text-muted)] italic py-8 text-center">No weekly goals set.</p>
              )
            )}

            {/* List: SEMESTER PLANNER */}
            {activeTab === 'semester' && (
              semesterGoals.length > 0 ? (
                semesterGoals.map((sg) => (
                  <div key={sg.id} className="p-4 rounded-xl border border-[var(--border-main)] bg-[var(--bg-card-hover)]/35 space-y-3 relative group">
                    <button
                      onClick={() => handleDeleteSemester(sg.id)}
                      className="absolute top-4 right-4 text-slate-500 hover:text-red-500 opacity-0 group-hover:opacity-100 cursor-pointer"
                    >
                      <Trash2 size={14} />
                    </button>

                    <div>
                      <span className="text-[9px] font-mono bg-emerald-500/10 text-emerald-400 px-2.5 py-0.5 rounded font-bold uppercase">Semester objectives</span>
                      <p className="text-xs font-semibold text-[var(--text-primary)] mt-1.5 leading-snug">{sg.goal}</p>
                      <p className="text-[10px] text-[var(--text-muted)] mt-1 font-mono">Deadline: {sg.deadline}</p>
                    </div>

                    <div className="flex items-center space-x-3.5 pt-2.5 border-t border-[var(--border-main)]/60">
                      <span className="text-[10px] text-[var(--text-muted)] font-bold uppercase tracking-wider">Objective</span>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        step="5"
                        value={sg.completedProgress}
                        onChange={(e) => handleUpdateSemProgress(sg.id, Number(e.target.value))}
                        className="flex-1 cursor-pointer accent-emerald-500 bg-slate-100 dark:bg-slate-800 rounded-lg appearance-none h-1.5"
                      />
                      <CircularProgress value={sg.completedProgress} size={38} colorClass="text-emerald-500" />
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-[var(--text-muted)] italic py-8 text-center">No semester milestones created.</p>
              )
            )}
          </div>
        </div>
        
      </div>
    </div>
  );
}
