import React from 'react';
import {
  LayoutDashboard,
  GraduationCap,
  Map,
  Network,
  CalendarDays,
  FileSpreadsheet,
  AlarmClock,
  BookOpen,
  Bookmark,
  Sliders,
  ChevronLeft,
  ChevronRight,
  Search,
  User,
  LogOut,
  Wifi,
  WifiOff
} from 'lucide-react';
import { StudentProfile, AppSettings } from '../types';

interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  collapsed: boolean;
  setCollapsed: (c: boolean) => void;
  profile: StudentProfile;
  settings: AppSettings;
  onOpenSearch: () => void;
  isOnline: boolean;
  onForceSync: () => void;
}

export default function Sidebar({
  currentTab,
  setCurrentTab,
  collapsed,
  setCollapsed,
  profile,
  settings,
  onOpenSearch,
  isOnline,
  onForceSync
}: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'roadmap', label: 'Degree Roadmap', icon: Map },
    { id: 'knowledge-tree', label: 'Knowledge Tree', icon: Network },
    { id: 'planner', label: 'Daily/Weekly/Semester Planner', icon: CalendarDays },
    { id: 'exams', label: 'Exam Routine', icon: AlarmClock },
    { id: 'notes', label: 'Academic Notes', icon: BookOpen },
    { id: 'bookmarks', label: 'Bookmarks', icon: Bookmark },
    { id: 'ledger', label: 'Student Ledger', icon: FileSpreadsheet },
    { id: 'pomodoro', label: 'Study Sessions', icon: AlarmClock },
    { id: 'settings', label: 'Settings', icon: Sliders }
  ];

  return (
    <div
      className={`fixed top-0 left-0 h-screen transition-all duration-300 z-30 flex flex-col border-r shadow-xl bg-[var(--bg-sidebar)] border-[var(--border-main)] ${
        collapsed ? 'w-20' : 'w-72'
      }`}
    >
      {/* Brand Header */}
      <div className="p-5 flex items-center justify-between border-b border-[var(--border-main)]">
        {!collapsed ? (
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center text-white font-extrabold text-lg shadow-md md:tracking-wider">
              SDUT
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-xs tracking-tight text-[var(--text-primary)]">
                ME ACADEMIC OS
              </span>
              <span className="text-[9px] text-[var(--text-muted)] tracking-wider">
                Intelligent Manufacturing
              </span>
            </div>
          </div>
        ) : (
          <div className="w-10 h-10 mx-auto rounded-lg bg-blue-600 flex items-center justify-center text-white font-extrabold text-lg shadow-md">
            S
          </div>
        )}

        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-1 rounded-md bg-[var(--bg-card)] border border-[var(--border-main)] hover:text-blue-500 text-[var(--text-secondary)] transition-colors"
          title={collapsed ? "Expand Sidebar" : "Collapse Sidebar"}
        >
          {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
        </button>
      </div>

      {/* Online / Offline Sync bar */}
      <div className="px-4 py-2 border-b border-[var(--border-main)] bg-black/10 flex items-center justify-between text-xs">
        <div className="flex items-center space-x-2">
          {isOnline ? (
            <>
              <Wifi size={14} className="text-emerald-500" />
              {!collapsed && <span className="text-emerald-500 font-medium">Cloud Connected</span>}
            </>
          ) : (
            <>
              <WifiOff size={14} className="text-amber-500" />
              {!collapsed && <span className="text-amber-500 font-medium font-mono">Offline Buffer</span>}
            </>
          )}
        </div>
        {!collapsed && settings.cloudSyncEnabled && (
          <button
            onClick={onForceSync}
            className="text-[10px] bg-blue-600 hover:bg-blue-700 text-white rounded px-1.5 py-0.5 font-bold cursor-pointer transition-colors"
            title="Force Cloud Synchronization"
          >
            Sync
          </button>
        )}
      </div>

      {/* Search Bar Button */}
      <div className="p-3">
        <button
          onClick={onOpenSearch}
          className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-lg bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] text-[var(--text-muted)] border border-[var(--border-main)] transition-all cursor-pointer text-left"
        >
          <Search size={16} />
          {!collapsed && <span className="text-xs">Search everywhere...</span>}
        </button>
      </div>

      {/* Navigation menu list */}
      <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setCurrentTab(item.id)}
              className={`w-full flex items-center space-x-3.5 px-3.5 py-3 rounded-lg text-sm font-medium transition-all cursor-pointer ${
                isActive
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/10'
                  : 'text-[var(--text-secondary)] hover:bg-[var(--bg-card)] hover:text-[var(--text-primary)]'
              }`}
            >
              <Icon size={18} className={isActive ? 'text-white' : 'text-[var(--text-muted)]'} />
              {!collapsed && <span>{item.label}</span>}
            </button>
          );
        })}
      </nav>

      {/* Student Profile Quick info Footer card */}
      <div className="p-4 border-t border-[var(--border-main)] bg-black/10">
        <div className="flex items-center space-x-3">
          <img
            src={profile.profilePhoto || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=100"}
            alt="Student Avatar"
            className="w-9 h-9 rounded-full object-cover ring-2 ring-blue-500/50"
            onError={(e) => {
              (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=100";
            }}
          />
          {!collapsed && (
            <div className="flex flex-col min-w-0 flex-1">
              <span className="text-xs font-semibold text-[var(--text-primary)] truncate">
                {profile.name}
              </span>
              <span className="text-[10px] text-[var(--text-muted)] truncate font-mono">
                {profile.studentId}
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
