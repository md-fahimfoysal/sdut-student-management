import React, { useState, useEffect, useRef } from 'react';
import { PomodoroPeriod, PomodoroHistoryItem, Semester } from '../types';
import { StorageService } from '../utils/storage';
import {
  AlarmClock,
  Play,
  Pause,
  RotateCcw,
  Plus,
  Trash2,
  ChevronRight,
  ListCheck,
  CheckCircle,
  Clock,
  Sparkles,
  FileClock,
  BellRing,
  Volume2
} from 'lucide-react';

interface PomodoroProps {
  semesters: Semester[];
  history: PomodoroHistoryItem[];
  setHistory: (h: PomodoroHistoryItem[]) => void;
}

export default function Pomodoro({ semesters, history, setHistory }: PomodoroProps) {
  // Base Course list lookup
  const coursesList = semesters.flatMap((s) => s.courses);

  // States for Period builder setup
  const [selectedCourseId, setSelectedCourseId] = useState(coursesList[0]?.id || 'c-thermodynamics');
  const [studyDuration, setStudyDuration] = useState(45);
  const [breakDuration, setBreakDuration] = useState(10);

  // The active session blocks sequence timeline
  const [sequence, setSequence] = useState<PomodoroPeriod[]>([
    { id: 'p-1', name: 'Fundamentals of Thermodynamics & Heat Transfer', duration: 45, type: 'study' },
    { id: 'p-2', name: 'Strategic Break', duration: 10, type: 'break' },
    { id: 'p-3', name: 'Finite Element Analysis', duration: 90, type: 'study' },
    { id: 'p-4', name: 'Rest / Hydrate Break', duration: 15, type: 'break' }
  ]);

  // Active playing indexes
  const [activeIdx, setActiveIdx] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0); // in seconds
  const [isPlaying, setIsPlaying] = useState(false);
  const [alarmActive, setAlarmActive] = useState(false);

  const audioTimerRef = useRef<number | null>(null);
  const mainTimerRef = useRef<number | null>(null);

  // Synthesized audio context using Web Audio API on-the-fly
  const audioCtxRef = useRef<AudioContext | null>(null);

  const startSynthesizedAlarmBeeps = () => {
    setAlarmActive(true);
    if (audioTimerRef.current) return;

    const runBeep = () => {
      try {
        if (!audioCtxRef.current) {
          audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        }
        const ctx = audioCtxRef.current;
        if (ctx.state === 'suspended') {
          ctx.resume();
        }

        const osc = ctx.createOscillator();
        const gainNode = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, ctx.currentTime); // Standard high pitch clear bell beep A5 pitch

        gainNode.gain.setValueAtTime(0.15, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.6); // smooth rapid decrease fade

        osc.connect(gainNode);
        gainNode.connect(ctx.destination);

        osc.start();
        osc.stop(ctx.currentTime + 0.6);
      } catch (err) {
        console.warn('Audio Synthesis is muted or unsupported in this sandbox context:', err);
      }
    };

    runBeep();
    audioTimerRef.current = window.setInterval(runBeep, 1400); // sound beep periodically
  };

  const stopSynthesizedAlarmBeeps = () => {
    setAlarmActive(false);
    if (audioTimerRef.current) {
      clearInterval(audioTimerRef.current);
      audioTimerRef.current = null;
    }
  };

  // Initialize countdown on index change
  useEffect(() => {
    if (sequence[activeIdx]) {
      setTimeLeft(sequence[activeIdx].duration * 60);
    }
  }, [activeIdx, sequence]);

  // Main timer ticking state logic
  useEffect(() => {
    if (isPlaying && timeLeft > 0) {
      mainTimerRef.current = window.setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(mainTimerRef.current!);
            setIsPlaying(false);
            handlePeriodComplete();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (mainTimerRef.current) {
        clearInterval(mainTimerRef.current);
      }
    }

    return () => {
      if (mainTimerRef.current) clearInterval(mainTimerRef.current);
    };
  }, [isPlaying, timeLeft]);

  // Cleanup synthesizer audio triggers
  useEffect(() => {
    return () => {
      if (audioTimerRef.current) clearInterval(audioTimerRef.current);
    };
  }, []);

  const handlePeriodComplete = () => {
    const activeBlock = sequence[activeIdx];
    if (activeBlock) {
      startSynthesizedAlarmBeeps();

      // If active block was study element, update History logs
      if (activeBlock.type === 'study') {
        const historyItem: PomodoroHistoryItem = {
          id: `hist-${Date.now()}`,
          subject: activeBlock.name,
          duration: activeBlock.duration,
          timestamp: new Date().toISOString(),
          completed: true
        };
        const nextHistory = [historyItem, ...history];
        setHistory(nextHistory);
        StorageService.savePomodoroHistory(nextHistory);
      }
    }
  };

  const handleNextInSequence = () => {
    stopSynthesizedAlarmBeeps();
    if (activeIdx < sequence.length - 1) {
      setActiveIdx(activeIdx + 1);
    } else {
      // Completed last timeline block! Reset to index 0
      setActiveIdx(0);
    }
  };

  const handleSequenceAddStudy = (e: React.FormEvent) => {
    e.preventDefault();
    const targetedCourse = coursesList.find((c) => c.id === selectedCourseId);
    const label = targetedCourse ? targetedCourse.name : 'Unknown Curriculum Course';

    const item: PomodoroPeriod = {
      id: `period-${Date.now()}`,
      name: label,
      duration: studyDuration,
      type: 'study'
    };

    setSequence([...sequence, item]);
  };

  const handleSequenceAddBreak = (e: React.FormEvent) => {
    e.preventDefault();
    const item: PomodoroPeriod = {
      id: `period-${Date.now()}`,
      name: `Strategic Break / Hydration Reset`,
      duration: breakDuration,
      type: 'break'
    };

    setSequence([...sequence, item]);
  };

  const handleDeleteSequenceItem = (id: string, idx: number) => {
    setSequence(sequence.filter((itm) => itm.id !== id));
    if (activeIdx >= idx && activeIdx > 0) {
      setActiveIdx(activeIdx - 1);
    }
  };

  const formatClockTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const totalLengthMinutes = sequence.reduce((sum, s) => sum + s.duration, 0);

  return (
    <div className="space-y-6">
      {/* Title Card */}
      <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[var(--text-primary)] flex items-center gap-2">
            <AlarmClock className="text-blue-500 animate-pulse" size={24} /> Sequential Study Period Builder
          </h1>
          <p className="text-xs text-[var(--text-secondary)]">
            Create multi-stage timelines, alternate high-focus blocks and strategic breaks, and log completions inside historical trackers.
          </p>
        </div>
      </div>

      {/* Alarm Sound Alert Banner Modal overlay if sounding */}
      {alarmActive && (
        <div className="bg-linear-to-r from-red-600 to-rose-700 text-white rounded-xl p-6 shadow-xl border border-red-500/30 flex flex-col sm:flex-row justify-between items-center gap-4 animate-pulse">
          <div className="flex items-center space-x-3.5">
            <BellRing size={28} className="animate-bounce" />
            <div>
              <p className="font-extrabold text-sm uppercase tracking-wider">Focus Period Block Finished!</p>
              <p className="text-xs text-rose-100">Click the button below to turn off sound. Prepare for subsequent modules.</p>
            </div>
          </div>
          <button
            onClick={stopSynthesizedAlarmBeeps}
            className="bg-white text-red-700 px-6 py-2.5 rounded-lg text-xs font-black shadow-md cursor-pointer transition-colors hover:bg-red-50"
          >
            Turn Off Alarm sound
          </button>
        </div>
      )}

      {/* Main Grid: Builder options (Left) + Player display (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left column: Study Timeline Builders (col-span-4) */}
        <div className="lg:col-span-4 space-y-4">
          
          {/* Section: Add custom Study Module */}
          <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 shadow-xs space-y-3.5">
            <h3 className="text-xs font-bold uppercase text-[var(--text-primary)] border-b pb-2 border-[var(--border-main)] flex items-center gap-1.5">
              <Plus size={14} className="text-blue-500" /> Insert Focused Study period
            </h3>

            <div className="space-y-3 t-xs">
              <div className="space-y-1">
                <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Associated Course</label>
                <select
                  value={selectedCourseId}
                  onChange={(e) => setSelectedCourseId(e.target.value)}
                  className="w-full bg-[var(--bg-app)] text-xs text-[var(--text-secondary)] border border-[var(--border-main)] rounded-lg px-2.5 py-2 cursor-pointer focus:outline-hidden"
                >
                  {coursesList.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.code || 'ME'} • {c.name.slice(0, 32)}...
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Target Duration (Minutes)</label>
                <input
                  type="number"
                  min="5"
                  max="180"
                  step="5"
                  value={studyDuration}
                  onChange={(e) => setStudyDuration(Math.max(5, Number(e.target.value)))}
                  className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-xs text-[var(--text-primary)] rounded-lg px-3 py-1.5 focus:outline-hidden"
                />
              </div>

              <button
                onClick={handleSequenceAddStudy}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-lg py-2 text-xs font-bold cursor-pointer transition-colors"
              >
                Insert Study block
              </button>
            </div>
          </div>

          {/* Section: Add custom Break Module */}
          <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 shadow-xs space-y-3.5">
            <h3 className="text-xs font-bold uppercase text-[var(--text-primary)] border-b pb-2 border-[var(--border-main)] flex items-center gap-1.5">
              <Plus size={14} className="text-amber-500" /> Insert Break Block
            </h3>

            <div className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Rest Duration (Minutes)</label>
                <input
                  type="number"
                  min="2"
                  max="60"
                  step="1"
                  value={breakDuration}
                  onChange={(e) => setBreakDuration(Math.max(2, Number(e.target.value)))}
                  className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-xs text-[var(--text-primary)] rounded-lg px-3 py-1.5 focus:outline-hidden"
                />
              </div>

              <button
                onClick={handleSequenceAddBreak}
                className="w-full bg-amber-600 hover:bg-amber-700 text-white rounded-lg py-2 text-xs font-bold cursor-pointer transition-colors"
              >
                Insert Break block
              </button>
            </div>
          </div>
        </div>

        {/* Right workspace player displays (col-span-8) */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Active Timer Display Pane */}
          <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-6 sm:p-8 flex flex-col items-center justify-center text-center shadow-md relative overflow-hidden">
            <div className="absolute top-4 right-4 text-[10px] bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-3 py-1 rounded-full font-bold uppercase">
              Period {activeIdx + 1} of {sequence.length}
            </div>

            {/* active segment labeling details */}
            <div className="space-y-2 max-w-lg mb-6">
              <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded font-mono ${
                sequence[activeIdx]?.type === 'study' ? 'bg-blue-500/10 text-blue-400' : 'bg-amber-500/10 text-amber-500'
              }`}>
                {sequence[activeIdx]?.type === 'study' ? 'Active Focus Period' : 'Recess Break'}
              </span>
              <h2 className="text-base sm:text-lg font-black text-[var(--text-primary)]">
                {sequence[activeIdx]?.name || 'No focus timeline configured'}
              </h2>
            </div>

            {/* Visual countdown clock */}
            <div className="relative flex items-center justify-center mb-6">
              {/* Dynamic decorative spinning concentric circle */}
              <div className={`w-44 h-44 sm:w-52 sm:h-52 rounded-full border-4 flex flex-col items-center justify-center select-none ${
                isPlaying ? 'border-blue-500/40 animate-pulse' : 'border-[var(--border-main)]'
              }`}>
                <span className="text-3xl sm:text-4xl font-mono font-black text-[var(--text-primary)] tracking-tighter">
                  {formatClockTime(timeLeft)}
                </span>
                <span className="text-[10px] text-[var(--text-muted)] font-mono uppercase mt-1">Seconds Left</span>
              </div>
            </div>

            {/* Controls panel */}
            <div className="flex items-center space-x-3.5 pt-4 border-t border-[var(--border-main)] w-full max-w-md justify-center">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className={`p-3.5 rounded-full shadow-lg text-white font-extrabold cursor-pointer transition-transform hover:scale-105 ${
                  isPlaying ? 'bg-amber-600' : 'bg-blue-600'
                }`}
                title={isPlaying ? 'Pause Study Session' : 'Play Session Timer'}
              >
                {isPlaying ? <Pause size={20} /> : <Play size={20} />}
              </button>

              <button
                onClick={() => {
                  setIsPlaying(false);
                  if (sequence[activeIdx]) {
                    setTimeLeft(sequence[activeIdx].duration * 60);
                  }
                }}
                className="p-3 bg-slate-800 hover:text-white hover:bg-slate-700 rounded-full border border-[var(--border-main)] text-[var(--text-secondary)] transition-colors cursor-pointer"
                title="Restart index block"
              >
                <RotateCcw size={16} />
              </button>

              <button
                onClick={handleNextInSequence}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 hover:text-white text-xs border border-[var(--border-main)] font-extrabold text-[var(--text-secondary)] rounded-lg cursor-pointer transition-all uppercase tracking-wider"
              >
                Skip / Next
              </button>
            </div>
          </div>

          {/* Sequence Timeline list */}
          <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 shadow-xs space-y-3.5">
            <div className="flex items-center justify-between border-b pb-3 border-[var(--border-main)]">
              <h3 className="text-xs font-black text-[var(--text-primary)] uppercase tracking-wider flex items-center gap-2">
                <ListCheck className="text-emerald-400" size={16} /> Active Sequence Timeline Playlist
              </h3>
              <span className="text-[10px] bg-slate-800 text-slate-300 font-mono font-bold px-2.5 py-0.5 rounded-full">
                {sequence.length} Periods • {totalLengthMinutes} Mins Total
              </span>
            </div>

            <div className="divide-y divide-[var(--border-main)] max-h-[190px] overflow-y-auto pr-1">
              {sequence.map((itm, index) => {
                const isActive = index === activeIdx;
                return (
                  <div
                    key={itm.id}
                    onClick={() => {
                      setIsPlaying(false);
                      setActiveIdx(index);
                    }}
                    className={`flex items-center justify-between py-2.5 px-2 hover:bg-slate-800/10 cursor-pointer rounded transition-colors ${
                      isActive ? 'bg-blue-600/10 border-l-2 border-blue-500' : ''
                    }`}
                  >
                    <div className="min-w-0 pr-4">
                      <div className="flex items-center space-x-2">
                        <span className="text-[10px] text-slate-500 font-mono">#{index + 1}</span>
                        <span className={`text-[8px] uppercase tracking-wider font-extrabold ${itm.type === 'study' ? 'text-blue-400' : 'text-amber-500'}`}>
                          {itm.type}
                        </span>
                      </div>
                      <p className={`text-xs font-bold truncate mt-0.5 ${isActive ? 'text-blue-400' : 'text-[var(--text-primary)]'}`}>
                        {itm.name}
                      </p>
                    </div>

                    <div className="flex items-center space-x-3.5 flex-shrink-0">
                      <span className="text-xs font-mono font-bold text-[var(--text-secondary)]">{itm.duration}m</span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteSequenceItem(itm.id, index);
                        }}
                        className="text-slate-500 hover:text-red-500 cursor-pointer"
                        title="Delete from list"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Completed history logs panel */}
          <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 shadow-xs space-y-3.5">
            <h3 className="text-xs font-black text-[var(--text-primary)] uppercase tracking-wider flex items-center gap-2">
              <FileClock className="text-indigo-400" size={16} /> Session Completion Logs
            </h3>
            <div className="space-y-2">
              {history.length > 0 ? (
                history.slice(0, 4).map((hist) => (
                  <div key={hist.id} className="flex justify-between items-center bg-black/10 border border-[var(--border-main)] p-2.5 rounded-lg text-xs">
                    <div className="min-w-0 pr-3">
                      <p className="font-bold text-[var(--text-primary)] truncate">{hist.subject}</p>
                      <p className="text-[10px] text-[var(--text-muted)] font-mono">Completed: {new Date(hist.timestamp).toLocaleTimeString()}</p>
                    </div>
                    <span className="text-xs font-mono bg-emerald-500/10 text-emerald-500 font-bold px-2 py-0.5 rounded">
                      +{hist.duration} Min
                    </span>
                  </div>
                ))
              ) : (
                <p className="text-xs text-[var(--text-muted)] italic text-center py-4">No completed study sessions registered in logs yet.</p>
              )}
            </div>
          </div>
          
        </div>
      </div>
    </div>
  );
}
