import React, { useState } from 'react';
import { Semester, Course, Topic, Subtopic } from '../types';
import {
  Network,
  Search,
  ChevronDown,
  ChevronRight,
  CheckCircle2,
  ListCollapse,
  FolderTree,
  Sliders,
  Sparkles
} from 'lucide-react';

interface KnowledgeTreeProps {
  semesters: Semester[];
  setSemesters: (s: Semester[]) => void;
  setCurrentTab: (tab: string) => void;
}

export default function KnowledgeTree({ semesters, setSemesters, setCurrentTab }: KnowledgeTreeProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedNodes, setExpandedNodes] = useState<Record<string, boolean>>({
    'root': true
  });

  const toggleExpand = (id: string) => {
    setExpandedNodes((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Bulk expand/collapse all nodes
  const handleExpandAll = (expand: boolean) => {
    const nextStates: Record<string, boolean> = { 'root': expand };
    semesters.forEach((sem) => {
      nextStates[`sem-${sem.id}`] = expand;
      sem.courses.forEach((c) => {
        nextStates[`course-${c.id}`] = expand;
        c.topics?.forEach((t) => {
          nextStates[`topic-${t.id}`] = expand;
        });
      });
    });
    setExpandedNodes(nextStates);
  };

  const isSearchMatch = (text: string) => {
    if (!searchQuery) return true;
    return text.toLowerCase().includes(searchQuery.toLowerCase());
  };

  // Cross-reactive state check functions
  const handleToggleSubtopic = (semId: number, courseId: string, topicId: string, subId: string) => {
    const updated = semesters.map((sem) => {
      if (sem.id !== semId) return sem;
      const updatedCourses = sem.courses.map((c) => {
        if (c.id !== courseId) return c;
        const updatedTopics = (c.topics || []).map((t) => {
          if (t.id !== topicId) return t;
          const updatedSubs = (t.subtopics || []).map((sub) => {
            if (sub.id === subId) {
              return { ...sub, completed: !sub.completed };
            }
            return sub;
          });
          const allSubsDone = updatedSubs.every((sub) => sub.completed);
          return { ...t, completed: allSubsDone, subtopics: updatedSubs };
        });
        const allTopicsDone = updatedTopics.every((t) => t.completed);
        return { ...c, completed: allTopicsDone, topics: updatedTopics };
      });
      return { ...sem, courses: updatedCourses };
    });
    setSemesters(updated);
  };

  const handleToggleTopic = (semId: number, courseId: string, topicId: string, currentCompleted: boolean) => {
    const nextVal = !currentCompleted;
    const updated = semesters.map((sem) => {
      if (sem.id !== semId) return sem;
      const updatedCourses = sem.courses.map((c) => {
        if (c.id !== courseId) return c;
        const updatedTopics = (c.topics || []).map((t) => {
          if (t.id === topicId) {
            const updatedSubs = (t.subtopics || []).map((s) => ({ ...s, completed: nextVal }));
            return { ...t, completed: nextVal, subtopics: updatedSubs };
          }
          return t;
        });
        const allTopicsDone = updatedTopics.every((t) => t.completed);
        return { ...c, completed: allTopicsDone, topics: updatedTopics };
      });
      return { ...sem, courses: updatedCourses };
    });
    setSemesters(updated);
  };

  const handleToggleCourse = (semId: number, courseId: string, currentCompleted: boolean) => {
    const nextVal = !currentCompleted;
    const updated = semesters.map((sem) => {
      if (sem.id !== semId) return sem;
      const updatedCourses = sem.courses.map((c) => {
        if (c.id === courseId) {
          const updatedTopics = (c.topics || []).map((t) => ({
            ...t,
            completed: nextVal,
            subtopics: (t.subtopics || []).map((sub) => ({ ...sub, completed: nextVal }))
          }));
          return { ...c, completed: nextVal, topics: updatedTopics };
        }
        return c;
      });
      return { ...sem, courses: updatedCourses };
    });
    setSemesters(updated);
  };

  return (
    <div className="space-y-6">
      {/* Header and top info block */}
      <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[var(--text-primary)] flex items-center gap-2">
            <Network className="text-blue-500 animate-pulse" size={24} /> Knowledge Tree Map Explorer
          </h1>
          <p className="text-xs text-[var(--text-secondary)]">
            Explore interactive curriculum layouts of mechanical engineering fields. Toggle completion rings reactively.
          </p>
        </div>

        {/* Global Expand and Collapse controls */}
        <div className="flex bg-[var(--bg-app)] border border-[var(--border-main)] rounded-lg p-1 text-xs space-x-1">
          <button
            onClick={() => handleExpandAll(true)}
            className="px-3 py-1.5 rounded-md font-bold text-[var(--text-secondary)] hover:text-white hover:bg-[var(--bg-card-hover)] cursor-pointer"
          >
            Expand All
          </button>
          <button
            onClick={() => handleExpandAll(false)}
            className="px-3 py-1.5 rounded-md font-bold text-[var(--text-secondary)] hover:text-white hover:bg-[var(--bg-card-hover)] cursor-pointer"
          >
            Collapse All
          </button>
        </div>
      </div>

      {/* Directory Search controls and Settings Workspace redirection banner */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        {/* Left Side: Directory Filters */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-4 shadow-xs space-y-3.5">
            <h3 className="text-xs font-bold text-[var(--text-primary)] uppercase tracking-wider">Search Map Directory</h3>
            <div className="relative">
              <input
                type="text"
                placeholder="Search branches, courses..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-xs text-[var(--text-primary)] rounded-lg pl-8 pr-3 py-2 focus:outline-hidden focus:border-blue-500"
              />
              <Search size={14} className="absolute left-2.5 top-2.5 text-[var(--text-muted)]" />
            </div>
          </div>

          <div className="bg-blue-600/10 border border-blue-500/20 rounded-xl p-5 space-y-3 shadow-xs">
            <div className="flex items-center space-x-2 text-blue-400">
              <Sliders size={16} />
              <span className="text-xs font-bold uppercase tracking-wider">Settings Redirect</span>
            </div>
            <p className="text-[11px] text-[var(--text-secondary)] leading-relaxed">
              Want to **Add, Edit, or Delete** Semesters, Curriculum Courses, Topics, or Subtopics? Focus settings provide physical control panel editors!
            </p>
            <button
              onClick={() => setCurrentTab('settings')}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-lg py-1.5 text-xs font-bold cursor-pointer transition-colors text-center block"
            >
              Launch Manager
            </button>
          </div>
        </div>

        {/* Right Side: Recursive Directory Tree List */}
        <div className="lg:col-span-3 bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 sm:p-6 shadow-xs space-y-4">
          <div className="border-b pb-3.5 border-[var(--border-main)] flex items-center justify-between">
            <h3 className="text-sm font-black text-[var(--text-primary)] uppercase tracking-wider flex items-center gap-2">
              <FolderTree className="text-indigo-400" size={16} /> Mechanical Engineering Branches Directory
            </h3>
            <span className="text-[10px] bg-indigo-500/10 text-indigo-400 px-2.5 py-0.5 rounded-full font-bold">
              Root Level
            </span>
          </div>

          {/* Core Directory Branch */}
          <div className="space-y-2 text-sm">
            
            {/* Tier 1 Parent: Mechanical Engineering root */}
            <div className="border border-[var(--border-main)] rounded-xl overflow-hidden bg-black/10">
              <div
                onClick={() => toggleExpand('root')}
                className="p-4 flex items-center justify-between cursor-pointer hover:bg-[var(--bg-card-hover)]/40 transition-colors"
              >
                <div className="flex items-center space-x-3.5">
                  {expandedNodes['root'] ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                  <div className="p-1.5 bg-blue-600/10 text-blue-500 rounded">
                    <Network size={16} />
                  </div>
                  <span className="font-extrabold text-xs sm:text-sm tracking-tight text-[var(--text-primary)] uppercase">
                    Mechanical Engineering (Intelligent Manufacturing Direction)
                  </span>
                </div>
                <span className="text-[10px] bg-slate-800 text-slate-400 font-bold px-2 py-0.5 rounded-full font-mono">
                  {semesters.length} Semesters Listed
                </span>
              </div>

              {expandedNodes['root'] && (
                <div className="p-4 border-t border-[var(--border-main)] space-y-4">
                  {semesters.map((sem) => {
                    const semKey = `sem-${sem.id}`;
                    const isExpanded = !!expandedNodes[semKey];
                    const countCompleted = sem.courses.filter((c) => c.completed).length;
                    
                    return (
                      <div key={sem.id} className="border-l border-[var(--border-main)] pl-4 space-y-2">
                        {/* Tier 2: Semester */}
                        <div
                          onClick={() => toggleExpand(semKey)}
                          className="flex items-center justify-between py-1.5 cursor-pointer hover:text-blue-500 transition-colors"
                        >
                          <div className="flex items-center space-x-2">
                            {isExpanded ? <ChevronDown size={14} className="text-[var(--text-muted)]" /> : <ChevronRight size={14} className="text-[var(--text-muted)]" />}
                            <span className="font-bold text-xs text-[var(--text-primary)]">{sem.name}</span>
                          </div>
                          <span className="text-[10px] text-[var(--text-muted)] font-mono">
                            {countCompleted}/{sem.courses.length} courses finished
                          </span>
                        </div>

                        {isExpanded && (
                          <div className="pl-4 space-y-3">
                            {sem.courses
                              .filter((course) => isSearchMatch(course.name) || isSearchMatch(course.code || ''))
                              .map((course) => {
                                const courseKey = `course-${course.id}`;
                                const isCourseExpanded = !!expandedNodes[courseKey];
                                return (
                                  <div key={course.id} className="border-l border-[var(--border-main)]/50 pl-4 space-y-2">
                                    {/* Tier 3: Course */}
                                    <div className="flex items-center justify-between py-1">
                                      <div
                                        onClick={() => toggleExpand(courseKey)}
                                        className="flex items-center space-x-2 cursor-pointer hover:text-indigo-400 transition-colors"
                                      >
                                        {isCourseExpanded ? <ChevronDown size={12} className="text-[var(--text-muted)]" /> : <ChevronRight size={12} className="text-[var(--text-muted)]" />}
                                        <span className={`text-xs font-semibold ${course.completed ? 'text-[var(--text-muted)] line-through' : 'text-[var(--text-secondary)]'}`}>
                                          [{course.code || 'ME'}] {course.name}
                                        </span>
                                      </div>

                                      {/* Complete Course button */}
                                      <button
                                        onClick={() => handleToggleCourse(sem.id, course.id, course.completed)}
                                        className={`w-4 h-4 rounded-full flex items-center justify-center border text-[9px] cursor-pointer ${
                                          course.completed ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-[var(--border-main)] hover:border-emerald-500'
                                        }`}
                                      >
                                        ✓
                                      </button>
                                    </div>

                                    {isCourseExpanded && (
                                      <div className="pl-4 space-y-2.5">
                                        {(course.topics || []).map((topic) => {
                                          const topicKey = `topic-${topic.id}`;
                                          const isTopicExpanded = !!expandedNodes[topicKey];
                                          return (
                                            <div key={topic.id} className="border-l border-[var(--border-main)]/30 pl-4 space-y-1.5">
                                              
                                              {/* Tier 4: Topic */}
                                              <div className="flex items-center justify-between">
                                                <div
                                                  onClick={() => toggleExpand(topicKey)}
                                                  className="flex items-center space-x-2 cursor-pointer hover:text-amber-400 text-xs text-[var(--text-secondary)]"
                                                >
                                                  {isTopicExpanded ? <ChevronDown size={10} /> : <ChevronRight size={10} />}
                                                  <span className={topic.completed ? 'line-through text-[var(--text-muted)]' : ''}>
                                                    {topic.name}
                                                  </span>
                                                </div>

                                                <button
                                                  onClick={() => handleToggleTopic(sem.id, course.id, topic.id, topic.completed)}
                                                  className={`w-3.5 h-3.5 rounded-full flex items-center justify-center border text-[8px] cursor-pointer ${
                                                    topic.completed ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-[var(--border-main)]'
                                                  }`}
                                                >
                                                  ✓
                                                </button>
                                              </div>

                                              {/* Tier 5: Subtopics list */}
                                              {isTopicExpanded && (
                                                <div className="pl-3.5 space-y-1 text-xs">
                                                  {(topic.subtopics || []).map((sub) => (
                                                    <div key={sub.id} className="flex items-center justify-between py-0.5 text-[11px] text-[var(--text-muted)]">
                                                      <span className={sub.completed ? 'line-through' : 'text-[var(--text-secondary)]/80'}>{sub.name}</span>
                                                      <button
                                                        onClick={() => handleToggleSubtopic(sem.id, course.id, topic.id, sub.id)}
                                                        className={`w-3 h-3 rounded flex items-center justify-center border text-[7px] cursor-pointer ${
                                                          sub.completed ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-[var(--border-main)]'
                                                        }`}
                                                      >
                                                        {sub.completed ? '✓' : ''}
                                                      </button>
                                                    </div>
                                                  ))}
                                                </div>
                                              )}
                                            </div>
                                          );
                                        })}
                                      </div>
                                    )}
                                  </div>
                                );
                              })}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
            
          </div>
        </div>
      </div>
    </div>
  );
}
