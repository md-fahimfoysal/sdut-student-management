import React, { useState, useEffect } from 'react';
import { ExamRoutine } from '../types';
import { StorageService } from '../utils/storage';
import {
  AlarmClock,
  CalendarDays,
  MapPin,
  Clock,
  Plus,
  Trash2,
  AlertTriangle,
  Sparkles,
  Check
} from 'lucide-react';

interface ExamPlannerProps {
  exams: ExamRoutine[];
  setExams: (e: ExamRoutine[]) => void;
}

export default function ExamPlanner({ exams, setExams }: ExamPlannerProps) {
  // Input builders
  const [sub, setSub] = useState('');
  const [dateVal, setDateVal] = useState('');
  const [timeVal, setTimeVal] = useState('09:00');
  const [roomVal, setRoomVal] = useState('');
  const [notesVal, setNotesVal] = useState('');

  const [notification, setNotification] = useState<string | null>(null);

  const triggerNotif = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  const handleAddExam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sub.trim() || !dateVal) return;

    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const chosenDay = days[new Date(dateVal).getDay()] || 'Week Day';

    const newExam: ExamRoutine = {
      id: `ex-${Date.now()}`,
      subject: sub,
      date: dateVal,
      time: timeVal,
      dayName: chosenDay,
      room: roomVal || 'Standard Lecture Hall',
      notes: notesVal
    };

    const updated = [...exams, newExam].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    setExams(updated);
    StorageService.saveExams(updated);

    // Reset fields
    setSub('');
    setDateVal('');
    setRoomVal('');
    setNotesVal('');
    triggerNotif('Perfect! Exam schedule configured on the database.');
  };

  const handleDeleteExam = (id: string) => {
    const updated = exams.filter((ex) => ex.id !== id);
    setExams(updated);
    StorageService.saveExams(updated);
    triggerNotif('Deleted exam schedule routine.');
  };

  // Live individual ticker component for countdown
  const ExamCountdownTicker = ({ examDate, examTime }: { examDate: string; examTime: string }) => {
    const [secondsRemaining, setSecondsRemaining] = useState<number>(0);

    useEffect(() => {
      const calculate = () => {
        const datetime = `${examDate}T${examTime || '09:00'}:00`;
        const diff = new Date(datetime).getTime() - Date.now();
        setSecondsRemaining(diff > 0 ? Math.floor(diff / 1000) : 0);
      };

      calculate();
      const interval = setInterval(calculate, 1000);
      return () => clearInterval(interval);
    }, [examDate, examTime]);

    if (secondsRemaining <= 0) {
      return (
        <span className="text-xs bg-slate-800 text-slate-400 px-2.5 py-1 rounded-full font-bold font-mono uppercase">
          Finished / In Progress
        </span>
      );
    }

    const days = Math.floor(secondsRemaining / (3600 * 24));
    const hours = Math.floor((secondsRemaining % (3600 * 24)) / 3600);
    const mins = Math.floor((secondsRemaining % 3600) / 60);
    const secs = secondsRemaining % 60;

    return (
      <div className="flex space-x-1.5 text-rose-400 font-mono text-xs font-black bg-rose-500/10 border border-rose-500/20 px-3 py-1.5 rounded-lg">
        <span>{days}d</span>
        <span>•</span>
        <span>{String(hours).padStart(2, '0')}h</span>
        <span>:</span>
        <span>{String(mins).padStart(2, '0')}m</span>
        <span>:</span>
        <span>{String(secs).padStart(2, '0')}s</span>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {notification && (
        <div className="fixed bottom-5 right-5 z-50 bg-blue-600 text-white px-4 py-2.5 rounded-lg shadow-lg text-xs font-bold border border-blue-500 animate-slide-in flex items-center space-x-2">
          <Check size={14} />
          <span>{notification}</span>
        </div>
      )}

      {/* Title Card layout */}
      <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[var(--text-primary)] flex items-center gap-2">
            <AlarmClock className="text-blue-500 animate-bounce" size={24} /> Exam Routine & Live Ticker Countdown
          </h1>
          <p className="text-xs text-[var(--text-secondary)]">
            Schedule upcoming examinations, reference coordinates (room locations, block), and display live countdowns down to seconds.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        
        {/* Left column: Add examination form */}
        <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 shadow-xs space-y-4">
          <h3 className="text-xs font-bold uppercase text-[var(--text-primary)] border-b pb-2 border-[var(--border-main)] flex items-center gap-2">
            <Plus size={14} /> Schedule New Exam
          </h3>

          <form onSubmit={handleAddExam} className="space-y-4 text-xs">
            <div className="space-y-1">
              <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Subject Module Title</label>
              <input
                type="text"
                required
                placeholder="e.g., Fundamentals of Thermodynamics & Heat Transfer"
                value={sub}
                onChange={(e) => setSub(e.target.value)}
                className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded-lg px-3 py-2.5 focus:outline-hidden focus:border-blue-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Date</label>
                <input
                  type="date"
                  required
                  value={dateVal}
                  onChange={(e) => setDateVal(e.target.value)}
                  className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-secondary)] rounded-lg px-2 py-1.5 focus:outline-hidden"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Time Start</label>
                <input
                  type="time"
                  required
                  value={timeVal}
                  onChange={(e) => setTimeVal(e.target.value)}
                  className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-secondary)] rounded-lg px-2 py-1.5 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Lecture Room / CAD Lab Location</label>
              <input
                type="text"
                placeholder="e.g., Building ME Room 402"
                value={roomVal}
                onChange={(e) => setRoomVal(e.target.value)}
                className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded-lg px-3 py-2 focus:outline-hidden"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Important Notes / Allowed Tools</label>
              <textarea
                placeholder="Bring mathematical tables, non-programmable sci-calculator..."
                value={notesVal}
                onChange={(e) => setNotesVal(e.target.value)}
                rows={3}
                className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-[var(--text-primary)] rounded-lg p-3 focus:outline-hidden"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-lg py-2.5 font-bold cursor-pointer transition-all"
            >
              Update Exam Schedules
            </button>
          </form>
        </div>

        {/* Right column: active schedule routines list with individual tickers (colspan-2) */}
        <div className="lg:col-span-2 space-y-4 bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 sm:p-6 shadow-xs">
          <div className="flex items-center justify-between border-b pb-3 border-[var(--border-main)]">
            <h3 className="text-sm font-black text-[var(--text-primary)] uppercase tracking-wider flex items-center gap-2">
              <CalendarDays className="text-indigo-400" size={16} /> Enrolled Exams Schedules Routines
            </h3>
            <span className="text-[10px] bg-slate-800 text-slate-300 font-mono font-bold px-2 py-0.5 rounded-full">
              {exams.length} Configured
            </span>
          </div>

          <div className="space-y-4">
            {exams.length > 0 ? (
              exams.map((ex) => (
                <div key={ex.id} className="p-4 sm:p-5 rounded-xl border border-[var(--border-main)] bg-[var(--bg-card-hover)]/30 hover:bg-[var(--bg-card-hover)]/60 transition-all flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative group">
                  
                  {/* Delete button standard */}
                  <button
                    onClick={() => handleDeleteExam(ex.id)}
                    className="absolute top-4 right-4 text-slate-500 hover:text-rose-500 transition-colors opacity-0 group-hover:opacity-100 cursor-pointer"
                    title="Delete schedule from ledger"
                  >
                    <Trash2 size={14} />
                  </button>

                  <div className="space-y-2 max-w-[70%]">
                    <span className="text-[9px] font-mono font-bold uppercase bg-rose-500/10 text-rose-500 px-2 py-0.5 rounded">
                      {ex.dayName} Series
                    </span>
                    <h4 className="text-xs sm:text-sm font-extrabold text-[var(--text-primary)] leading-tight">
                      {ex.subject}
                    </h4>
                    
                    <div className="flex flex-wrap items-center gap-3 text-[10px] text-[var(--text-secondary)]">
                      <div className="flex items-center space-x-1">
                        <CalendarDays size={12} className="text-blue-400" />
                        <span>{ex.date}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock size={12} className="text-indigo-400" />
                        <span>{ex.time}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <MapPin size={12} className="text-amber-400" />
                        <span>Room {ex.room}</span>
                      </div>
                    </div>

                    {ex.notes && (
                      <p className="text-[11px] text-[var(--text-secondary)] italic bg-black/10 px-3 py-1.5 rounded border-l-2 border-slate-500">
                        Instructions: {ex.notes}
                      </p>
                    )}
                  </div>

                  {/* Individual live count countdown widgets */}
                  <div className="self-end sm:self-auto flex-shrink-0">
                    <ExamCountdownTicker examDate={ex.date} examTime={ex.time} />
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-10 space-y-2">
                <AlertTriangle size={32} className="mx-auto text-[var(--text-muted)] opacity-20" />
                <p className="text-xs text-[var(--text-muted)] italic">No upcoming exams configured in current routine rosters.</p>
              </div>
            )}
          </div>
        </div>
        
      </div>
    </div>
  );
}
