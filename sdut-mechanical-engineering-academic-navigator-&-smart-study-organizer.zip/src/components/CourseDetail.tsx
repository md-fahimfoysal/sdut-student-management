import React from 'react';
import { Course } from '../types';
import {
  Bookmark,
  Check,
  BookMarked,
  BookOpen,
  Award,
  Link,
  ChevronDown,
  Hammer,
  GraduationCap,
  FlaskConical,
  Workflow,
  Atom,
  Terminal,
  FileCheck,
  Calculator,
  Compass
} from 'lucide-react';

interface CourseDetailProps {
  course: Course;
  onToggleCompleted: () => void;
  isBookmarked: boolean;
  onToggleBookmark: () => void;
  onToggleSubtopic: (topicIndex: number, subtopicIndex: number) => void;
}

export default function CourseDetail({
  course,
  onToggleCompleted,
  isBookmarked,
  onToggleBookmark,
  onToggleSubtopic
}: CourseDetailProps) {
  return (
    <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-2xl p-6 shadow-sm space-y-6">
      
      {/* Header and top tools */}
      <div className="flex justify-between items-start border-b pb-4 border-[var(--border-main)]">
        <div>
          <span className="text-[10px] font-mono bg-blue-500/10 text-blue-500 px-2.5 py-1 rounded font-bold uppercase">
            {course.code || 'SDUT Program'}
          </span>
          <h2 className="text-lg font-black text-[var(--text-primary)] mt-2 leading-tight">
            {course.name}
          </h2>
        </div>
        
        {/* Bookmark and Complete tools */}
        <div className="flex items-center space-x-2">
          <button
            onClick={onToggleBookmark}
            className={`p-2 rounded-lg border cursor-pointer transition-all ${
              isBookmarked
                ? 'bg-amber-500/10 border-amber-500/30 text-amber-500 shadow-xs'
                : 'border-[var(--border-main)] hover:text-white hover:bg-[var(--bg-card-hover)] text-[var(--text-muted)]'
            }`}
            title="Toggle Bookmark"
          >
            <Bookmark size={16} className={isBookmarked ? 'fill-amber-500' : ''} />
          </button>
          
          <button
            onClick={onToggleCompleted}
            className={`text-xs font-bold px-3 py-2 rounded-lg cursor-pointer transition-colors flex items-center gap-1.5 ${
              course.completed
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-800 text-[var(--text-secondary)] border border-[var(--border-main)] hover:text-white'
            }`}
          >
            {course.completed ? <Check size={14} /> : null}
            {course.completed ? 'Completed' : 'Mark Completed'}
          </button>
        </div>
      </div>

      {/* Course Core overview details */}
      <div className="space-y-4">
        <div>
          <h3 className="text-[11px] font-extrabold uppercase tracking-wider text-[var(--text-muted)] flex items-center gap-1">
            <Compass size={12} /> Course Overview
          </h3>
          <p className="text-xs text-[var(--text-secondary)] leading-relaxed mt-1">
            {course.overview || 'This syllabus incorporates Shandong University of Technology (SDUT) academic structures.'}
          </p>
        </div>

        {course.purpose && (
          <div>
            <h3 className="text-[11px] font-extrabold uppercase tracking-wider text-[var(--text-muted)] flex items-center gap-1">
              <BookOpen size={12} /> Purpose & Pedagogical Intent
            </h3>
            <p className="text-xs text-[var(--text-secondary)] leading-relaxed mt-1">
              {course.purpose}
            </p>
          </div>
        )}

        {course.importance && (
          <div>
            <h3 className="text-[11px] font-extrabold uppercase tracking-wider text-[var(--text-muted)] flex items-center gap-1">
              <Award size={12} /> Industrial Importance
            </h3>
            <p className="text-xs text-[var(--text-secondary)] mt-1">{course.importance}</p>
          </div>
        )}
      </div>

      {/* Topics and Subtopics checkable checklist section */}
      <div className="border-t pt-5 border-[var(--border-main)] space-y-3">
        <h3 className="text-xs font-black uppercase text-[var(--text-primary)] flex items-center gap-2">
          <FileCheck size={16} className="text-indigo-400" /> Syllabus Topics Checklist
        </h3>
        
        <div className="space-y-3.5 max-h-[280px] overflow-y-auto pr-1">
          {course.topics && course.topics.length > 0 ? (
            course.topics.map((topic, tIdx) => (
              <div key={topic.id} className="bg-black/10 border border-[var(--border-main)] rounded-lg p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[var(--text-primary)]">
                    Unit {tIdx + 1}: {topic.name}
                  </span>
                  <span className="text-[9px] font-mono text-[var(--text-muted)]">
                    {topic.subtopics?.filter(s => s.completed).length || 0}/{topic.subtopics?.length || 0} Complete
                  </span>
                </div>
                
                {topic.subtopics && (
                  <div className="pl-2 space-y-1.5 border-l border-[var(--border-main)]">
                    {topic.subtopics.map((sub, sIdx) => (
                      <button
                        key={sub.id}
                        onClick={() => onToggleSubtopic(tIdx, sIdx)}
                        className="w-full flex items-center text-left text-xs text-[var(--text-secondary)] hover:text-[var(--text-primary)] space-x-2 py-0.5 cursor-pointer"
                      >
                        <div className={`w-3.5 h-3.5 rounded flex items-center justify-center border text-[8px] ${
                          sub.completed ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-[var(--border-main)]'
                        }`}>
                          {sub.completed ? '✓' : ''}
                        </div>
                        <span className={sub.completed ? 'line-through text-[var(--text-muted)]' : ''}>
                          {sub.name}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))
          ) : (
            <p className="text-xs text-[var(--text-muted)] italic">No detailed topics available for this course.</p>
          )}
        </div>
      </div>

      {/* Engineering Specifications Tab panels */}
      <div className="border-t pt-5 border-[var(--border-main)] space-y-4">
        <h3 className="text-xs font-black uppercase text-[var(--text-primary)] flex items-center gap-2">
          <Workflow size={16} className="text-blue-500" /> Engineering & Industrial Specs
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          {/* Labs */}
          {course.laboratories && (
            <div className="bg-slate-800/25 border border-[var(--border-main)] p-3 rounded-lg">
              <span className="text-[10px] text-blue-400 font-bold uppercase tracking-wider flex items-center gap-1">
                <FlaskConical size={11} /> Labs & Experiments
              </span>
              <ul className="list-disc pl-4 space-y-1 text-[11px] text-[var(--text-secondary)] mt-1.5">
                {course.laboratories.map((lab, idx) => (
                  <li key={idx}>{lab}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Software Tools */}
          {course.softwareTools && (
            <div className="bg-slate-800/25 border border-[var(--border-main)] p-3 rounded-lg">
              <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider flex items-center gap-1">
                <Terminal size={11} /> CAD / Software Stacks
              </span>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {course.softwareTools.map((tool, idx) => (
                  <span key={idx} className="bg-amber-500/10 text-amber-500 font-mono text-[10px] px-1.5 py-0.5 rounded border border-amber-500/20">
                    {tool}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Engineering Principles */}
          {course.engineeringPrinciples && (
            <div className="bg-slate-800/25 border border-[var(--border-main)] p-3 rounded-lg">
              <span className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider flex items-center gap-1">
                <Atom size={11} /> Core Mech Principles
              </span>
              <ul className="list-disc pl-4 space-y-1 text-[11px] text-[var(--text-secondary)] mt-1.5">
                {course.engineeringPrinciples.map((pr, idx) => (
                  <li key={idx}>{pr}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Research & Career Options */}
          {(course.careerApplications || course.industrialApplications) && (
            <div className="bg-slate-800/25 border border-[var(--border-main)] p-3 rounded-lg">
              <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider flex items-center gap-1">
                <Workflow size={11} /> Industrial Outlets
              </span>
              <p className="text-[11px] text-[var(--text-secondary)] leading-relaxed mt-1.5">
                {course.careerApplications?.[0] || course.industrialApplications?.[0]}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Equations Section */}
      {course.importantEquations && course.importantEquations.length > 0 && (
        <div className="border-t pt-5 border-[var(--border-main)] space-y-3">
          <h3 className="text-xs font-black uppercase text-[var(--text-primary)] flex items-center gap-2">
            <Calculator className="text-rose-500" size={16} /> Important Engineering Formulations
          </h3>
          <div className="space-y-2">
            {course.importantEquations.map((eq, idx) => (
              <div key={idx} className="bg-[var(--bg-app)] border border-[var(--border-main)] p-3 rounded-lg">
                <span className="text-[10px] font-bold text-rose-400 block">{eq.name}</span>
                <span className="block font-mono text-xs border-y py-1.5 border-[var(--border-main)] my-1.5 text-center text-[var(--text-primary)] bg-black/20 rounded font-semibold">
                  {eq.formula}
                </span>
                <span className="text-[10px] text-[var(--text-muted)] block">{eq.explanation}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Capstone design Projects */}
      {course.projects && course.projects.length > 0 && (
        <div className="border-t pt-5 border-[var(--border-main)] space-y-3">
          <h3 className="text-xs font-black uppercase text-[var(--text-primary)] flex items-center gap-2">
            <Hammer className="text-purple-400" size={16} /> Capstone / Practical Lab Challenges
          </h3>
          {course.projects.map((p, idx) => (
            <div key={idx} className="bg-black/10 border border-[var(--border-main)] p-3 rounded-lg text-xs">
              <span className="font-bold text-[var(--text-primary)] block text-xs">{p.title}</span>
              <p className="text-[11px] text-[var(--text-secondary)] leading-relaxed mt-1">{p.desc}</p>
            </div>
          ))}
        </div>
      )}

      {/* Course textbooks */}
      {course.recommendedBooks && course.recommendedBooks.length > 0 && (
        <div className="border-t pt-5 border-[var(--border-main)] space-y-2">
          <span className="text-[10px] text-[var(--text-muted)] font-extrabold uppercase tracking-wider block">Recommended Reference Books</span>
          <ul className="text-[11px] text-[var(--text-secondary)] space-y-1 list-disc pl-4">
            {course.recommendedBooks.map((b, idx) => (
              <li key={idx}>{b}</li>
            ))}
          </ul>
        </div>
      )}
      
    </div>
  );
}
