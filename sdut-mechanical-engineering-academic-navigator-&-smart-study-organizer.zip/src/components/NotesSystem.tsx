import React, { useState, useEffect, useRef } from 'react';
import { AcademicNote, Semester } from '../types';
import { StorageService } from '../utils/storage';
import {
  BookOpen,
  Search,
  Heart,
  Plus,
  Trash2,
  Save,
  FileText,
  Pin,
  Sparkles,
  Bold,
  Quote,
  Code,
  Check
} from 'lucide-react';

interface NotesSystemProps {
  notes: AcademicNote[];
  setNotes: (n: AcademicNote[]) => void;
  semesters: Semester[];
}

export default function NotesSystem({ notes, setNotes, semesters }: NotesSystemProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterFavorite, setFilterFavorite] = useState(false);
  const [activeNoteId, setActiveNoteId] = useState<string | null>(notes[0]?.id || null);

  const [notification, setNotification] = useState<string | null>(null);

  // Derived courses lookup list
  const coursesList = semesters.flatMap((s) => s.courses);

  const triggerNotif = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 2000);
  };

  // Find active note object
  const activeNote = notes.find((n) => n.id === activeNoteId) || null;

  // Active note semester
  const activeNoteSemester = activeNote
    ? semesters.find((s) => s.courses.some((c) => c.id === activeNote.subjectId)) || semesters[0]
    : null;

  // Handle Note edits and auto-save list
  const updateActiveNoteField = (field: keyof AcademicNote, value: any) => {
    if (!activeNoteId) return;
    const updated = notes.map((n) => {
      if (n.id === activeNoteId) {
        return {
          ...n,
          [field]: value,
          lastModifiedAt: new Date().toISOString()
        };
      }
      return n;
    });
    setNotes(updated);
    StorageService.saveNotes(updated);
  };

  // Create new academic log note
  const handleCreateNote = () => {
    const defaultSubjectId = coursesList[0]?.id || 'custom-note';
    const newNote: AcademicNote = {
      id: `note-${Date.now()}`,
      subjectId: defaultSubjectId,
      title: 'New Study Entry',
      content: `## Quick Lecture Summary\n- Topic details here...\n- Engineering formula references...\n\n### Analytical equations:\n$$q = -k A \\frac{dT}{dx}$$`,
      createdAt: new Date().toISOString(),
      lastModifiedAt: new Date().toISOString(),
      isFavorite: false
    };

    const updated = [newNote, ...notes];
    setNotes(updated);
    StorageService.saveNotes(updated);
    setActiveNoteId(newNote.id);
    triggerNotif('Created new blank note. Auto-save enabled.');
  };

  // Delete note
  const handleDeleteNote = (id: string) => {
    const updated = notes.filter((n) => n.id !== id);
    setNotes(updated);
    StorageService.saveNotes(updated);
    if (activeNoteId === id) {
      setActiveNoteId(updated[0]?.id || null);
    }
    triggerNotif('Deleted study note.');
  };

  // Markdown injection helper toolbar
  const insertMarkdownWrap = (prefix: string, suffix = '') => {
    const textarea = document.getElementById('notes-content-textarea') as HTMLTextAreaElement;
    if (!textarea || !activeNote) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    const selected = text.substring(start, end);
    const replacement = prefix + selected + suffix;

    const nextContent = text.substring(0, start) + replacement + text.substring(end);
    updateActiveNoteField('content', nextContent);

    // Focus ref lock
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + prefix.length, start + prefix.length + selected.length);
    }, 50);
  };

  const filteredNotes = notes.filter((n) => {
    const matchSearch = n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                        n.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchFav = filterFavorite ? n.isFavorite : true;
    return matchSearch && matchFav;
  });

  return (
    <div className="space-y-6">
      {/* Toast alert */}
      {notification && (
        <div className="fixed bottom-5 right-5 z-50 bg-emerald-600 text-white px-4 py-2 rounded-lg shadow-lg text-xs font-bold border border-emerald-500 animate-slide-in flex items-center space-x-2">
          <Check size={14} />
          <span>{notification}</span>
        </div>
      )}

      {/* Header section card */}
      <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[var(--text-primary)] flex items-center gap-2">
            <BookOpen className="text-blue-500 animate-pulse" size={24} /> Intellectual Study Workspace & Notes System
          </h1>
          <p className="text-xs text-[var(--text-secondary)]">
            Compose comprehensive revision files, insert custom formulas, associate topics directly to SDUT courses, and enjoy auto-saves.
          </p>
        </div>

        <button
          onClick={handleCreateNote}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg text-xs font-bold shadow-md cursor-pointer transition-colors flex items-center gap-1.5 self-start md:self-auto"
        >
          <Plus size={16} /> New Revision Note
        </button>
      </div>

      {/* Main split work pane layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch min-h-[550px]">
        
        {/* Left list pane (col-span-4) */}
        <div className="lg:col-span-4 bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-4 shadow-xs flex flex-col space-y-4">
          
          <div className="space-y-3">
            <div className="relative">
              <input
                type="text"
                placeholder="Search notes content..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[var(--bg-app)] border border-[var(--border-main)] text-xs text-[var(--text-primary)] rounded-lg pl-8 pr-3 py-2 focus:outline-hidden"
              />
              <Search size={14} className="absolute left-2.5 top-2.5 text-[var(--text-muted)]" />
            </div>

            <button
              onClick={() => setFilterFavorite(!filterFavorite)}
              className={`w-full text-xs font-bold py-1 px-3 rounded-lg border transition-all flex items-center justify-center gap-1 cursor-pointer ${
                filterFavorite
                  ? 'bg-rose-500/10 border-rose-500/30 text-rose-500'
                  : 'border-[var(--border-main)] text-[var(--text-secondary)] hover:text-white'
              }`}
            >
              <Heart size={12} className={filterFavorite ? 'fill-rose-500' : ''} />
              {filterFavorite ? 'Showing Favorites Only' : 'Filter Favorites'}
            </button>
          </div>

          {/* List of notes */}
          <div className="flex-1 overflow-y-auto space-y-2 pr-1 max-h-[420px]">
            {filteredNotes.length > 0 ? (
              filteredNotes.map((note) => {
                const isSelected = note.id === activeNoteId;
                const associatedCourse = coursesList.find((c) => c.id === note.subjectId);
                const associatedSemester = semesters.find((s) => s.courses.some((c) => c.id === note.subjectId));
                return (
                  <div
                    key={note.id}
                    onClick={() => setActiveNoteId(note.id)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer relative group ${
                      isSelected
                        ? 'border-blue-500 bg-blue-500/5 shadow-inner'
                        : 'border-[var(--border-main)] bg-[var(--bg-card-hover)]/25 hover:bg-[var(--bg-card-hover)]'
                    }`}
                  >
                    {/* Delete button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteNote(note.id);
                      }}
                      className="absolute top-3 right-3 text-slate-500 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                    >
                      <Trash2 size={12} />
                    </button>

                    <div className="pr-4 space-y-1">
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-[9px] font-mono text-slate-400 truncate max-w-[85%]">
                          {associatedSemester ? `${associatedSemester.name} • ` : ''}
                          {associatedCourse ? associatedCourse.code : 'SDUT'}
                        </span>
                        {note.isFavorite && <Heart size={10} className="fill-rose-500 stroke-rose-500 shrink-0" />}
                      </div>
                      <h4 className="text-xs font-bold text-[var(--text-primary)] truncate leading-tight">
                        {note.title || 'Untitled Note'}
                      </h4>
                      <p className="text-[10px] text-[var(--text-muted)] truncate">
                        {note.content.replace(/[#*`$\\]/g, '').slice(0, 60) || 'No text write...'}
                      </p>
                      <div className="text-[9px] text-[var(--text-muted)] font-mono pt-1 text-right">
                        Last modified: {new Date(note.lastModifiedAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <p className="text-xs text-[var(--text-muted)] italic py-8 text-center">No revision files matched.</p>
            )}
          </div>
        </div>

        {/* Right workspace: Markdown-capable rich text field (col-span-8) */}
        <div className="lg:col-span-8 bg-[var(--bg-card)] border border-[var(--border-main)] rounded-xl p-5 shadow-xs flex flex-col h-full">
          {activeNote ? (
            <div className="space-y-4 flex flex-col h-full flex-1">
              {/* Header options inside active note */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b pb-3 border-[var(--border-main)]">
                <div className="flex-1 space-y-2">
                  <input
                    type="text"
                    value={activeNote.title}
                    onChange={(e) => updateActiveNoteField('title', e.target.value)}
                    className="w-full bg-transparent border-0 text-sm font-black text-[var(--text-primary)] focus:outline-hidden"
                    placeholder="Enter Note title here..."
                  />
                  
                  {/* Subject and Semester Dual Interactive Selectors */}
                  <div className="flex flex-col sm:flex-row gap-2 bg-black/15 p-2.5 rounded-lg border border-[var(--border-main)]">
                    <div className="flex items-center gap-1.5 flex-1 min-w-[130px]">
                      <span className="text-[10px] text-blue-400 font-extrabold font-mono uppercase shrink-0">Sem:</span>
                      <select
                        value={activeNoteSemester?.id || ''}
                        onChange={(e) => {
                          const semId = parseInt(e.target.value);
                          const chosenSem = semesters.find((s) => s.id === semId);
                          if (chosenSem && chosenSem.courses.length > 0) {
                            updateActiveNoteField('subjectId', chosenSem.courses[0].id);
                          } else {
                            updateActiveNoteField('subjectId', '');
                          }
                        }}
                        className="bg-[var(--bg-app)] border border-[var(--border-main)] text-[11px] text-[var(--text-primary)] rounded px-1.5 py-0.5 focus:outline-hidden font-bold cursor-pointer w-full"
                      >
                        {semesters.map((s) => (
                          <option key={s.id} value={s.id} className="bg-[var(--bg-card)]">
                            {s.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="flex items-center gap-1.5 flex-1 min-w-[170px]">
                      <span className="text-[10px] text-indigo-400 font-extrabold font-mono uppercase shrink-0">Course:</span>
                      <select
                        value={activeNote.subjectId || ''}
                        onChange={(e) => updateActiveNoteField('subjectId', e.target.value)}
                        className="bg-[var(--bg-app)] border border-[var(--border-main)] text-[11px] text-[var(--text-primary)] rounded px-1.5 py-0.5 focus:outline-hidden font-bold cursor-pointer w-full"
                      >
                        {activeNoteSemester && activeNoteSemester.courses.length > 0 ? (
                          activeNoteSemester.courses.map((c) => (
                            <option key={c.id} value={c.id} className="bg-[var(--bg-card)]">
                              {c.code || 'SDUT'} • {c.name}
                            </option>
                          ))
                        ) : (
                          <option value="">-- No Courses in Term --</option>
                        )}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Favorite option and auto-save alert */}
                <div className="flex items-center space-x-2 flex-shrink-0 self-end sm:self-auto">
                  <span className="text-[9px] text-emerald-500 font-mono font-bold uppercase tracking-wider bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                    Auto-Saved Local
                  </span>
                  
                  <button
                    onClick={() => updateActiveNoteField('isFavorite', !activeNote.isFavorite)}
                    className={`p-2 rounded-lg border cursor-pointer transition-colors ${
                      activeNote.isFavorite
                        ? 'bg-rose-500/10 border-rose-500/35 text-rose-500 shadow-xs'
                        : 'border-[var(--border-main)] text-[var(--text-muted)] hover:text-white'
                    }`}
                  >
                    <Heart size={14} className={activeNote.isFavorite ? 'fill-rose-500' : ''} />
                  </button>
                </div>
              </div>

              {/* Simple Markdown editor panel helper toolbar */}
              <div className="flex items-center space-x-1.5 bg-black/15 p-1 rounded-lg border border-[var(--border-main)]">
                <button
                  onClick={() => insertMarkdownWrap('**', '**')}
                  className="p-1 px-2 hover:bg-[var(--bg-card-hover)] hover:text-white rounded text-[10px] font-bold text-[var(--text-secondary)] flex items-center gap-0.5 cursor-pointer"
                  title="Bold text"
                >
                  <Bold size={11} /> Bold
                </button>
                <span className="text-[var(--text-muted)]">|</span>
                <button
                  onClick={() => insertMarkdownWrap('> ', '')}
                  className="p-1 px-2 hover:bg-[var(--bg-card-hover)] hover:text-white rounded text-[10px] font-bold text-[var(--text-secondary)] flex items-center gap-0.5 cursor-pointer"
                  title="Incorporate quote block"
                >
                  <Quote size={11} /> Blockquote
                </button>
                <span className="text-[var(--text-muted)]">|</span>
                <button
                  onClick={() => insertMarkdownWrap('`', '`')}
                  className="p-1 px-2 hover:bg-[var(--bg-card-hover)] hover:text-white rounded text-[10px] font-bold text-[var(--text-secondary)] flex items-center gap-0.5 cursor-pointer"
                  title="Code snippets formatting"
                >
                  <Code size={11} /> Code
                </button>
                <span className="text-[var(--text-muted)]">|</span>
                <button
                  onClick={() => insertMarkdownWrap('$$', '$$')}
                  className="p-1 px-2 hover:bg-[var(--bg-card-hover)] hover:text-white rounded text-[10px] font-mono font-normal text-rose-400 flex items-center gap-0.5 cursor-pointer"
                  title="Latex formatted equation block"
                >
                  $$ LaTeX Equation
                </button>
              </div>

              {/* Main notes textarea content */}
              <div className="flex-1 flex flex-col min-h-[300px]">
                <textarea
                  id="notes-content-textarea"
                  value={activeNote.content}
                  onChange={(e) => updateActiveNoteField('content', e.target.value)}
                  className="w-full h-full min-h-[300px] flex-1 bg-[var(--bg-app)] text-[var(--text-primary)] text-xs border border-[var(--border-main)] rounded-lg p-4 font-mono focus:outline-hidden focus:border-blue-500 resize-none leading-relaxed"
                  placeholder="Draft comprehensive Markdown revision parameters..."
                />
              </div>

              <div className="text-[9px] text-[var(--text-muted)] italic text-right">
                Synthesized Markdown content is saved instantaneously inside standard IndexedDB database caches.
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-xs text-[var(--text-muted)] italic min-h-[300px]">
              <FileText size={40} className="text-[var(--text-muted)] opacity-20 mb-3" />
              Open existing notes from the sidebar list or click the header menu "+ New Note" to initiate composing revision parameters.
            </div>
          )}
        </div>
        
      </div>
    </div>
  );
}
