import React from 'react';

interface CircularProgressProps {
  value: number; // 0 to 100
  size?: number; // size of the circle
  strokeWidth?: number;
  colorClass?: string; // Tailwind color class
}

export default function CircularProgress({
  value,
  size = 44,
  strokeWidth = 4,
  colorClass = 'text-blue-500'
}: CircularProgressProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const clampedValue = Math.min(100, Math.max(0, value));
  const strokeDashoffset = circumference - (clampedValue / 100) * circumference;

  return (
    <div className="relative flex items-center justify-center select-none shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="transform -rotate-90">
        {/* Gray Background Track */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="transparent"
          stroke="currentColor"
          strokeWidth={strokeWidth}
          className="text-slate-200 dark:text-slate-800 opacity-60"
        />
        {/* Colored Progress Ring */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="transparent"
          stroke="currentColor"
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          className={`transition-all duration-700 ease-in-out ${colorClass}`}
        />
      </svg>
      {/* Center Percentage Display */}
      <span className="absolute text-[9px] font-black font-mono tracking-tighter text-[var(--text-primary)]">
        {Math.round(clampedValue)}%
      </span>
    </div>
  );
}
