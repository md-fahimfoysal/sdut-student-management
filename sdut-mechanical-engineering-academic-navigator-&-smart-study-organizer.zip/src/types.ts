export interface StudentProfile {
  name: string;
  studentId: string;
  universityId: string;
  passportNumber: string;
  email: string;
  phone: string;
  address: string;
  emergencyContact: string;
  parentInfo: string;
  scholarshipInfo: string;
  admissionInfo: string;
  academicStatus: string;
  profilePhoto: string;
}

export interface Subtopic {
  id: string;
  name: string;
  completed: boolean;
}

export interface Topic {
  id: string;
  name: string;
  completed: boolean;
  subtopics: Subtopic[];
}

export interface Course {
  id: string;
  name: string;
  code?: string;
  completed: boolean;
  // Detail elements
  overview?: string;
  purpose?: string;
  learningOutcomes?: string[];
  importance?: string;
  topics: Topic[];
  engineeringPrinciples?: string[];
  mathematicalFoundations?: string[];
  laboratories?: string[];
  softwareTools?: string[];
  industrialApplications?: string[];
  researchApplications?: string[];
  careerApplications?: string[];
  projects?: { title: string; desc: string }[];
  recommendedBooks?: string[];
  importantEquations?: { name: string; formula: string; explanation: string }[];
  learningPath?: string[];
}

export interface Semester {
  id: number;
  name: string;
  courses: Course[];
}

export interface DailyTask {
  id: string;
  task: string;
  date: string;
  time: string;
  dayName: string;
  priority: 'High' | 'Medium' | 'Low';
  notes: string;
  completedProgress: number; // 0 to 100
  alarmEnabled?: boolean;
  alarmSound?: 'chime' | 'beep' | 'retro' | 'synth';
  alarmTriggered?: boolean;
}

export interface WeeklyGoal {
  id: string;
  goal: string;
  startDate: string;
  endDate: string;
  dayName: string;
  completedProgress: number; // 0 to 100
}

export interface SemesterGoal {
  id: string;
  goal: string;
  deadline: string;
  completedProgress: number; // 0 to 100
}

export interface ExamRoutine {
  id: string;
  subject: string;
  date: string;
  time: string;
  dayName: string;
  room: string;
  notes: string;
}

export interface AcademicNote {
  id: string;
  subjectId: string; // Course ID or generic
  topicId?: string;
  title: string;
  content: string;
  createdAt: string;
  lastModifiedAt: string;
  isFavorite: boolean;
}

export interface Bookmark {
  id: string;
  type: 'course' | 'topic' | 'note' | 'equation' | 'project';
  itemId: string;
  title: string;
  subTitle?: string;
  extraData?: any;
}

export interface PomodoroPeriod {
  id: string;
  name: string;
  duration: number; // minutes
  type: 'study' | 'break';
}

export interface PomodoroHistoryItem {
  id: string;
  subject: string;
  duration: number;
  timestamp: string;
  completed: boolean;
}

export type ThemeType =
  | 'clean-minimalism'
  | 'elegant-dark'
  | 'white-academic'
  | 'mint-green'
  | 'ocean-blue'
  | 'cyber-cyan'
  | 'deep-navy'
  | 'crimson-red'
  | 'sunset-orange'
  | 'galaxy-purple'
  | 'titanium-black'
  | 'golden-executive'
  | 'forest-green'
  | 'nordic-frost'
  | 'sakura-pink'
  | 'royal-emerald'
  | 'retro-amber'
  | 'ivory-warm'
  | 'nordic-light'
  | 'sage-ceramic'
  | 'minimal-grey';

export interface AppSettings {
  generalTitle: string;
  theme: ThemeType;
  studyStreak: number;
  lastStudyDate: string;
  cloudSyncEnabled: boolean;
  cloudSyncUser: string;
  cloudSyncLastSuccess: string;
  notificationsEnabled: boolean;
  cloudProvider?: 'none' | 'google-drive' | 'onedrive' | 'dropbox' | 'firebase';
  cloudSyncStatus?: 'idle' | 'syncing' | 'synced' | 'offline-backlog';
  academicLocation?: string;
  timeFormat?: '12h' | '24h';
  showSeconds?: boolean;
  activeTimezone?: string;
  customStatus?: string;
}
