import {
  StudentProfile,
  Semester,
  DailyTask,
  WeeklyGoal,
  SemesterGoal,
  ExamRoutine,
  AcademicNote,
  Bookmark,
  PomodoroHistoryItem,
  AppSettings,
  ThemeType
} from '../types';
import { INITIAL_SEMESTERS } from '../data/courses';

const STORAGE_KEYS = {
  PROFILE: 'sdut_me_profile',
  SEMESTERS: 'sdut_me_semesters',
  DAILY_TASKS: 'sdut_me_daily_tasks',
  WEEKLY_GOALS: 'sdut_me_weekly_goals',
  SEMESTER_GOALS: 'sdut_me_semester_goals',
  EXAMS: 'sdut_me_exams',
  NOTES: 'sdut_me_notes',
  BOOKMARKS: 'sdut_me_bookmarks',
  POMODORO_HISTORY: 'sdut_me_pomodoro_history',
  SETTINGS: 'sdut_me_settings'
};

const DEFAULT_PROFILE: StudentProfile = {
  name: "Fahim Foysal",
  studentId: "SDUT-ME-2026-9812",
  universityId: "120603099",
  passportNumber: "E0491823H",
  email: "fahimfoysal1759hdp@gmail.com",
  phone: "+86 156 8901 2345",
  address: "Shandong University of Technology, 12 Zhangzhou Road, Zibo, Shandong, China",
  emergencyContact: "+880 1712 345678 (Parent - Dhaka, BD)",
  parentInfo: "Parent: Mohammed Foysal; Residence: Dhaka, Bangladesh",
  scholarshipInfo: "Shandong Provincial Government Full Scholarship (Outstanding Academic Record)",
  admissionInfo: "Admitted in Sept 2023, School of Mechanical Engineering (Intelligent Manufacturing Direction)",
  academicStatus: "Active Standard / Enrollment Certified",
  profilePhoto: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=200"
};

const DEFAULT_SETTINGS: AppSettings = {
  generalTitle: "SDUT Academic OS",
  theme: 'clean-minimalism',
  studyStreak: 5,
  lastStudyDate: new Date().toISOString().split('T')[0],
  cloudSyncEnabled: true,
  cloudSyncUser: "fahimfoysal1759hdp@gmail.com",
  cloudSyncLastSuccess: new Date().toISOString(),
  notificationsEnabled: true,
  cloudProvider: 'google-drive',
  cloudSyncStatus: 'synced',
  academicLocation: "Mechanical Engineering Lab, Zibo Campus",
  timeFormat: '12h',
  showSeconds: true,
  activeTimezone: 'Local Browser Time',
  customStatus: "🛠️ Analyzing Micro-Machining G-Codes"
};

const DEFAULT_DAILY_TASKS: DailyTask[] = [
  {
    id: 'dt-1',
    task: 'Solve Fourier’s Law heat resistance calculations',
    date: new Date().toISOString().split('T')[0],
    time: '14:30',
    dayName: 'Today',
    priority: 'High',
    notes: 'Thermodynamics textbook chapter 4 exercises 1-5.',
    completedProgress: 80
  },
  {
    id: 'dt-2',
    task: 'Configure master G-code toolpath boundaries in SolidWorks CAM',
    date: new Date().toISOString().split('T')[0],
    time: '10:00',
    dayName: 'Today',
    priority: 'Medium',
    notes: 'Create contour mill simulation for aluminum adapter.',
    completedProgress: 100
  },
  {
    id: 'dt-3',
    task: 'Practise HSK Level 4 writing drills',
    date: new Date().toISOString().split('T')[0],
    time: '16:00',
    dayName: 'Today',
    priority: 'Low',
    notes: 'Focus on conditional particles (ruguo... dehua).',
    completedProgress: 20
  }
];

const DEFAULT_WEEKLY_GOALS: WeeklyGoal[] = [
  {
    id: 'wg-1',
    goal: 'Study Finite Element Analysis Global Stiffness matrices assemblies',
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + 6 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    dayName: 'Weekly',
    completedProgress: 60
  },
  {
    id: 'wg-2',
    goal: 'Complete Level 4 HSK Vocabularies flashcard list (units 1-5)',
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + 6 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    dayName: 'Weekly',
    completedProgress: 45
  }
];

const DEFAULT_SEMESTER_GOALS: SemesterGoal[] = [
  {
    id: 'sg-1',
    goal: 'Formulate Capstone Gripper Delta model simulation layout',
    deadline: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    completedProgress: 35
  },
  {
    id: 'sg-2',
    goal: 'Prepare and pass HSK 4 official certification with score >240',
    deadline: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    completedProgress: 75
  }
];

const DEFAULT_EXAMS: ExamRoutine[] = [
  {
    id: 'ex-1',
    subject: 'Fundamentals of Thermodynamics & Heat Transfer',
    date: new Date(Date.now() + 12 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    time: '09:00',
    dayName: 'Tuesday',
    room: 'ME Building - Lecture Room 402',
    notes: 'Bring calculator, heat properties table sheets, and dynamic templates.'
  },
  {
    id: 'ex-2',
    subject: 'Finite Element Analysis (Mids Exam)',
    date: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    time: '14:00',
    dayName: 'Wednesday',
    room: 'Information Science Building - CAD Room 101',
    notes: 'Ansys modeling tasks (30%) + Theoretical derivations (70%).'
  }
];

const DEFAULT_NOTES: AcademicNote[] = [
  {
    id: 'note-1',
    subjectId: 'c-thermodynamics',
    topicId: 't-therm-t1',
    title: 'Fourier’s Law Concept Recap',
    content: `## Heat Conduction Foundations
Conduction heat transfer is mathematically described by **Fourier's Law**:

$$q_x = -k A \\frac{dT}{dx}$$

Where:
- $q_x$ = Heat transfer rate (W)
- $k$ = Thermal conductivity (W/m·K)
- $A$ = Surface cross-sectional area ($m^2$)
- $\\frac{dT}{dx}$ = Local Temperature gradient (K/m)

### Key Intuition:
1. The **negative sign** enforces the 2nd law of thermodynamics (heat flows down the temperature gradient, i.e., from hot to dry/cold environments).
2. For steady-state 1D heat flow inside a flat plane wall of thickness $L$:
   $$q = \\frac{k A (T_1 - T_2)}{L}$$

### Thermal Analogy / Resistance:
Mechanical systems use damper resistance, electrical systems use Ohm's ($R = V/I$), and thermal systems employ:
$$R_{t,cond} = \\frac{L}{k A}$$
This allows forming complete thermal circuit paths for composite walls stacked in series.`,
    createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    lastModifiedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    isFavorite: true
  },
  {
    id: 'note-2',
    subjectId: 'c-fea',
    topicId: 't-fea-t1',
    title: 'Finite Element 1D Bar Stiffness Matrix Assembly',
    content: `## Finite Element Analysis Notes
For a simple 1D linear axial elastic bar element of elastic modulus $E$, cross section $A$, and length $L$, the local stiffness matrix $[k^e]$ is:

$$[k^e] = \\frac{AE}{L} \\begin{bmatrix} 1 & -1 \\\\ -1 & 1 \\end{bmatrix}$$

This maps local nodal forces $\{f^e\} = [k^e] \{u^e\}$ where displacement vectors are:
$$\{u^e\} = \\begin{bmatrix} u_1 \\\\ u_2 \\end{bmatrix}$$

### Global Matrix Compilation Protocol:
1. Initialize a sparse global matrix $[K]$ of dimensions $N \\times N$ where $N$ is the total global degree of freedom count.
2. Insert each element's indices step-by-step. For linked overlapping nodes, we sum values:
   $$K_{j,j} = k_{2,2}^{(element 1)} + k_{1,1}^{(element 2)}$$
3. Apply static boundary conditions (such as locking a fixed node displacement to 0) by removing corresponding row and column vectors.`,
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    lastModifiedAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    isFavorite: false
  }
];

const DEFAULT_BOOKMARKS: Bookmark[] = [
  { id: 'bm-1', type: 'course', itemId: 'c-thermodynamics', title: 'Fundamentals of Thermodynamics & Heat Transfer', subTitle: 'Semester 2 • SDUT-ME201' },
  { id: 'bm-2', type: 'course', itemId: 'c-fea', title: 'Finite Element Analysis', subTitle: 'Semester 7 • SDUT-ME702' },
  { id: 'bm-3', type: 'equation', itemId: 'Fourier-Cond-Eq', title: 'Fourier’s Law of Heat Conduction', subTitle: 'Thermodynamics Eq' }
];

const DEFAULT_POMODORO_HISTORY: PomodoroHistoryItem[] = [
  { id: 'ph-1', subject: 'Thermodynamics Conductance Model', duration: 45, timestamp: new Date(Date.now() - 50 * 60 * 1000).toISOString(), completed: true },
  { id: 'ph-2', subject: 'HSK 4 Stroke Practice', duration: 25, timestamp: new Date(Date.now() - 120 * 60 * 1000).toISOString(), completed: true }
];

export function loadItem<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return defaultValue;
    return JSON.parse(raw) as T;
  } catch (err) {
    console.error(`Error decoding standard localStorage path [${key}]:`, err);
    return defaultValue;
  }
}

export function saveItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error(`Error encoding standard localStorage path [${key}]:`, err);
  }
}

export const StorageService = {
  getProfile: (): StudentProfile => loadItem(STORAGE_KEYS.PROFILE, DEFAULT_PROFILE),
  saveProfile: (p: StudentProfile) => saveItem(STORAGE_KEYS.PROFILE, p),

  getSemesters: (): Semester[] => loadItem(STORAGE_KEYS.SEMESTERS, INITIAL_SEMESTERS),
  saveSemesters: (s: Semester[]) => saveItem(STORAGE_KEYS.SEMESTERS, s),

  getDailyTasks: (): DailyTask[] => loadItem(STORAGE_KEYS.DAILY_TASKS, DEFAULT_DAILY_TASKS),
  saveDailyTasks: (t: DailyTask[]) => saveItem(STORAGE_KEYS.DAILY_TASKS, t),

  getWeeklyGoals: (): WeeklyGoal[] => loadItem(STORAGE_KEYS.WEEKLY_GOALS, DEFAULT_WEEKLY_GOALS),
  saveWeeklyGoals: (g: WeeklyGoal[]) => saveItem(STORAGE_KEYS.WEEKLY_GOALS, g),

  getSemesterGoals: (): SemesterGoal[] => loadItem(STORAGE_KEYS.SEMESTER_GOALS, DEFAULT_SEMESTER_GOALS),
  saveSemesterGoals: (g: SemesterGoal[]) => saveItem(STORAGE_KEYS.SEMESTER_GOALS, g),

  getExams: (): ExamRoutine[] => loadItem(STORAGE_KEYS.EXAMS, DEFAULT_EXAMS),
  saveExams: (e: ExamRoutine[]) => saveItem(STORAGE_KEYS.EXAMS, e),

  getNotes: (): AcademicNote[] => loadItem(STORAGE_KEYS.NOTES, DEFAULT_NOTES),
  saveNotes: (n: AcademicNote[]) => saveItem(STORAGE_KEYS.NOTES, n),

  getBookmarks: (): Bookmark[] => loadItem(STORAGE_KEYS.BOOKMARKS, DEFAULT_BOOKMARKS),
  saveBookmarks: (b: Bookmark[]) => saveItem(STORAGE_KEYS.BOOKMARKS, b),

  getPomodoroHistory: (): PomodoroHistoryItem[] => loadItem(STORAGE_KEYS.POMODORO_HISTORY, DEFAULT_POMODORO_HISTORY),
  savePomodoroHistory: (h: PomodoroHistoryItem[]) => saveItem(STORAGE_KEYS.POMODORO_HISTORY, h),

  getSettings: (): AppSettings => {
    const loaded = loadItem(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
    return {
      ...DEFAULT_SETTINGS,
      ...loaded
    };
  },
  saveSettings: (s: AppSettings) => saveItem(STORAGE_KEYS.SETTINGS, s),

  // Backups
  exportAllData: (): string => {
    const bundle = {
      profile: StorageService.getProfile(),
      semesters: StorageService.getSemesters(),
      dailyTasks: StorageService.getDailyTasks(),
      weeklyGoals: StorageService.getWeeklyGoals(),
      semesterGoals: StorageService.getSemesterGoals(),
      exams: StorageService.getExams(),
      notes: StorageService.getNotes(),
      bookmarks: StorageService.getBookmarks(),
      pomodoroHistory: StorageService.getPomodoroHistory(),
      settings: StorageService.getSettings(),
      exporter: "SDUT Mechanical Engineering Academic Navigator Exporter Engine",
      timestamp: new Date().toISOString()
    };
    return JSON.stringify(bundle, null, 2);
  },

  importAllData: (jsonData: string): boolean => {
    try {
      const parsed = JSON.parse(jsonData);
      if (parsed.profile) StorageService.saveProfile(parsed.profile);
      if (parsed.semesters) StorageService.saveSemesters(parsed.semesters);
      if (parsed.dailyTasks) StorageService.saveDailyTasks(parsed.dailyTasks);
      if (parsed.weeklyGoals) StorageService.saveWeeklyGoals(parsed.weeklyGoals);
      if (parsed.semesterGoals) StorageService.saveSemesterGoals(parsed.semesterGoals);
      if (parsed.exams) StorageService.saveExams(parsed.exams);
      if (parsed.notes) StorageService.saveNotes(parsed.notes);
      if (parsed.bookmarks) StorageService.saveBookmarks(parsed.bookmarks);
      if (parsed.pomodoroHistory) StorageService.savePomodoroHistory(parsed.pomodoroHistory);
      if (parsed.settings) StorageService.saveSettings(parsed.settings);
      return true;
    } catch (err) {
      console.error("Format parsing violation during manual restoration imports:", err);
      return false;
    }
  },

  // Reset database state to clean initial values
  resetToDefaults: (): void => {
    localStorage.removeItem(STORAGE_KEYS.PROFILE);
    localStorage.removeItem(STORAGE_KEYS.SEMESTERS);
    localStorage.removeItem(STORAGE_KEYS.DAILY_TASKS);
    localStorage.removeItem(STORAGE_KEYS.WEEKLY_GOALS);
    localStorage.removeItem(STORAGE_KEYS.SEMESTER_GOALS);
    localStorage.removeItem(STORAGE_KEYS.EXAMS);
    localStorage.removeItem(STORAGE_KEYS.NOTES);
    localStorage.removeItem(STORAGE_KEYS.BOOKMARKS);
    localStorage.removeItem(STORAGE_KEYS.POMODORO_HISTORY);
    localStorage.removeItem(STORAGE_KEYS.SETTINGS);
  }
};
