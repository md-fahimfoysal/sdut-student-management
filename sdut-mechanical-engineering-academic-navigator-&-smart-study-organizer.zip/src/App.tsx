import React, { useState, useEffect } from 'react';
import {
  StudentProfile,
  Semester,
  DailyTask,
  WeeklyGoal,
  SemesterGoal,
  ExamRoutine,
  AcademicNote,
  Bookmark,
  PomodoroHistoryItem,
  AppSettings
} from './types';
import { StorageService } from './utils/storage';

// Import Visual Views components
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Roadmap from './components/Roadmap';
import KnowledgeTree from './components/KnowledgeTree';
import Planner from './components/Planner';
import ExamPlanner from './components/ExamPlanner';
import NotesSystem from './components/NotesSystem';
import Bookmarks from './components/Bookmarks';
import StudentLedger from './components/StudentLedger';
import Pomodoro from './components/Pomodoro';
import SettingsPanel from './components/SettingsPanel';
import SearchEverywhere from './components/SearchEverywhere';

import { Wifi, WifiOff, Sparkles, Check } from 'lucide-react';

export default function App() {
  // Mounting structures from Storage caches
  const [profile, setProfile] = useState<StudentProfile>(() => StorageService.getProfile());
  const [semesters, setSemesters] = useState<Semester[]>(() => StorageService.getSemesters());
  const [dailyTasks, setDailyTasks] = useState<DailyTask[]>(() => StorageService.getDailyTasks());
  const [weeklyGoals, setWeeklyGoals] = useState<WeeklyGoal[]>(() => StorageService.getWeeklyGoals());
  const [semesterGoals, setSemesterGoals] = useState<SemesterGoal[]>(() => StorageService.getSemesterGoals());
  const [exams, setExams] = useState<ExamRoutine[]>(() => StorageService.getExams());
  const [notes, setNotes] = useState<AcademicNote[]>(() => StorageService.getNotes());
  const [bookmarks, setBookmarks] = useState<Bookmark[]>(() => StorageService.getBookmarks());
  const [pomodoroHistory, setPomodoroHistory] = useState<PomodoroHistoryItem[]>(() => StorageService.getPomodoroHistory());
  const [settings, setSettings] = useState<AppSettings>(() => StorageService.getSettings());

  // App UI state
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);
  const [searchOpen, setSearchOpen] = useState<boolean>(false);
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);

  const [syncToast, setSyncToast] = useState<string | null>(null);

  // Global hotkeys (Ctrl+K to search)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Multi-device and browser tabs real-time synchronization
  useEffect(() => {
    try {
      const channel = new BroadcastChannel('sdut_academic_os_sync');
      const handleSyncMessage = (event: MessageEvent) => {
        const { type, data } = event.data || {};
        if (!type || !data) return;

        switch (type) {
          case 'SYNC_PROFILE':
            setProfile(data);
            StorageService.saveProfile(data);
            break;
          case 'SYNC_SEMESTERS':
            setSemesters(data);
            StorageService.saveSemesters(data);
            break;
          case 'SYNC_DAILY_TASKS':
            setDailyTasks(data);
            StorageService.saveDailyTasks(data);
            break;
          case 'SYNC_WEEKLY_GOALS':
            setWeeklyGoals(data);
            StorageService.saveWeeklyGoals(data);
            break;
          case 'SYNC_SEMESTER_GOALS':
            setSemesterGoals(data);
            StorageService.saveSemesterGoals(data);
            break;
          case 'SYNC_EXAMS':
            setExams(data);
            StorageService.saveExams(data);
            break;
          case 'SYNC_NOTES':
            setNotes(data);
            StorageService.saveNotes(data);
            break;
          case 'SYNC_BOOKMARKS':
            setBookmarks(data);
            StorageService.saveBookmarks(data);
            break;
          case 'SYNC_POMODO':
            setPomodoroHistory(data);
            StorageService.savePomodoroHistory(data);
            break;
          case 'SYNC_SETTINGS':
            setSettings(data);
            StorageService.saveSettings(data);
            break;
        }

        setSyncToast(`[Multi-Device Account Sync] Pulled live updates successfully!`);
        setTimeout(() => setSyncToast(null), 2500);
      };

      channel.addEventListener('message', handleSyncMessage);
      return () => {
        channel.close();
      };
    } catch (e) {
      console.warn('Sandbox restrictions block BroadcastChannel:', e);
    }
  }, []);

  // Real-time network monitor
  useEffect(() => {
    const handleNetworkChange = () => {
      const online = window.navigator.onLine;
      setIsOnline(online);
      if (online) {
        setSyncToast('Connected online! Synchronizing files and merging offline edits...');
        setTimeout(() => setSyncToast(null), 3000);
      } else {
        setSyncToast('Device offline. Preserving all edits in offline local storage buffer.');
        setTimeout(() => setSyncToast(null), 3500);
      }
    };

    setIsOnline(window.navigator.onLine);
    window.addEventListener('online', handleNetworkChange);
    window.addEventListener('offline', handleNetworkChange);
    return () => {
      window.removeEventListener('online', handleNetworkChange);
      window.removeEventListener('offline', handleNetworkChange);
    };
  }, []);

  // Helper function to synchronize other tabs/devices
  const broadcastSync = (type: string, data: any) => {
    try {
      const channel = new BroadcastChannel('sdut_academic_os_sync');
      channel.postMessage({ type, data });
      channel.close();
    } catch (e) {
      // ignore
    }
  };

  const playSynthAlarm = (preset: 'chime' | 'beep' | 'retro' | 'synth') => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      
      const ctx = new AudioContextClass();
      
      if (preset === 'beep') {
        let time = ctx.currentTime;
        for (let i = 0; i < 4; i++) {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(880, time);
          gain.gain.setValueAtTime(0.2, time);
          gain.gain.exponentialRampToValueAtTime(0.001, time + 0.2);
          
          osc.connect(gain);
          gain.connect(ctx.destination);
          
          osc.start(time);
          osc.stop(time + 0.25);
          time += 0.4;
        }
      } else if (preset === 'retro') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(150, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(800, ctx.currentTime + 0.8);
        
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.8);
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.8);
      } else if (preset === 'synth') {
        const freqs = [196, 293.66, 392, 493.88];
        freqs.forEach((f, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(f, ctx.currentTime);
          
          gain.gain.setValueAtTime(0.06, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.5 + idx * 0.1);
          
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start();
          osc.stop(ctx.currentTime + 2.0);
        });
      } else {
        const freqs = [523.25, 659.25, 783.99, 1046.50];
        freqs.forEach((f, index) => {
          const t = ctx.currentTime + index * 0.15;
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(f, t);
          
          gain.gain.setValueAtTime(0.15, t);
          gain.gain.exponentialRampToValueAtTime(0.001, t + 0.6);
          
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(t);
          osc.stop(t + 0.65);
        });
      }
    } catch (e) {
      console.warn('Audio synthesis failed:', e);
    }
  };

  // Alarm Scheduler State & Effect
  const [activeAlarmTask, setActiveAlarmTask] = useState<DailyTask | null>(null);

  useEffect(() => {
    const checkAlarmsInterval = setInterval(() => {
      if (typeof window === 'undefined') return;
      
      const now = new Date();
      const currentHoursAndMinutes = now.toTimeString().split(' ')[0].substring(0, 5); // "HH:MM"
      
      dailyTasks.forEach(task => {
        if (
          task.alarmEnabled && 
          !task.alarmTriggered && 
          task.completedProgress < 100 &&
          task.time === currentHoursAndMinutes
        ) {
          console.log(`[ALARM TRK] Alarm triggered for task: ${task.task}`);
          setActiveAlarmTask(task);
          playSynthAlarm(task.alarmSound || 'chime');
          
          const updated = dailyTasks.map(t => t.id === task.id ? { ...t, alarmTriggered: true } : t);
          setDailyTasks(updated);
          StorageService.saveDailyTasks(updated);
          broadcastSync('SYNC_DAILY_TASKS', updated);
        }
      });
    }, 10000);

    return () => clearInterval(checkAlarmsInterval);
  }, [dailyTasks]);

  // Sync state triggers
  const handleForceSync = () => {
    const providerName = settings.cloudProvider === 'google-drive' ? 'Google Drive' :
                         settings.cloudProvider === 'onedrive' ? 'Microsoft OneDrive' :
                         settings.cloudProvider === 'dropbox' ? 'Dropbox Sync' :
                         settings.cloudProvider === 'firebase' ? 'Firebase Cloud Firestore' : 'Academic Core Sync';
    setSyncToast(`[Syncing] Uploading and merging files with ${providerName}...`);
    
    setSettings(prev => ({ ...prev, cloudSyncStatus: 'syncing' }));

    setTimeout(() => {
      const now = new Date().toISOString();
      const updatedSettings: AppSettings = {
        ...settings,
        cloudSyncStatus: 'synced',
        cloudSyncLastSuccess: now
      };
      setSettings(updatedSettings);
      StorageService.saveSettings(updatedSettings);
      broadcastSync('SYNC_SETTINGS', updatedSettings);

      setSyncToast(`Merged successfully with ${providerName}! State fully consistent.`);
      setTimeout(() => setSyncToast(null), 2500);
    }, 1500);
  };

  // State wrapper mutations
  const handleSetSemesters = (updated: Semester[]) => {
    setSemesters(updated);
    StorageService.saveSemesters(updated);
    broadcastSync('SYNC_SEMESTERS', updated);
  };

  const handleSetDailyTasks = (updated: DailyTask[]) => {
    setDailyTasks(updated);
    StorageService.saveDailyTasks(updated);
    broadcastSync('SYNC_DAILY_TASKS', updated);
  };

  const handleSetWeeklyGoals = (updated: WeeklyGoal[]) => {
    setWeeklyGoals(updated);
    StorageService.saveWeeklyGoals(updated);
    broadcastSync('SYNC_WEEKLY_GOALS', updated);
  };

  const handleSetSemesterGoals = (updated: SemesterGoal[]) => {
    setSemesterGoals(updated);
    StorageService.saveSemesterGoals(updated);
    broadcastSync('SYNC_SEMESTER_GOALS', updated);
  };

  const handleSetExams = (updated: ExamRoutine[]) => {
    setExams(updated);
    StorageService.saveExams(updated);
    broadcastSync('SYNC_EXAMS', updated);
  };

  const handleSetNotes = (updated: AcademicNote[]) => {
    setNotes(updated);
    StorageService.saveNotes(updated);
    broadcastSync('SYNC_NOTES', updated);
  };

  const handleSetBookmarks = (updated: Bookmark[]) => {
    setBookmarks(updated);
    StorageService.saveBookmarks(updated);
    broadcastSync('SYNC_BOOKMARKS', updated);
  };

  const handleSetHistory = (updated: PomodoroHistoryItem[]) => {
    setPomodoroHistory(updated);
    StorageService.savePomodoroHistory(updated);
    broadcastSync('SYNC_POMODO', updated);
  };

  const handleSetProfile = (updated: StudentProfile) => {
    setProfile(updated);
    StorageService.saveProfile(updated);
    broadcastSync('SYNC_PROFILE', updated);
  };

  const handleSetSettings = (updated: AppSettings) => {
    setSettings(updated);
    StorageService.saveSettings(updated);
    broadcastSync('SYNC_SETTINGS', updated);
  };

  // Bookmark Toggle logic for individual items
  const handleToggleBookmark = (item: any) => {
    const exists = bookmarks.some((b) => b.itemId === item.id);
    if (exists) {
      const filtered = bookmarks.filter((b) => b.itemId !== item.id);
      handleSetBookmarks(filtered);
    } else {
      const newBm: Bookmark = {
        id: `bm-${Date.now()}`,
        type: item.type || 'course',
        itemId: item.id,
        title: item.name || item.title || 'Curriculum Item',
        subTitle: item.code ? `Course Reference • ${item.code}` : 'Revision resource'
      };
      handleSetBookmarks([...bookmarks, newBm]);
    }
  };

  return (
    <div className={`theme-${settings.theme || 'elegant-dark'} bg-[var(--bg-app)] text-[var(--text-primary)] min-h-screen transition-colors duration-200`}>
      
      {/* Synchronization alert banner overlay */}
      {syncToast && (
        <div className="fixed top-5 right-5 z-50 bg-blue-600 text-white px-5 py-3 rounded-xl border border-blue-500/30 shadow-2xl text-xs font-bold animate-slide-in flex items-center space-x-2.5">
          <Check size={16} />
          <span>{syncToast}</span>
        </div>
      )}

      {/* Main Core Layout grid */}
      <div className="flex">
        
        {/* Sidebar Left Navigation */}
        <Sidebar
          currentTab={currentTab}
          setCurrentTab={setCurrentTab}
          collapsed={isSidebarCollapsed}
          setCollapsed={setIsSidebarCollapsed}
          profile={profile}
          settings={settings}
          onOpenSearch={() => setSearchOpen(true)}
          isOnline={isOnline}
          onForceSync={handleForceSync}
        />

        {/* Content Right Pane */}
        <main className={`flex-1 min-h-screen transition-all duration-300 p-4 sm:p-6 lg:p-8 ${
          isSidebarCollapsed ? 'pl-24' : 'pl-24 sm:pl-80'
        }`}>
          <div className="max-w-7xl mx-auto space-y-6">
            
            {/* Header branding overlay banner */}
            <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b pb-4 border-[var(--border-main)]/60">
              <div className="space-y-1">
                <span className="text-[10px] text-blue-400 bg-blue-500/10 px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider font-mono">
                  Bachelor of Mechanical Engineering (Intelligent Manufacturing Tech) • SDUT
                </span>
                <h2 className="text-xl sm:text-2xl font-black text-[var(--text-primary)] font-sans tracking-tight">
                  {settings.generalTitle || 'SDUT Mechanical Engineering Academic OS'}
                </h2>
              </div>

              {/* Status capsule */}
              <div className="flex items-center space-x-2 text-[10px] font-mono text-[var(--text-secondary)] font-bold uppercase tracking-wider bg-black/15 border border-[var(--border-main)] px-3 py-1.5 rounded-lg">
                <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse" />
                <span>SDUT-ME Client Core Online</span>
              </div>
            </header>

            {/* Router dynamic selectors */}
            {currentTab === 'dashboard' && (
              <Dashboard
                profile={profile}
                setProfile={handleSetProfile}
                semesters={semesters}
                setSemesters={handleSetSemesters}
                dailyTasks={dailyTasks}
                setDailyTasks={handleSetDailyTasks}
                weeklyGoals={weeklyGoals}
                setWeeklyGoals={handleSetWeeklyGoals}
                semesterGoals={semesterGoals}
                setSemesterGoals={handleSetSemesterGoals}
                exams={exams}
                setExams={handleSetExams}
                notes={notes}
                bookmarks={bookmarks}
                pomodoroHistory={pomodoroHistory}
                settings={settings}
                setSettings={handleSetSettings}
                setCurrentTab={setCurrentTab}
                setSelectedCourseId={setSelectedCourseId}
              />
            )}

            {currentTab === 'roadmap' && (
              <Roadmap
                semesters={semesters}
                setSemesters={handleSetSemesters}
                bookmarks={bookmarks}
                onToggleBookmark={handleToggleBookmark}
                selectedCourseId={selectedCourseId}
                setSelectedCourseId={setSelectedCourseId}
              />
            )}

            {currentTab === 'knowledge-tree' && (
              <KnowledgeTree
                semesters={semesters}
                setSemesters={handleSetSemesters}
                setCurrentTab={setCurrentTab}
              />
            )}

            {currentTab === 'planner' && (
              <Planner
                dailyTasks={dailyTasks}
                setDailyTasks={handleSetDailyTasks}
                weeklyGoals={weeklyGoals}
                setWeeklyGoals={handleSetWeeklyGoals}
                semesterGoals={semesterGoals}
                setSemesterGoals={handleSetSemesterGoals}
              />
            )}

            {currentTab === 'exams' && (
              <ExamPlanner
                exams={exams}
                setExams={handleSetExams}
              />
            )}

            {currentTab === 'notes' && (
              <NotesSystem
                notes={notes}
                setNotes={handleSetNotes}
                semesters={semesters}
              />
            )}

            {currentTab === 'bookmarks' && (
              <Bookmarks
                bookmarks={bookmarks}
                setBookmarks={handleSetBookmarks}
                semesters={semesters}
                notes={notes}
                onSelectCourse={setSelectedCourseId}
                setCurrentTab={setCurrentTab}
              />
            )}

            {currentTab === 'ledger' && (
              <StudentLedger
                profile={profile}
                setProfile={handleSetProfile}
                semesters={semesters}
              />
            )}

            {currentTab === 'pomodoro' && (
              <Pomodoro
                semesters={semesters}
                history={pomodoroHistory}
                setHistory={handleSetHistory}
              />
            )}

            {currentTab === 'settings' && (
              <SettingsPanel
                settings={settings}
                setSettings={handleSetSettings}
                profile={profile}
                setProfile={handleSetProfile}
                semesters={semesters}
                setSemesters={handleSetSemesters}
                isOnline={isOnline}
                setIsOnline={setIsOnline}
              />
            )}

          </div>
        </main>
      </div>

      {/* Global Search Everywhere Dialog Box */}
      <SearchEverywhere
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        semesters={semesters}
        notes={notes}
        bookmarks={bookmarks}
        onSelectCourse={setSelectedCourseId}
        setCurrentTab={setCurrentTab}
      />

      {/* Unified Interactive Audio Alarm Popup Overlay */}
      {activeAlarmTask && (
        <div className="fixed top-6 right-6 z-50 animate-bounce bg-linear-to-r from-red-600 to-rose-700 text-white rounded-2xl border border-red-500/30 p-5 shadow-2xl max-w-sm flex items-start space-x-4">
          <div className="bg-white/10 p-3 rounded-full animate-pulse select-none text-xl">
            🔔
          </div>
          <div className="flex-1 space-y-2 font-sans">
            <div>
              <span className="text-[9px] bg-white/20 px-2 py-0.5 rounded font-mono font-bold uppercase tracking-wider">Academic Alarm Reminder</span>
              <h4 className="text-sm font-black mt-1 leading-snug">{activeAlarmTask.task}</h4>
              <p className="text-[10px] text-white/80 font-mono mt-0.5">Strikes: {activeAlarmTask.time} • Priority: {activeAlarmTask.priority}</p>
            </div>
            <div className="flex items-center space-x-2 pt-1">
              <button
                type="button"
                onClick={() => playSynthAlarm(activeAlarmTask.alarmSound || 'chime')}
                className="bg-white/15 hover:bg-white/25 border border-white/20 text-white text-[10px] py-1 px-2.5 rounded-md font-mono font-bold transition-colors cursor-pointer"
              >
                🔊 Test Ring
              </button>
              <button
                type="button"
                onClick={() => {
                  const updated = dailyTasks.map(t => t.id === activeAlarmTask.id ? { ...t, completedProgress: 100 } : t);
                  handleSetDailyTasks(updated);
                  setActiveAlarmTask(null);
                }}
                className="bg-emerald-500 hover:bg-emerald-600 text-white text-[10px] py-1 px-3 rounded-md font-bold transition-colors cursor-pointer"
              >
                Done!
               </button>
              <button
                type="button"
                onClick={() => setActiveAlarmTask(null)}
                className="bg-white text-rose-700 text-[10px] py-1 px-3 rounded-md font-extrabold shadow-sm hover:bg-slate-100 transition-colors cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
