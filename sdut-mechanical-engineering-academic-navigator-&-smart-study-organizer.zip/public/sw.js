const CACHE_NAME = 'sdut-navigator-v1';

// Assets to cache immediately on service worker install
const INITIAL_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon.svg'
];

self.addEventListener('install', (event) => {
  // Force active immediately
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[PWA ServiceWorker] Pre-caching Core App Shell');
      return cache.addAll(INITIAL_ASSETS);
    })
  );
});

self.addEventListener('activate', (event) => {
  // Take control immediately
  event.waitUntil(self.clients.claim());
  
  // Clean up any stale/older caches
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cache) => {
          if (cache !== CACHE_NAME) {
            console.log('[PWA ServiceWorker] Clearing Stale Cache:', cache);
            return caches.delete(cache);
          }
        })
      );
    })
  );
});

// Dynamic Intercept & Offline strategies
self.addEventListener('fetch', (event) => {
  const requestUrl = new URL(event.request.url);

  // Skip APIs and non-GET requests (e.g., POST, external cloud syncs)
  if (event.request.method !== 'GET' || requestUrl.pathname.startsWith('/api')) {
    return;
  }

  // Strategy 1: Network-First for HTML navigation (index.html)
  // This ensures the user gets real-time edits when connected, but falls back seamlessly to the cached shell when offline.
  if (event.request.mode === 'navigate' || requestUrl.pathname === '/') {
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          // Clone response and cache it
          const responseClone = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put('/', responseClone);
          });
          return response;
        })
        .catch(() => {
          // If offline, serve cached home shell
          return caches.match('/');
        })
    );
    return;
  }

  // Strategy 2: Stale-While-Revalidate for Web Assets (JS, CSS, SVGs, Fonts)
  // This delivers lightning-fast instantaneous startup from cache, while updating assets in the background.
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        // Fetch fresh asset in background to keep cache up-to-date
        fetch(event.request)
          .then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200) {
              caches.open(CACHE_NAME).then((cache) => {
                cache.put(event.request, networkResponse);
              });
            }
          })
          .catch(() => {
            // Silence network failures in background fetches (e.g. offline)
          });
        return cachedResponse;
      }

      // Fallback to fetch from network if not in cache
      return fetch(event.request)
        .then((networkResponse) => {
          // Allow caching of local basic/cors responses that are successful
          if (!networkResponse || (networkResponse.status !== 200 && networkResponse.status !== 304)) {
            return networkResponse;
          }
          const responseClone = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseClone);
          });
          return networkResponse;
        })
        .catch(() => {
          // Fail gracefully if resources can't be retrieved or cached
        });
    })
  );
});
